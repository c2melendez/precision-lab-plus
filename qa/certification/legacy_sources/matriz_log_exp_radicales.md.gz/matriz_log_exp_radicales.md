# Matriz de estrés — Logarítmicas, exponenciales, radicales y sus combinaciones

Batería para medir la capacidad real de los motores de la calculadora (Precision Lab Lite / Plus) y localizar oportunidades de mejora. Cubre funciones logarítmicas, exponenciales y radicales, solas y combinadas con polinomios, racionales, trigonométricas, hiperbólicas y sus inversas.

## Convenciones

- Trabajo en $\mathbb{R}$ salvo indicación. Ángulos en radianes.
- `\ln` es logaritmo natural; `\log_{b}` es base $b$; `\log` sin base se evita.
- Raíces de índice impar de negativos: se espera la **raíz real** (p. ej. $\sqrt[3]{-8}=-2$). Si el motor devuelve la rama principal compleja, anotarlo como *observación de convención*, no como fallo.
- Antiderivadas: se aceptan salvo constante y en formas equivalentes.
- Aproximaciones a 9 decimales cuando se indica `\approx`.
- Cada ejercicio y cada resultado esperado está en código LaTeX, listo para pegar.
- **Nivel:** `N1` básico · `N2` intermedio (requiere estrategia) · `N3` desafío (función especial, rama delicada, cancelación numérica o técnica no trivial).
- "Error claro" = el motor debe avisar del problema (dominio, divergencia, indefinición). Devolver un número incorrecto en silencio es el peor resultado posible.
- Los resultados esperados se calcularon a mano y se verificaron derivando/sustituyendo. Ante una discrepancia, revisar primero el valor esperado.

## Categorías de fallo sugeridas para el registro

| Código | Significado | Gravedad |
|---|---|---|
| F1 | Resultado matemáticamente incorrecto | Crítica |
| F2 | Pierde soluciones / incluye soluciones extrañas | Alta |
| F3 | No resuelve (sin respuesta, timeout o "no soportado") | Media |
| F4 | Correcto pero sin simplificar o en forma poco útil | Baja |
| F5 | Dominio o rama no respetados (p. ej. $\sqrt{x^2}\to x$) | Alta |
| F6 | Error numérico (cancelación, desbordamiento, precisión) | Alta |

---

## 1. Evaluación de una función en un punto

### 1.L Logarítmicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EV-L-01 | N1 | `\ln\left(e^{3}\right)` | `3` |
| EV-L-02 | N1 | `\log_{2}(8)` | `3` |
| EV-L-03 | N1 | `\log_{10}(0.001)` | `-3` |
| EV-L-04 | N1 | `\log_{3}\left(\frac{1}{27}\right)` | `-3` |
| EV-L-05 | N1 | `\ln 2` | `\approx 0.693147181` |
| EV-L-06 | N2 | `\log_{4}(8)` | `\frac{3}{2}` |
| EV-L-07 | N2 | `\log_{8}(2)` | `\frac{1}{3}` |
| EV-L-08 | N2 | `\log_{2}(3)` | `\approx 1.584962501` |
| EV-L-09 | N2 | `\log_{2}(3)\cdot\log_{3}(4)` | `2` |
| EV-L-10 | N2 | `\ln\left(\sqrt{e}\right)` | `\frac{1}{2}` |
| EV-L-11 | N3 | `\ln\left(10^{50}\right)` | `50\ln 10\approx 115.129254650` |
| EV-L-12 | N2 | `\ln(0)` | indefinido (error claro) |
| EV-L-13 | N2 | `\ln(-1)` | en $\mathbb{R}$: error claro; en $\mathbb{C}$: `i\pi` |
| EV-L-14 | N2 | `\log_{1}(5)` | base inválida (error claro) |

### 1.E Exponenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EV-E-01 | N1 | `e^{0}` | `1` |
| EV-E-02 | N1 | `e^{-1}` | `\approx 0.367879441` |
| EV-E-03 | N1 | `2^{10}` | `1024` |
| EV-E-04 | N1 | `2^{-3}` | `\frac{1}{8}` |
| EV-E-05 | N2 | `8^{2/3}` | `4` |
| EV-E-06 | N2 | `27^{-1/3}` | `\frac{1}{3}` |
| EV-E-07 | N2 | `2^{\sqrt{2}}` | `\approx 2.665144143` |
| EV-E-08 | N2 | `\pi^{e}` | `\approx 22.459157718` |
| EV-E-09 | N3 | `e^{\pi}-\pi` | `\approx 19.999099979` |
| EV-E-10 | N2 | `e^{\ln 2+\ln 3}` | `6` |
| EV-E-11 | N3 | `e^{100}` | `\approx 2.688117142\times 10^{43}` |
| EV-E-12 | N2 | `\left(1+\frac{1}{1000}\right)^{1000}` | `\approx 2.716923932` |
| EV-E-13 | N2 | `e^{i\pi}` | `-1` (en $\mathbb{C}$) |
| EV-E-14 | N2 | `0^{0}` | indeterminada (o `1` por convención declarada) |

### 1.R Radicales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EV-R-01 | N1 | `\sqrt{16}` | `4` |
| EV-R-02 | N1 | `\sqrt[3]{27}` | `3` |
| EV-R-03 | N1 | `\sqrt[3]{-8}` | `-2` (raíz real) |
| EV-R-04 | N1 | `\sqrt[4]{81}` | `3` |
| EV-R-05 | N1 | `\sqrt[5]{-32}` | `-2` |
| EV-R-06 | N1 | `\sqrt{12}` | `2\sqrt{3}` |
| EV-R-07 | N2 | `\sqrt{8}+\sqrt{18}` | `5\sqrt{2}` |
| EV-R-08 | N2 | `\frac{1}{\sqrt{2}+1}` | `\sqrt{2}-1` |
| EV-R-09 | N2 | `\sqrt[3]{2}\cdot\sqrt[3]{4}` | `2` |
| EV-R-10 | N2 | `16^{3/4}` | `8` |
| EV-R-11 | N3 | `\sqrt{3+2\sqrt{2}}` | `1+\sqrt{2}` (radical anidado) |
| EV-R-12 | N3 | `\sqrt{5+2\sqrt{6}}` | `\sqrt{2}+\sqrt{3}` |
| EV-R-13 | N2 | `\sqrt{-4}` | en $\mathbb{R}$: error claro; en $\mathbb{C}$: `2i` |
| EV-R-14 | N2 | `(-8)^{1/3}` | convención: real `-2`; principal `1+i\sqrt{3}`. Debe declarar cuál usa |

### 1.M Mixtas (log, exp, radicales, polinomios)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EV-M-01 | N1 | `\ln\left(\sqrt[3]{e^{6}}\right)` | `2` |
| EV-M-02 | N1 | `e^{2\ln 3}` | `9` |
| EV-M-03 | N1 | `\log_{2}\left(\sqrt{8}\right)` | `\frac{3}{2}` |
| EV-M-04 | N2 | `f(x)=\ln\left(x^{2}+1\right);\ f\left(\sqrt{e-1}\right)` | `1` |
| EV-M-05 | N2 | `f(x)=\sqrt[3]{x^{3}+1};\ f(2)` | `\sqrt[3]{9}\approx 2.080083823` |
| EV-M-06 | N2 | `f(x)=x^{2}e^{-x};\ f(2)` | `4e^{-2}\approx 0.541341133` |
| EV-M-07 | N1 | `f(x)=\frac{\ln x}{x};\ f(e)` | `e^{-1}\approx 0.367879441` |
| EV-M-08 | N1 | `f(x)=x^{x};\ f(2)` | `4` |
| EV-M-09 | N2 | `\sqrt{2}^{\sqrt{2}}` | `\approx 1.632526919` |
| EV-M-10 | N2 | `\ln\left(\frac{1+\sqrt{5}}{2}\right)` | `\approx 0.481211825` |
| EV-M-11 | N2 | `\left(\frac{1+\sqrt{5}}{2}\right)^{2}` | `\frac{3+\sqrt{5}}{2}\approx 2.618033989` |
| EV-M-12 | N2 | `f(x)=\sqrt{x^{2}};\ f(-3)` | `3` (no `-3`) |
| EV-M-13 | N3 | `f(x)=\ln\left(x-\sqrt{x^{2}-1}\right)+\ln\left(x+\sqrt{x^{2}-1}\right);\ f(2)` | `0` |

### 1.T Con trigonométricas, hiperbólicas e inversas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EV-T-01 | N1 | `\ln\left(\sin\frac{\pi}{2}\right)` | `0` |
| EV-T-02 | N2 | `e^{\sin(\pi/6)}` | `\sqrt{e}\approx 1.648721271` |
| EV-T-03 | N2 | `\sqrt{1+\tan^{2}\frac{\pi}{3}}` | `2` |
| EV-T-04 | N1 | `\ln\left(\tan\frac{\pi}{4}\right)` | `0` |
| EV-T-05 | N2 | `\ln(\cosh 1)` | `\approx 0.433780830` |
| EV-T-06 | N1 | `\arctan\left(e^{0}\right)` | `\frac{\pi}{4}` |
| EV-T-07 | N3 | `\sin\left(10^{22}\right)` | `\approx -0.852200850` (reducción de argumento) |
| EV-T-08 | N2 | `e^{i\pi/2}` | `i` (en $\mathbb{C}$) |
| EV-T-09 | N2 | `\operatorname{arsinh}\left(\frac{e-e^{-1}}{2}\right)` | `1` |
| EV-T-10 | N2 | `\exp\left(\operatorname{artanh}\frac{1}{2}\right)` | `\sqrt{3}` |
| EV-T-11 | N2 | `\ln\left(\cos\frac{\pi}{2}\right)` | indefinido (error claro) |
| EV-T-12 | N2 | `\sqrt{\cos\pi}` | en $\mathbb{R}$: error claro; en $\mathbb{C}$: `i` |

---

## 2. Ecuaciones (soluciones en $\mathbb{R}$)

### 2.L Logarítmicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EC-L-01 | N1 | `\ln x=2` | `x=e^{2}` |
| EC-L-02 | N1 | `\log_{2}x=5` | `x=32` |
| EC-L-03 | N1 | `\log_{3}(x-1)=2` | `x=10` |
| EC-L-04 | N2 | `\ln x+\ln(x-2)=\ln 3` | `x=3` (descartar `x=-1`) |
| EC-L-05 | N2 | `\log_{2}x+\log_{2}(x-3)=2` | `x=4` (descartar `x=-1`) |
| EC-L-06 | N2 | `(\ln x)^{2}-3\ln x+2=0` | `x=e,\ x=e^{2}` |
| EC-L-07 | N2 | `\log_{x}8=3` | `x=2` |
| EC-L-08 | N2 | `\ln(x+1)-\ln x=1` | `x=\frac{1}{e-1}` |
| EC-L-09 | N2 | `\log_{2}\left(\log_{3}x\right)=1` | `x=9` |
| EC-L-10 | N2 | `\ln\left(x^{2}\right)=2\ln x` | todo `x>0` |
| EC-L-11 | N3 | `\ln x=-x` | `x=W(1)\approx 0.567143290` |
| EC-L-12 | N3 | `\ln x=x-2` | `x\approx 0.158594340,\ x\approx 3.146193221` (dos soluciones) |

### 2.E Exponenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EC-E-01 | N1 | `e^{x}=5` | `x=\ln 5` |
| EC-E-02 | N1 | `2^{x}=32` | `x=5` |
| EC-E-03 | N1 | `3^{2x-1}=27` | `x=2` |
| EC-E-04 | N2 | `e^{2x}-5e^{x}+6=0` | `x=\ln 2,\ x=\ln 3` |
| EC-E-05 | N2 | `4^{x}-3\cdot 2^{x}+2=0` | `x=0,\ x=1` |
| EC-E-06 | N2 | `e^{x}+e^{-x}=4` | `x=\pm\ln\left(2+\sqrt{3}\right)` |
| EC-E-07 | N2 | `2^{x}=3^{x-1}` | `x=\frac{\ln 3}{\ln 3-\ln 2}\approx 2.709511291` |
| EC-E-08 | N1 | `e^{x}=-1` | sin solución real |
| EC-E-09 | N3 | `xe^{x}=1` | `x=W(1)\approx 0.567143290` |
| EC-E-10 | N3 | `xe^{x}=2` | `x=W(2)\approx 0.852605502` |
| EC-E-11 | N3 | `xe^{x}=-\frac{1}{e}` | `x=-1` (raíz doble; punto de ramificación de $W$) |
| EC-E-12 | N3 | `e^{x}=x+1` | `x=0` (raíz doble) |
| EC-E-13 | N3 | `e^{x}=2x` | sin solución real |
| EC-E-14 | N3 | `2^{x}=x^{2}` | `x=2,\ x=4,\ x\approx -0.766664696` |
| EC-E-15 | N3 | `x^{x}=27` | `x=3` |

### 2.R Radicales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EC-R-01 | N1 | `\sqrt{x}=3` | `x=9` |
| EC-R-02 | N1 | `\sqrt[3]{x+1}=2` | `x=7` |
| EC-R-03 | N2 | `\sqrt{x+1}=x-1` | `x=3` (descartar `x=0`) |
| EC-R-04 | N2 | `\sqrt{x^{2}-4}=\sqrt{3x}` | `x=4` (descartar `x=-1`) |
| EC-R-05 | N2 | `\sqrt{x+5}-\sqrt{x}=1` | `x=4` |
| EC-R-06 | N3 | `\sqrt{2x+3}+\sqrt{x-2}=4` | `x=3` (descartar `x=83`) |
| EC-R-07 | N2 | `\sqrt[3]{x}=x` | `x=-1,\ x=0,\ x=1` |
| EC-R-08 | N2 | `\sqrt{x}+\sqrt[3]{x}=2` | `x=1` |
| EC-R-09 | N2 | `x^{2/3}=4` | `x=\pm 8` |
| EC-R-10 | N2 | `\left\lvert\sqrt{x}-2\right\rvert=1` | `x=1,\ x=9` |
| EC-R-11 | N1 | `\sqrt{x}=-2` | sin solución real |

### 2.M Mixtas (log, exp, radicales, polinomios)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EC-M-01 | N2 | `\left(x^{2}-4\right)\ln x=0` | `x=1,\ x=2` (descartar `x=-2`) |
| EC-M-02 | N2 | `x\sqrt{x-1}=0` | `x=1` (descartar `x=0`) |
| EC-M-03 | N2 | `e^{x}\left(x^{2}-3x+2\right)=0` | `x=1,\ x=2` |
| EC-M-04 | N2 | `\left(x^{2}-1\right)\ln x=0` | `x=1` (descartar `x=-1`) |
| EC-M-05 | N2 | `\sqrt{x}\,(x-4)\ln x=0` | `x=1,\ x=4` |
| EC-M-06 | N2 | `\ln\left(x^{4}-5x^{2}+5\right)=0` | `x=\pm 1,\ x=\pm 2` |
| EC-M-07 | N2 | `\ln\left(x^{2}-1\right)=\ln 3` | `x=\pm 2` |
| EC-M-08 | N2 | `\ln\lvert x\rvert=1` | `x=\pm e` |
| EC-M-09 | N2 | `e^{2x}-e^{x}-2=0` | `x=\ln 2` (descartar `e^{x}=-1`) |
| EC-M-10 | N2 | `2^{\sqrt{x}}=16` | `x=16` |
| EC-M-11 | N2 | `\sqrt{e^{x}-1}=1` | `x=\ln 2` |
| EC-M-12 | N1 | `e^{\ln x}=x` | todo `x>0` |
| EC-M-13 | N3 | `\sqrt{x}=\ln x` | sin solución real |
| EC-M-14 | N3 | `x^{2}=e^{x}` | `x\approx -0.703467422` (única real) |
| EC-M-15 | N2 | `\begin{cases}\ln x+\ln y=\ln 6\\ x+y=5\end{cases}` | `(x,y)=(2,3),\ (3,2)` |
| EC-M-16 | N2 | `\begin{cases}e^{x}e^{y}=e^{5}\\ x-y=1\end{cases}` | `(x,y)=(3,2)` |
| EC-M-17 | N2 | `\begin{cases}\sqrt{x}+\sqrt{y}=5\\ x-y=5\end{cases}` | `(x,y)=(9,4)` |
| EC-M-18 | N3 | `\begin{cases}y=e^{x}\\ y=x+2\end{cases}` | `x\approx -1.841405661,\ x\approx 1.146193221` |

### 2.T Con trigonométricas e hiperbólicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| EC-T-01 | N2 | `\ln(\sin x)=0,\quad x\in(0,\pi)` | `x=\frac{\pi}{2}` |
| EC-T-02 | N2 | `e^{\sin x}=1,\quad x\in[0,2\pi]` | `x=0,\ \pi,\ 2\pi` |
| EC-T-03 | N2 | `\sqrt{\sin x}=\frac{1}{2},\quad x\in[0,\pi]` | `x=\arcsin\frac{1}{4},\ \pi-\arcsin\frac{1}{4}` (`\approx 0.252680255,\ 2.888912399`) |
| EC-T-04 | N2 | `\ln(\tan x)=0,\quad x\in\left(0,\frac{\pi}{2}\right)` | `x=\frac{\pi}{4}` |
| EC-T-05 | N3 | `4^{\sin^{2}x}+4^{\cos^{2}x}=5,\quad x\in[0,2\pi)` | `x=0,\ \frac{\pi}{2},\ \pi,\ \frac{3\pi}{2}` |
| EC-T-06 | N3 | `x=\cos x` | `x\approx 0.739085133` |
| EC-T-07 | N2 | `e^{x}-e^{-x}=2` | `x=\ln\left(1+\sqrt{2}\right)` |
| EC-T-08 | N2 | `\ln(\cosh x)=\ln 2` | `x=\pm\ln\left(2+\sqrt{3}\right)` |
| EC-T-09 | N2 | `e^{x}=\cosh x+\sinh x` | identidad: todo `x` |
| EC-T-10 | N3 | `\sin\left(\ln x\right)=0,\quad x\in\left[1,e^{2\pi}\right]` | `x=1,\ e^{\pi},\ e^{2\pi}` |
| EC-T-11 | N3 | `\arctan\left(e^{x}\right)=\frac{\pi}{4}` | `x=0` |
| EC-T-12 | N3 | `\sqrt{\cos x}=\cos x,\quad x\in[0,2\pi)` | `x=0,\ \frac{\pi}{2},\ \frac{3\pi}{2}` (`\cos x\in\{0,1\}`) |

---

## 3. Inecuaciones

### 3.L Logarítmicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IN-L-01 | N1 | `\ln x>1` | `(e,\infty)` |
| IN-L-02 | N2 | `\log_{1/2}x>2` | `\left(0,\frac{1}{4}\right)` (base menor que 1 invierte el sentido) |
| IN-L-03 | N2 | `\ln(x-1)\le 0` | `(1,2]` |
| IN-L-04 | N2 | `\log_{2}x+\log_{2}(x-1)<1` | `(1,2)` |
| IN-L-05 | N2 | `(\ln x)^{2}-\ln x-2<0` | `\left(e^{-1},e^{2}\right)` |
| IN-L-06 | N2 | `\ln\left(x^{2}-4\right)\ge 0` | `\left(-\infty,-\sqrt{5}\right]\cup\left[\sqrt{5},\infty\right)` |
| IN-L-07 | N2 | `\lvert\ln x\rvert<1` | `\left(e^{-1},e\right)` |
| IN-L-08 | N2 | `x\ln x<0` | `(0,1)` |
| IN-L-09 | N2 | `\frac{\ln x}{x}>0` | `(1,\infty)` |

### 3.E Exponenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IN-E-01 | N1 | `e^{x}>2` | `(\ln 2,\infty)` |
| IN-E-02 | N1 | `2^{x}\le 8` | `(-\infty,3]` |
| IN-E-03 | N2 | `\left(\frac{1}{2}\right)^{x}<\frac{1}{4}` | `(2,\infty)` |
| IN-E-04 | N2 | `e^{2x}-3e^{x}+2<0` | `(0,\ln 2)` |
| IN-E-05 | N2 | `4^{x}-2^{x+1}-8>0` | `(2,\infty)` |
| IN-E-06 | N2 | `e^{-x^{2}}>\frac{1}{e}` | `(-1,1)` |
| IN-E-07 | N2 | `xe^{x}<0` | `(-\infty,0)` |
| IN-E-08 | N2 | `e^{x}\ge x+1` | `\mathbb{R}` |
| IN-E-09 | N3 | `e^{x}>x^{2}` | `\left(-0.703467422,\infty\right)` |
| IN-E-10 | N3 | `2^{x}>x^{2}` | `\left(-0.766664696,\ 2\right)\cup(4,\infty)` |

### 3.R Radicales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IN-R-01 | N1 | `\sqrt{x-2}<3` | `[2,11)` |
| IN-R-02 | N1 | `\sqrt[3]{x}<2` | `(-\infty,8)` |
| IN-R-03 | N2 | `\frac{1}{\sqrt{x}}<\frac{1}{2}` | `(4,\infty)` |
| IN-R-04 | N2 | `\sqrt{x^{2}-1}\ge 2` | `\left(-\infty,-\sqrt{5}\right]\cup\left[\sqrt{5},\infty\right)` |
| IN-R-05 | N3 | `\sqrt{x+1}>x-1` | `[-1,3)` |
| IN-R-06 | N3 | `\sqrt{4-x^{2}}>x` | `\left[-2,\sqrt{2}\right)` |
| IN-R-07 | N3 | `\sqrt{x^{2}+1}<x+1` | `(0,\infty)` |
| IN-R-08 | N3 | `\sqrt{x}+\sqrt{x+3}<3` | `[0,1)` |
| IN-R-09 | N2 | `x^{2/3}>1` | `(-\infty,-1)\cup(1,\infty)` |

### 3.M Mixtas (log, exp, radicales, polinomios, racionales)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IN-M-01 | N2 | `\left(x^{2}-4\right)\ln x>0` | `(0,1)\cup(2,\infty)` |
| IN-M-02 | N2 | `\frac{\ln x}{x^{2}-1}>0` | `(0,1)\cup(1,\infty)` |
| IN-M-03 | N3 | `\frac{e^{x}-1}{x^{2}-1}\ge 0` | `(-1,0]\cup(1,\infty)` |
| IN-M-04 | N3 | `\sqrt{x}\,(x-1)(x-3)\le 0` | `\{0\}\cup[1,3]` (punto aislado) |
| IN-M-05 | N2 | `\left(x^{2}-1\right)e^{x}<0` | `(-1,1)` |
| IN-M-06 | N2 | `\frac{e^{x}-1}{x}>0` | `\mathbb{R}\setminus\{0\}` |
| IN-M-07 | N3 | `x\ln x-x+1\ge 0` | `(0,\infty)` |
| IN-M-08 | N2 | `\ln x<\sqrt{x}` | `(0,\infty)` |
| IN-M-09 | N2 | `\sqrt{x}\,\ln x<0` | `(0,1)` |

### 3.T Con trigonométricas e hiperbólicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IN-T-01 | N2 | `\ln(\sin x)<0,\quad x\in(0,\pi)` | `\left(0,\frac{\pi}{2}\right)\cup\left(\frac{\pi}{2},\pi\right)` |
| IN-T-02 | N2 | `e^{\cos x}>1,\quad x\in[0,2\pi]` | `\left[0,\frac{\pi}{2}\right)\cup\left(\frac{3\pi}{2},2\pi\right]` |
| IN-T-03 | N2 | `\sqrt{\cos x}\ge\frac{\sqrt{2}}{2},\quad x\in[-\pi,\pi]` | `\left[-\frac{\pi}{3},\frac{\pi}{3}\right]` |
| IN-T-04 | N2 | `e^{x}\sin x>0,\quad x\in(0,2\pi)` | `(0,\pi)` |
| IN-T-05 | N3 | `\sqrt{\lvert\sin x\rvert}<\frac{1}{2},\quad x\in[0,2\pi)` | `\left[0,a\right)\cup\left(\pi-a,\pi+a\right)\cup\left(2\pi-a,2\pi\right),\ a=\arcsin\frac{1}{4}` |
| IN-T-06 | N2 | `\ln(\cosh x)<\ln 2` | `\left(-\ln\left(2+\sqrt{3}\right),\ln\left(2+\sqrt{3}\right)\right)` |
| IN-T-07 | N2 | `\arctan\left(e^{x}\right)>\frac{\pi}{4}` | `(0,\infty)` |

---

## 4. Límites

Incluye formas $0/0$, $\infty/\infty$, $\infty-\infty$, $0\cdot\infty$, $1^{\infty}$, $0^{0}$, $\infty^{0}$, laterales, en el infinito, sucesiones, paramétricos y multivariable.

### 4.L Logarítmicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| LM-L-01 | N1 | `\lim_{x\to 0}\frac{\ln(1+x)}{x}` | `1` |
| LM-L-02 | N1 | `\lim_{x\to 0}\frac{\ln(1+3x)}{x}` | `3` |
| LM-L-03 | N1 | `\lim_{x\to 1}\frac{\ln x}{x-1}` | `1` |
| LM-L-04 | N2 | `\lim_{x\to 0}\frac{x-\ln(1+x)}{x^{2}}` | `\frac{1}{2}` |
| LM-L-05 | N1 | `\lim_{x\to 0^{+}}\ln x` | `-\infty` |
| LM-L-06 | N1 | `\lim_{x\to 0}\ln\lvert x\rvert` | `-\infty` |
| LM-L-07 | N1 | `\lim_{x\to\infty}\frac{\ln x}{x}` | `0` |
| LM-L-08 | N2 | `\lim_{x\to\infty}\frac{\ln x}{\sqrt{x}}` | `0` |
| LM-L-09 | N2 | `\lim_{x\to\infty}\frac{\ln\left(x^{2}+1\right)}{\ln x}` | `2` |
| LM-L-10 | N2 | `\lim_{x\to 0^{+}}x\ln x` | `0` |
| LM-L-11 | N2 | `\lim_{x\to\infty}\left(\ln(x+1)-\ln x\right)` | `0` |
| LM-L-12 | N3 | `\lim_{x\to 1}\left(\frac{1}{\ln x}-\frac{1}{x-1}\right)` | `\frac{1}{2}` |
| LM-L-13 | N3 | `\lim_{x\to 0^{+}}\left(\frac{1}{x}-\frac{1}{\ln(1+x)}\right)` | `-\frac{1}{2}` |
| LM-L-14 | N2 | `\lim_{x\to\infty}\frac{\ln\left(1+e^{x}\right)}{x}` | `1` |
| LM-L-15 | N2 | `\lim_{x\to-\infty}\frac{\ln\left(1+e^{x}\right)}{e^{x}}` | `1` |

### 4.E Exponenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| LM-E-01 | N1 | `\lim_{x\to 0}\frac{e^{x}-1}{x}` | `1` |
| LM-E-02 | N1 | `\lim_{x\to 0}\frac{a^{x}-1}{x},\ a>0` | `\ln a` |
| LM-E-03 | N2 | `\lim_{x\to 0}\frac{e^{2x}-1}{\ln(1+3x)}` | `\frac{2}{3}` |
| LM-E-04 | N2 | `\lim_{x\to 0}\frac{e^{x}-1-x}{x^{2}}` | `\frac{1}{2}` |
| LM-E-05 | N2 | `\lim_{x\to 0}\frac{a^{x}-b^{x}}{x},\ a,b>0` | `\ln a-\ln b` |
| LM-E-06 | N1 | `\lim_{x\to-\infty}e^{x}` | `0` |
| LM-E-07 | N2 | `\lim_{x\to\infty}\frac{x^{100}}{e^{x}}` | `0` |
| LM-E-08 | N2 | `\lim_{x\to\infty}\frac{e^{x}}{x^{100}}` | `+\infty` |
| LM-E-09 | N2 | `\lim_{x\to\infty}\frac{2^{x}+3^{x}}{3^{x}+4^{x}}` | `0` |
| LM-E-10 | N2 | `\lim_{x\to\infty}\left(x-\ln\left(e^{x}+1\right)\right)` | `0` |
| LM-E-11 | N2 | `\lim_{x\to\infty}x\left(e^{1/x}-1\right)` | `1` |
| LM-E-12 | N3 | `\lim_{x\to\infty}x^{2}\left(e^{1/x}-1-\frac{1}{x}\right)` | `\frac{1}{2}` |
| LM-E-13 | N2 | `\lim_{x\to 0^{+}}e^{-1/x}` | `0` |
| LM-E-14 | N2 | `\lim_{x\to 0^{-}}e^{-1/x}` | `+\infty` |
| LM-E-15 | N2 | `\lim_{x\to 0}e^{-1/x}` | no existe (laterales distintos) |
| LM-E-16 | N2 | `\lim_{x\to 0}e^{-1/x^{2}}` | `0` |
| LM-E-17 | N3 | `\lim_{x\to 0}\frac{e^{-1/x^{2}}}{x^{10}}` | `0` |

### 4.R Radicales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| LM-R-01 | N1 | `\lim_{x\to 0}\frac{\sqrt{1+x}-1}{x}` | `\frac{1}{2}` |
| LM-R-02 | N1 | `\lim_{x\to 0}\frac{\sqrt[3]{1+x}-1}{x}` | `\frac{1}{3}` |
| LM-R-03 | N1 | `\lim_{x\to 4}\frac{\sqrt{x}-2}{x-4}` | `\frac{1}{4}` |
| LM-R-04 | N2 | `\lim_{x\to 8}\frac{\sqrt[3]{x}-2}{x-8}` | `\frac{1}{12}` |
| LM-R-05 | N2 | `\lim_{x\to 0}\frac{\sqrt{1+x}-\sqrt{1-x}}{x}` | `1` |
| LM-R-06 | N3 | `\lim_{x\to 0}\frac{\sqrt{1+x}-1-\frac{x}{2}}{x^{2}}` | `-\frac{1}{8}` |
| LM-R-07 | N2 | `\lim_{x\to\infty}\left(\sqrt{x^{2}+x}-x\right)` | `\frac{1}{2}` |
| LM-R-08 | N2 | `\lim_{x\to\infty}\left(\sqrt{x^{2}+1}-\sqrt{x^{2}-1}\right)` | `0` |
| LM-R-09 | N3 | `\lim_{x\to\infty}\left(\sqrt{x+\sqrt{x}}-\sqrt{x}\right)` | `\frac{1}{2}` |
| LM-R-10 | N3 | `\lim_{x\to\infty}\left(\sqrt[3]{x^{3}+x^{2}}-x\right)` | `\frac{1}{3}` |
| LM-R-11 | N2 | `\lim_{x\to\infty}\frac{\sqrt{x^{2}+1}}{x}` | `1` |
| LM-R-12 | N2 | `\lim_{x\to-\infty}\frac{\sqrt{x^{2}+1}}{x}` | `-1` (trampa de signo) |
| LM-R-13 | N3 | `\lim_{x\to-\infty}\frac{\sqrt{4x^{2}+x}}{x+1}` | `-2` |
| LM-R-14 | N2 | `\lim_{x\to 0^{+}}\sqrt{x}\,\ln x` | `0` |
| LM-R-15 | N2 | `\lim_{x\to 0}\frac{\lvert x\rvert}{x}` | no existe (laterales `-1` y `1`) |

### 4.M Mixtas y formas indeterminadas $1^{\infty}$, $0^{0}$, $\infty^{0}$

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| LM-M-01 | N1 | `\lim_{x\to\infty}\left(1+\frac{1}{x}\right)^{x}` | `e` |
| LM-M-02 | N1 | `\lim_{x\to 0}(1+x)^{1/x}` | `e` |
| LM-M-03 | N2 | `\lim_{x\to\infty}\left(1+\frac{a}{x}\right)^{x}` | `e^{a}` |
| LM-M-04 | N2 | `\lim_{x\to\infty}\left(\frac{x+1}{x-1}\right)^{x}` | `e^{2}` |
| LM-M-05 | N3 | `\lim_{x\to\infty}\left(\frac{x^{2}+1}{x^{2}-1}\right)^{x^{2}}` | `e^{2}` |
| LM-M-06 | N2 | `\lim_{x\to\infty}\left(1+\frac{1}{x^{2}}\right)^{x}` | `1` |
| LM-M-07 | N2 | `\lim_{x\to 0^{+}}x^{x}` | `1` |
| LM-M-08 | N2 | `\lim_{x\to 0^{+}}x^{\sin x}` | `1` |
| LM-M-09 | N2 | `\lim_{x\to\infty}x^{1/x}` | `1` |
| LM-M-10 | N3 | `\lim_{x\to 0}\left(\frac{a^{x}+b^{x}}{2}\right)^{1/x},\ a,b>0` | `\sqrt{ab}` |
| LM-M-11 | N3 | `\lim_{x\to\infty}\left(\frac{a^{1/x}+b^{1/x}}{2}\right)^{x},\ a,b>0` | `\sqrt{ab}` |
| LM-M-12 | N2 | `\lim_{n\to\infty}\sqrt[n]{n}` | `1` |
| LM-M-13 | N3 | `\lim_{n\to\infty}\frac{\sqrt[n]{n!}}{n}` | `\frac{1}{e}` |
| LM-M-14 | N2 | `\lim_{x\to\infty}\frac{3^{x}+2^{x}}{3^{x}-2^{x}}` | `1` |
| LM-M-15 | N2 | `\lim_{h\to 0}\frac{\ln(x+h)-\ln x}{h},\ x>0` | `\frac{1}{x}` |
| LM-M-16 | N2 | `\lim_{h\to 0}\frac{\sqrt{x+h}-\sqrt{x}}{h},\ x>0` | `\frac{1}{2\sqrt{x}}` |
| LM-M-17 | N1 | `\lim_{x\to 0}\frac{1}{x}` | no existe (laterales `-\infty` y `+\infty`) |
| LM-M-18 | N1 | `\lim_{x\to 0}\frac{1}{x^{2}}` | `+\infty` |

### 4.T Con trigonométricas e hiperbólicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| LM-T-01 | N1 | `\lim_{x\to 0}\frac{e^{\sin x}-1}{x}` | `1` |
| LM-T-02 | N2 | `\lim_{x\to 0}\frac{\ln(\cos x)}{x^{2}}` | `-\frac{1}{2}` |
| LM-T-03 | N2 | `\lim_{x\to 0}\frac{e^{x^{2}}-\cos x}{x^{2}}` | `\frac{3}{2}` |
| LM-T-04 | N2 | `\lim_{x\to 0}\frac{\ln(1+\tan x)}{\sin 2x}` | `\frac{1}{2}` |
| LM-T-05 | N2 | `\lim_{x\to 0}\frac{\sqrt{1+\sin x}-\sqrt{1-\sin x}}{x}` | `1` |
| LM-T-06 | N3 | `\lim_{x\to 0}\frac{e^{x}-e^{\sin x}}{x-\sin x}` | `1` |
| LM-T-07 | N2 | `\lim_{x\to 0}\frac{\sqrt{1+x^{2}}-\cos x}{x^{2}}` | `1` |
| LM-T-08 | N3 | `\lim_{x\to 0}(\cos x)^{1/x^{2}}` | `e^{-1/2}` |
| LM-T-09 | N3 | `\lim_{x\to 0}\left(\frac{\sin x}{x}\right)^{1/x^{2}}` | `e^{-1/6}` |
| LM-T-10 | N3 | `\lim_{x\to\infty}\left(\cos\frac{1}{x}\right)^{x^{2}}` | `e^{-1/2}` |
| LM-T-11 | N3 | `\lim_{x\to\frac{\pi}{4}}(\tan x)^{\tan 2x}` | `e^{-1}` |
| LM-T-12 | N3 | `\lim_{x\to\frac{\pi}{2}}(\sin x)^{\tan x}` | `1` |
| LM-T-13 | N2 | `\lim_{x\to 0^{+}}(\sin x)^{\tan x}` | `1` |
| LM-T-14 | N2 | `\lim_{x\to 0}\left(\frac{1}{x}-\frac{1}{e^{x}-1}\right)` | `\frac{1}{2}` |
| LM-T-15 | N2 | `\lim_{x\to\frac{\pi}{2}^{-}}(\sec x-\tan x)` | `0` |
| LM-T-16 | N2 | `\lim_{x\to\infty}e^{-x}\sin x` | `0` |
| LM-T-17 | N2 | `\lim_{x\to\infty}\frac{\sin x}{\ln x}` | `0` |
| LM-T-18 | N2 | `\lim_{x\to\infty}\arctan(\ln x)` | `\frac{\pi}{2}` |
| LM-T-19 | N2 | `\lim_{x\to\infty}\left(\operatorname{arsinh}x-\ln x\right)` | `\ln 2` |
| LM-T-20 | N1 | `\lim_{x\to 0}\sin\frac{1}{x}` | no existe |

### 4.V Multivariable

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| LM-V-01 | N2 | `\lim_{(x,y)\to(0,0)}\frac{x^{2}y}{x^{2}+y^{2}}` | `0` |
| LM-V-02 | N2 | `\lim_{(x,y)\to(0,0)}\frac{xy}{x^{2}+y^{2}}` | no existe (depende de la trayectoria) |
| LM-V-03 | N2 | `\lim_{(x,y)\to(0,0)}\frac{x^{2}-y^{2}}{x^{2}+y^{2}}` | no existe |
| LM-V-04 | N3 | `\lim_{(x,y)\to(0,0)}\frac{xy^{2}}{x^{2}+y^{4}}` | no existe (`0` por `y=0`; `\frac{1}{2}` por `x=y^{2}`) |
| LM-V-05 | N2 | `\lim_{(x,y)\to(0,0)}\frac{x^{3}+y^{3}}{x^{2}+y^{2}}` | `0` |
| LM-V-06 | N2 | `\lim_{(x,y)\to(0,0)}\frac{\ln\left(1+x^{2}y^{2}\right)}{x^{2}+y^{2}}` | `0` |
| LM-V-07 | N2 | `\lim_{(x,y)\to(0,0)}\left(x^{2}+y^{2}\right)\ln\left(x^{2}+y^{2}\right)` | `0` |
| LM-V-08 | N2 | `\lim_{(x,y)\to(0,0)}\frac{\sqrt{x^{2}+y^{2}+1}-1}{x^{2}+y^{2}}` | `\frac{1}{2}` |
| LM-V-09 | N2 | `\lim_{(x,y)\to(0,0)}\frac{e^{x+y}-1}{x+y}` | `1` |

---

## 5. Derivadas

### 5.L Logarítmicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| DV-L-01 | N1 | `\frac{d}{dx}\ln x` | `\frac{1}{x}` |
| DV-L-02 | N1 | `\frac{d}{dx}\log_{a}x` | `\frac{1}{x\ln a}` |
| DV-L-03 | N1 | `\frac{d}{dx}\ln\left(x^{2}+1\right)` | `\frac{2x}{x^{2}+1}` |
| DV-L-04 | N1 | `\frac{d}{dx}\ln\lvert x\rvert` | `\frac{1}{x}` |
| DV-L-05 | N2 | `\frac{d}{dx}\ln(\ln x)` | `\frac{1}{x\ln x}` |
| DV-L-06 | N2 | `\frac{d}{dx}\left(x\ln x-x\right)` | `\ln x` |
| DV-L-07 | N2 | `\frac{d}{dx}\ln\left(\frac{1+x}{1-x}\right)` | `\frac{2}{1-x^{2}}` |
| DV-L-08 | N2 | `\frac{d}{dx}\log_{2}(3x+1)` | `\frac{3}{(3x+1)\ln 2}` |
| DV-L-09 | N2 | `\frac{d}{dx}\frac{\ln x}{x}` | `\frac{1-\ln x}{x^{2}}` |
| DV-L-10 | N2 | `\frac{d}{dx}\ln\left(x+\sqrt{x^{2}+1}\right)` | `\frac{1}{\sqrt{x^{2}+1}}` |
| DV-L-11 | N2 | `\frac{d}{dx}\ln\left(x+\sqrt{x^{2}-1}\right)` | `\frac{1}{\sqrt{x^{2}-1}}` |
| DV-L-12 | N2 | `\frac{d^{2}}{dx^{2}}\ln x` | `-\frac{1}{x^{2}}` |
| DV-L-13 | N2 | `\frac{d^{2}}{dx^{2}}\left(x\ln x\right)` | `\frac{1}{x}` |
| DV-L-14 | N2 | `\left.\frac{d}{dx}\ln\left(x^{2}+1\right)\right\rvert_{x=1}` | `1` |

### 5.E Exponenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| DV-E-01 | N1 | `\frac{d}{dx}e^{x}` | `e^{x}` |
| DV-E-02 | N1 | `\frac{d}{dx}a^{x}` | `a^{x}\ln a` |
| DV-E-03 | N1 | `\frac{d}{dx}e^{x^{2}}` | `2xe^{x^{2}}` |
| DV-E-04 | N1 | `\frac{d}{dx}\left(xe^{-x}\right)` | `(1-x)e^{-x}` |
| DV-E-05 | N2 | `\frac{d}{dx}2^{x^{2}}` | `2x\cdot 2^{x^{2}}\ln 2` |
| DV-E-06 | N2 | `\frac{d}{dx}e^{e^{x}}` | `e^{x}e^{e^{x}}` |
| DV-E-07 | N2 | `\frac{d}{dx}\frac{e^{x}}{1+e^{x}}` | `\frac{e^{x}}{\left(1+e^{x}\right)^{2}}` |
| DV-E-08 | N2 | `\frac{d}{dx}e^{-x^{2}/2}` | `-xe^{-x^{2}/2}` |
| DV-E-09 | N2 | `\frac{d}{dx}\ln\left(e^{x}+e^{-x}\right)` | `\tanh x` |
| DV-E-10 | N3 | `\frac{d^{3}}{dx^{3}}\left(x^{2}e^{x}\right)` | `e^{x}\left(x^{2}+6x+6\right)` |
| DV-E-11 | N2 | `\frac{d^{n}}{dx^{n}}e^{ax}` | `a^{n}e^{ax}` |
| DV-E-12 | N3 | `\frac{d^{n}}{dx^{n}}\ln x` | `\frac{(-1)^{n-1}(n-1)!}{x^{n}}` |

### 5.R Radicales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| DV-R-01 | N1 | `\frac{d}{dx}\sqrt{x}` | `\frac{1}{2\sqrt{x}}` |
| DV-R-02 | N1 | `\frac{d}{dx}\sqrt[3]{x}` | `\frac{1}{3x^{2/3}}` |
| DV-R-03 | N1 | `\frac{d}{dx}\sqrt{x^{2}+1}` | `\frac{x}{\sqrt{x^{2}+1}}` |
| DV-R-04 | N1 | `\frac{d}{dx}\sqrt{1-x^{2}}` | `-\frac{x}{\sqrt{1-x^{2}}}` |
| DV-R-05 | N2 | `\frac{d}{dx}\left(x\sqrt{x}\right)` | `\frac{3}{2}\sqrt{x}` |
| DV-R-06 | N2 | `\frac{d}{dx}\sqrt[3]{x^{2}}` | `\frac{2}{3\sqrt[3]{x}}` |
| DV-R-07 | N3 | `\frac{d}{dx}\sqrt{x+\sqrt{x}}` | `\frac{2\sqrt{x}+1}{4\sqrt{x}\sqrt{x+\sqrt{x}}}` |
| DV-R-08 | N3 | `\frac{d}{dx}\sqrt{\frac{1-x}{1+x}}` | `-\frac{1}{(1+x)\sqrt{1-x^{2}}}` |
| DV-R-09 | N2 | `\frac{d}{dx}\sqrt{x^{2}}` | `\frac{x}{\lvert x\rvert}` (no `1`) |
| DV-R-10 | N2 | `\frac{d}{dx}\lvert x\rvert` | `\frac{x}{\lvert x\rvert}`, no existe en `x=0` |
| DV-R-11 | N2 | `\left.\frac{d}{dx}\sqrt{x}\right\rvert_{x=4}` | `\frac{1}{4}` |
| DV-R-12 | N2 | `\left.\frac{d}{dx}\sqrt[3]{x}\right\rvert_{x=0}` | `+\infty` (tangente vertical) |
| DV-R-13 | N2 | `\left.\frac{d}{dx}x^{2/3}\right\rvert_{x=0}` | no existe (cúspide) |

### 5.M Mixtas, potencial-exponencial, implícita y parciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| DV-M-01 | N2 | `\frac{d}{dx}\left(x^{2}\ln x\right)` | `2x\ln x+x` |
| DV-M-02 | N2 | `\frac{d}{dx}\sqrt{\ln x}` | `\frac{1}{2x\sqrt{\ln x}}` |
| DV-M-03 | N2 | `\frac{d}{dx}\ln\sqrt{x^{2}+1}` | `\frac{x}{x^{2}+1}` |
| DV-M-04 | N2 | `\frac{d}{dx}e^{\sqrt{x}}` | `\frac{e^{\sqrt{x}}}{2\sqrt{x}}` |
| DV-M-05 | N2 | `\frac{d}{dx}\sqrt{e^{x}+1}` | `\frac{e^{x}}{2\sqrt{e^{x}+1}}` |
| DV-M-06 | N2 | `\frac{d}{dx}\left(\sqrt{x}\,\ln x\right)` | `\frac{\ln x+2}{2\sqrt{x}}` |
| DV-M-07 | N2 | `\frac{d}{dx}x^{x}` | `x^{x}(\ln x+1)` |
| DV-M-08 | N2 | `\left.\frac{d}{dx}x^{x}\right\rvert_{x=1}` | `1` |
| DV-M-09 | N3 | `\frac{d}{dx}x^{x^{x}}` | `x^{x^{x}}\left(x^{x}(\ln x+1)\ln x+x^{x-1}\right)` |
| DV-M-10 | N3 | `\frac{d}{dx}\frac{x^{3}\sqrt{x+1}}{(x-2)^{2}}` | `\frac{x^{3}\sqrt{x+1}}{(x-2)^{2}}\left(\frac{3}{x}+\frac{1}{2(x+1)}-\frac{2}{x-2}\right)` |
| DV-M-11 | N3 | `x^{2}+y^{2}=e^{xy},\ \frac{dy}{dx}` | `\frac{ye^{xy}-2x}{2y-xe^{xy}}` |
| DV-M-12 | N2 | `\frac{\partial}{\partial x}x^{y}` | `yx^{y-1}` |
| DV-M-13 | N2 | `\frac{\partial}{\partial y}x^{y}` | `x^{y}\ln x` |
| DV-M-14 | N2 | `\frac{\partial^{2}}{\partial x\,\partial y}e^{xy}` | `(1+xy)e^{xy}` |
| DV-M-15 | N2 | `\lim_{h\to 0}\frac{e^{x+h}-e^{x}}{h}` | `e^{x}` |

### 5.T Con trigonométricas, hiperbólicas e inversas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| DV-T-01 | N1 | `\frac{d}{dx}\ln(\sin x)` | `\cot x` |
| DV-T-02 | N2 | `\frac{d}{dx}\ln\left(\tan\frac{x}{2}\right)` | `\csc x` |
| DV-T-03 | N2 | `\frac{d}{dx}\ln\left(\sec x+\tan x\right)` | `\sec x` |
| DV-T-04 | N1 | `\frac{d}{dx}\left(e^{x}\cos x\right)` | `e^{x}(\cos x-\sin x)` |
| DV-T-05 | N2 | `\frac{d}{dx}\left(x^{2}e^{x}\cos x\right)` | `e^{x}\left(\left(x^{2}+2x\right)\cos x-x^{2}\sin x\right)` |
| DV-T-06 | N2 | `\frac{d}{dx}e^{\sin x}` | `\cos x\,e^{\sin x}` |
| DV-T-07 | N2 | `\frac{d}{dx}\sqrt{1+\sin^{2}x}` | `\frac{\sin x\cos x}{\sqrt{1+\sin^{2}x}}` |
| DV-T-08 | N2 | `\frac{d}{dx}\arctan\left(e^{x}\right)` | `\frac{e^{x}}{1+e^{2x}}` |
| DV-T-09 | N2 | `\frac{d}{dx}\ln(\arctan x)` | `\frac{1}{\left(1+x^{2}\right)\arctan x}` |
| DV-T-10 | N2 | `\frac{d}{dx}x^{\sin x}` | `x^{\sin x}\left(\cos x\ln x+\frac{\sin x}{x}\right)` |
| DV-T-11 | N3 | `\frac{d}{dx}(\sin x)^{x}` | `(\sin x)^{x}\left(\ln(\sin x)+x\cot x\right)` |
| DV-T-12 | N2 | `\frac{d^{2}}{dx^{2}}\left(e^{x}\sin x\right)` | `2e^{x}\cos x` |
| DV-T-13 | N2 | `\left.\frac{d}{dx}\left(e^{x}\sin x\right)\right\rvert_{x=0}` | `1` |
| DV-T-14 | N2 | `\frac{d}{dx}\ln\left(\cosh x\right)` | `\tanh x` |
| DV-T-15 | N3 | `\frac{d}{dx}\operatorname{arsinh}\left(\sqrt{x}\right)` | `\frac{1}{2\sqrt{x(1+x)}}` |

---

## 6. Integrales indefinidas

### 6.L Logarítmicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IT-L-01 | N1 | `\int\ln x\,dx` | `x\ln x-x+C` |
| IT-L-02 | N1 | `\int\frac{dx}{x}` | `\ln\lvert x\rvert+C` |
| IT-L-03 | N2 | `\int(\ln x)^{2}\,dx` | `x(\ln x)^{2}-2x\ln x+2x+C` |
| IT-L-04 | N2 | `\int x\ln x\,dx` | `\frac{x^{2}}{2}\ln x-\frac{x^{2}}{4}+C` |
| IT-L-05 | N2 | `\int x^{2}\ln x\,dx` | `\frac{x^{3}}{3}\ln x-\frac{x^{3}}{9}+C` |
| IT-L-06 | N2 | `\int\frac{\ln x}{x}\,dx` | `\frac{1}{2}(\ln x)^{2}+C` |
| IT-L-07 | N2 | `\int\frac{dx}{x\ln x}` | `\ln\lvert\ln x\rvert+C` |
| IT-L-08 | N2 | `\int\frac{\ln x}{x^{2}}\,dx` | `-\frac{\ln x+1}{x}+C` |
| IT-L-09 | N2 | `\int\log_{2}x\,dx` | `\frac{x(\ln x-1)}{\ln 2}+C` |
| IT-L-10 | N2 | `\int\ln\left(x^{2}+1\right)dx` | `x\ln\left(x^{2}+1\right)-2x+2\arctan x+C` |
| IT-L-11 | N3 | `\int x^{n}\ln x\,dx,\ n\neq-1` | `\frac{x^{n+1}}{n+1}\left(\ln x-\frac{1}{n+1}\right)+C` |
| IT-L-12 | N2 | `\int\frac{dx}{x(1+\ln x)}` | `\ln\lvert 1+\ln x\rvert+C` |

### 6.E Exponenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IT-E-01 | N1 | `\int e^{x}\,dx` | `e^{x}+C` |
| IT-E-02 | N1 | `\int a^{x}\,dx` | `\frac{a^{x}}{\ln a}+C` |
| IT-E-03 | N1 | `\int e^{2x+1}\,dx` | `\frac{e^{2x+1}}{2}+C` |
| IT-E-04 | N2 | `\int xe^{x}\,dx` | `(x-1)e^{x}+C` |
| IT-E-05 | N2 | `\int x^{2}e^{x}\,dx` | `\left(x^{2}-2x+2\right)e^{x}+C` |
| IT-E-06 | N2 | `\int x^{3}e^{-x}\,dx` | `-e^{-x}\left(x^{3}+3x^{2}+6x+6\right)+C` |
| IT-E-07 | N2 | `\int xe^{x^{2}}\,dx` | `\frac{e^{x^{2}}}{2}+C` |
| IT-E-08 | N2 | `\int\frac{e^{x}}{1+e^{x}}\,dx` | `\ln\left(1+e^{x}\right)+C` |
| IT-E-09 | N2 | `\int\frac{dx}{1+e^{x}}` | `x-\ln\left(1+e^{x}\right)+C` |
| IT-E-10 | N2 | `\int\frac{dx}{e^{x}+e^{-x}}` | `\arctan\left(e^{x}\right)+C` |
| IT-E-11 | N2 | `\int\frac{e^{2x}}{e^{x}+1}\,dx` | `e^{x}-\ln\left(e^{x}+1\right)+C` |
| IT-E-12 | N2 | `\int\frac{e^{x}}{\sqrt{e^{x}-1}}\,dx` | `2\sqrt{e^{x}-1}+C` |
| IT-E-13 | N2 | `\int e^{e^{x}}e^{x}\,dx` | `e^{e^{x}}+C` |
| IT-E-14 | N3 | `\int e^{\sqrt{x}}\,dx` | `2\left(\sqrt{x}-1\right)e^{\sqrt{x}}+C` |
| IT-E-15 | N3 | `\int e^{ax}\sin(bx)\,dx` | `\frac{e^{ax}\left(a\sin bx-b\cos bx\right)}{a^{2}+b^{2}}+C` |

### 6.R Radicales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IT-R-01 | N1 | `\int\sqrt{x}\,dx` | `\frac{2}{3}x^{3/2}+C` |
| IT-R-02 | N1 | `\int\frac{dx}{\sqrt{x}}` | `2\sqrt{x}+C` |
| IT-R-03 | N1 | `\int\sqrt[3]{x}\,dx` | `\frac{3}{4}x^{4/3}+C` |
| IT-R-04 | N2 | `\int x\sqrt{x+1}\,dx` | `\frac{2}{5}(x+1)^{5/2}-\frac{2}{3}(x+1)^{3/2}+C` |
| IT-R-05 | N2 | `\int\frac{x}{\sqrt{x+1}}\,dx` | `\frac{2}{3}(x+1)^{3/2}-2\sqrt{x+1}+C` |
| IT-R-06 | N2 | `\int\frac{dx}{\sqrt{x}+1}` | `2\sqrt{x}-2\ln\left(\sqrt{x}+1\right)+C` |
| IT-R-07 | N2 | `\int\frac{dx}{\sqrt{x}\,(1+x)}` | `2\arctan\sqrt{x}+C` |
| IT-R-08 | N2 | `\int\frac{dx}{x+\sqrt{x}}` | `2\ln\left(\sqrt{x}+1\right)+C` |
| IT-R-09 | N2 | `\int\frac{x}{\sqrt{x^{2}+1}}\,dx` | `\sqrt{x^{2}+1}+C` |
| IT-R-10 | N2 | `\int\sqrt{1-x^{2}}\,dx` | `\frac{1}{2}\left(x\sqrt{1-x^{2}}+\arcsin x\right)+C` |
| IT-R-11 | N2 | `\int\sqrt{x^{2}+1}\,dx` | `\frac{1}{2}\left(x\sqrt{x^{2}+1}+\operatorname{arsinh}x\right)+C` |
| IT-R-12 | N2 | `\int\sqrt{x^{2}-1}\,dx,\ x>1` | `\frac{1}{2}\left(x\sqrt{x^{2}-1}-\operatorname{arcosh}x\right)+C` |
| IT-R-13 | N2 | `\int\frac{dx}{\sqrt{x^{2}-2x+5}}` | `\operatorname{arsinh}\frac{x-1}{2}+C` |
| IT-R-14 | N2 | `\int\frac{dx}{\sqrt{-x^{2}+2x+3}}` | `\arcsin\frac{x-1}{2}+C` |
| IT-R-15 | N3 | `\int\sqrt{\frac{1-x}{1+x}}\,dx` | `\arcsin x+\sqrt{1-x^{2}}+C` |

### 6.M Mixtas (log, exp, radicales, polinomios, racionales)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IT-M-01 | N2 | `\int\sqrt{x}\,\ln x\,dx` | `\frac{2}{3}x^{3/2}\ln x-\frac{4}{9}x^{3/2}+C` |
| IT-M-02 | N2 | `\int\frac{\ln x}{\sqrt{x}}\,dx` | `2\sqrt{x}\ln x-4\sqrt{x}+C` |
| IT-M-03 | N3 | `\int\ln\left(\sqrt{x}+1\right)dx` | `\left(x-1\right)\ln\left(\sqrt{x}+1\right)-\frac{x}{2}+\sqrt{x}+C` |
| IT-M-04 | N2 | `\int\frac{x}{x^{2}+1}\,dx` | `\frac{1}{2}\ln\left(x^{2}+1\right)+C` |
| IT-M-05 | N2 | `\int\frac{x^{3}}{x^{2}+1}\,dx` | `\frac{x^{2}}{2}-\frac{1}{2}\ln\left(x^{2}+1\right)+C` |
| IT-M-06 | N2 | `\int\frac{dx}{x^{2}-1}` | `\frac{1}{2}\ln\left\lvert\frac{x-1}{x+1}\right\rvert+C` |
| IT-M-07 | N2 | `\int\frac{dx}{x\left(x^{2}+1\right)}` | `\ln\lvert x\rvert-\frac{1}{2}\ln\left(x^{2}+1\right)+C` |
| IT-M-08 | N3 | `\int\frac{2x+3}{x^{2}+2x+5}\,dx` | `\ln\left(x^{2}+2x+5\right)+\frac{1}{2}\arctan\frac{x+1}{2}+C` |
| IT-M-09 | N3 | `\int\frac{x^{2}+1}{x^{4}+1}\,dx` | `\frac{1}{\sqrt{2}}\arctan\frac{x^{2}-1}{\sqrt{2}\,x}+C` (discontinuidad en `x=0`) |
| IT-M-10 | N2 | `\int\frac{dx}{1+\sqrt{x}}` | `2\sqrt{x}-2\ln\left(1+\sqrt{x}\right)+C` |

### 6.T Con trigonométricas, hiperbólicas e inversas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IT-T-01 | N2 | `\int e^{x}\sin x\,dx` | `\frac{e^{x}(\sin x-\cos x)}{2}+C` |
| IT-T-02 | N2 | `\int e^{x}\cos x\,dx` | `\frac{e^{x}(\sin x+\cos x)}{2}+C` |
| IT-T-03 | N3 | `\int\sin(\ln x)\,dx` | `\frac{x\left(\sin(\ln x)-\cos(\ln x)\right)}{2}+C` |
| IT-T-04 | N3 | `\int\cos(\ln x)\,dx` | `\frac{x\left(\sin(\ln x)+\cos(\ln x)\right)}{2}+C` |
| IT-T-05 | N2 | `\int\frac{\cos\sqrt{x}}{\sqrt{x}}\,dx` | `2\sin\sqrt{x}+C` |
| IT-T-06 | N2 | `\int\tan x\,\ln(\cos x)\,dx` | `-\frac{1}{2}\left(\ln(\cos x)\right)^{2}+C` |
| IT-T-07 | N2 | `\int\frac{\sin x}{\sqrt{1+\cos x}}\,dx` | `-2\sqrt{1+\cos x}+C` |
| IT-T-08 | N3 | `\int\arctan\sqrt{x}\,dx` | `(x+1)\arctan\sqrt{x}-\sqrt{x}+C` |
| IT-T-09 | N2 | `\int\frac{\cos x}{1+\sin^{2}x}\,dx` | `\arctan(\sin x)+C` |
| IT-T-10 | N2 | `\int\frac{\arcsin x}{\sqrt{1-x^{2}}}\,dx` | `\frac{1}{2}\arcsin^{2}x+C` |
| IT-T-11 | N2 | `\int e^{x}\cosh x\,dx` | `\frac{e^{2x}}{4}+\frac{x}{2}+C` |
| IT-T-12 | N3 | `\int\operatorname{arsech}x\,dx,\ 0<x<1` | `x\operatorname{arsech}x+\arcsin x+C` |

### 6.S No elementales (el motor debe devolver una función especial o declararlo)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| IT-S-01 | N3 | `\int e^{-x^{2}}\,dx` | `\frac{\sqrt{\pi}}{2}\operatorname{erf}(x)+C` |
| IT-S-02 | N3 | `\int\frac{\sin x}{x}\,dx` | `\operatorname{Si}(x)+C` |
| IT-S-03 | N3 | `\int\frac{e^{x}}{x}\,dx` | `\operatorname{Ei}(x)+C` |
| IT-S-04 | N3 | `\int\frac{dx}{\ln x}` | `\operatorname{li}(x)+C` |
| IT-S-05 | N3 | `\int\sin\left(x^{2}\right)dx` | `\sqrt{\frac{\pi}{2}}\,S\!\left(\sqrt{\frac{2}{\pi}}\,x\right)+C` (Fresnel) |
| IT-S-06 | N3 | `\int x^{x}\,dx` | sin forma cerrada elemental (declararlo; no inventar una) |
| IT-S-07 | N3 | `\int\sqrt{1+x^{3}}\,dx` | sin forma elemental (hipergeométrica) |

---

## 7. Integrales definidas e impropias

### 7.L Logarítmicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ID-L-01 | N1 | `\int_{1}^{e}\ln x\,dx` | `1` |
| ID-L-02 | N1 | `\int_{1}^{e}\frac{dx}{x}` | `1` |
| ID-L-03 | N2 | `\int_{0}^{1}\ln(1+x)\,dx` | `2\ln 2-1\approx 0.386294361` |
| ID-L-04 | N2 | `\int_{1}^{e}(\ln x)^{2}\,dx` | `e-2\approx 0.718281828` |
| ID-L-05 | N2 | `\int_{1}^{2}\frac{\ln x}{x}\,dx` | `\frac{1}{2}(\ln 2)^{2}\approx 0.240226507` |
| ID-L-06 | N2 | `\int_{0}^{1}\ln x\,dx` | `-1` (impropia) |
| ID-L-07 | N2 | `\int_{0}^{1}x\ln x\,dx` | `-\frac{1}{4}` (impropia) |
| ID-L-08 | N2 | `\int_{0}^{1}(\ln x)^{2}\,dx` | `2` (impropia) |
| ID-L-09 | N3 | `\int_{0}^{1}\frac{\ln(1+x)}{x}\,dx` | `\frac{\pi^{2}}{12}` |
| ID-L-10 | N3 | `\int_{0}^{1}\frac{\ln x}{1-x}\,dx` | `-\frac{\pi^{2}}{6}` |
| ID-L-11 | N3 | `\int_{0}^{1}\frac{x-1}{\ln x}\,dx` | `\ln 2\approx 0.693147181` |
| ID-L-12 | N3 | `\int_{0}^{\infty}\frac{\ln x}{1+x^{2}}\,dx` | `0` |
| ID-L-13 | N3 | `\int_{2}^{10}\frac{dx}{\ln x}` | `\operatorname{li}(10)-\operatorname{li}(2)\approx 5.120435725` |

### 7.E Exponenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ID-E-01 | N1 | `\int_{0}^{1}e^{x}\,dx` | `e-1\approx 1.718281828` |
| ID-E-02 | N1 | `\int_{0}^{1}xe^{x}\,dx` | `1` |
| ID-E-03 | N2 | `\int_{0}^{1}x^{2}e^{x}\,dx` | `e-2` |
| ID-E-04 | N1 | `\int_{0}^{\infty}e^{-x}\,dx` | `1` |
| ID-E-05 | N2 | `\int_{0}^{\infty}x^{2}e^{-x}\,dx` | `2` |
| ID-E-06 | N2 | `\int_{0}^{\infty}x^{n}e^{-x}\,dx,\ n\in\mathbb{N}` | `n!` |
| ID-E-07 | N2 | `\int_{0}^{\infty}x^{s-1}e^{-x}\,dx,\ s>0` | `\Gamma(s)` |
| ID-E-08 | N2 | `\int_{0}^{\infty}e^{-x^{2}}\,dx` | `\frac{\sqrt{\pi}}{2}` |
| ID-E-09 | N2 | `\int_{-\infty}^{\infty}e^{-x^{2}/2}\,dx` | `\sqrt{2\pi}` |
| ID-E-10 | N2 | `\int_{0}^{\infty}xe^{-x^{2}}\,dx` | `\frac{1}{2}` |
| ID-E-11 | N2 | `\int_{-1}^{1}e^{-\lvert x\rvert}\,dx` | `2\left(1-e^{-1}\right)\approx 1.264241118` |
| ID-E-12 | N3 | `\int_{0}^{\infty}\frac{x}{e^{x}-1}\,dx` | `\frac{\pi^{2}}{6}` |
| ID-E-13 | N3 | `\int_{0}^{\infty}\frac{x^{2}}{e^{x}-1}\,dx` | `2\zeta(3)\approx 2.404113806` |
| ID-E-14 | N3 | `\int_{0}^{\infty}\frac{x}{e^{x}+1}\,dx` | `\frac{\pi^{2}}{12}` |
| ID-E-15 | N3 | `\int_{0}^{\infty}\frac{e^{-x}-e^{-2x}}{x}\,dx` | `\ln 2` |
| ID-E-16 | N3 | `\int_{0}^{\infty}e^{-x}\ln x\,dx` | `-\gamma\approx -0.577215665` |
| ID-E-17 | N3 | `\int_{0}^{1}x^{-x}\,dx` | `\approx 1.291285997` (sin forma cerrada; suma `\sum n^{-n}`) |
| ID-E-18 | N3 | `\int_{0}^{1}x^{x}\,dx` | `\approx 0.783430511` |

### 7.R Radicales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ID-R-01 | N1 | `\int_{0}^{4}\sqrt{x}\,dx` | `\frac{16}{3}` |
| ID-R-02 | N1 | `\int_{0}^{8}\sqrt[3]{x}\,dx` | `12` |
| ID-R-03 | N2 | `\int_{-8}^{8}\sqrt[3]{x}\,dx` | `0` |
| ID-R-04 | N2 | `\int_{0}^{1}\frac{dx}{\sqrt{x}}` | `2` (impropia) |
| ID-R-05 | N2 | `\int_{0}^{1}\frac{dx}{\sqrt{1-x}}` | `2` (impropia) |
| ID-R-06 | N2 | `\int_{-1}^{1}\frac{dx}{\sqrt[3]{x^{2}}}` | `6` (impropia en el interior) |
| ID-R-07 | N2 | `\int_{0}^{1}\sqrt{1-x^{2}}\,dx` | `\frac{\pi}{4}` |
| ID-R-08 | N2 | `\int_{0}^{2}x\sqrt{4-x^{2}}\,dx` | `\frac{8}{3}` |
| ID-R-09 | N2 | `\int_{0}^{3}\frac{x}{\sqrt{x+1}}\,dx` | `\frac{8}{3}` |
| ID-R-10 | N2 | `\int_{0}^{4}\frac{dx}{1+\sqrt{x}}` | `4-2\ln 3\approx 1.802775423` |
| ID-R-11 | N2 | `\int_{0}^{1}\sqrt{1+x^{2}}\,dx` | `\frac{\sqrt{2}+\ln\left(1+\sqrt{2}\right)}{2}\approx 1.147793575` |
| ID-R-12 | N2 | `\int_{1}^{\infty}\frac{dx}{x^{2}}` | `1` |
| ID-R-13 | N2 | `\int_{1}^{\infty}\frac{dx}{\sqrt{x}}` | diverge |
| ID-R-14 | N3 | `\int_{1}^{\infty}\frac{dx}{x^{p}}` | `\frac{1}{p-1}` si `p>1`; diverge si `p\le 1` |
| ID-R-15 | N3 | `\int_{0}^{1}\frac{dx}{x^{p}}` | `\frac{1}{1-p}` si `p<1`; diverge si `p\ge 1` |
| ID-R-16 | N3 | `\int_{0}^{1}\sqrt{x(1-x)}\,dx` | `\frac{\pi}{8}` |
| ID-R-17 | N3 | `\int_{0}^{1}\frac{dx}{\sqrt{x(1-x)}}` | `\pi` |
| ID-R-18 | N3 | `\int_{0}^{\infty}\sqrt{x}\,e^{-x}\,dx` | `\frac{\sqrt{\pi}}{2}` |
| ID-R-19 | N3 | `\int_{-2}^{2}\left\lvert x^{2}-1\right\rvert dx` | `4` |
| ID-R-20 | N3 | `\int_{0}^{\pi}\sqrt{1-\cos 2x}\,dx` | `2\sqrt{2}` (usa `\lvert\sin x\rvert`) |
| ID-R-21 | N3 | `\int_{0}^{2\pi}\sqrt{1-\cos x}\,dx` | `4\sqrt{2}` |

### 7.M Mixtas y con trigonométricas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ID-M-01 | N2 | `\int_{1}^{e}\sqrt{x}\,\ln x\,dx` | `\frac{2}{9}e^{3/2}+\frac{4}{9}\approx 1.440375349` |
| ID-M-02 | N2 | `\int_{0}^{1}\arctan\sqrt{x}\,dx` | `\frac{\pi}{2}-1\approx 0.570796327` |
| ID-M-03 | N2 | `\int_{0}^{1}\frac{x}{1+x^{2}}\,dx` | `\frac{1}{2}\ln 2` |
| ID-M-04 | N2 | `\int_{0}^{1}\frac{dx}{\sqrt{x}\,(1+x)}` | `\frac{\pi}{2}` |
| ID-M-05 | N2 | `\int_{0}^{\infty}\frac{dx}{\sqrt{x}\,(1+x)}` | `\pi` |
| ID-M-06 | N2 | `\int_{0}^{\pi}e^{x}\sin x\,dx` | `\frac{1+e^{\pi}}{2}\approx 12.070346316` |
| ID-M-07 | N2 | `\int_{0}^{\pi/2}e^{\sin x}\cos x\,dx` | `e-1` |
| ID-M-08 | N3 | `\int_{0}^{1}\sin(\ln x)\,dx` | `-\frac{1}{2}` (impropia oscilatoria) |
| ID-M-09 | N3 | `\int_{0}^{\pi/4}\ln(1+\tan x)\,dx` | `\frac{\pi}{8}\ln 2\approx 0.272198262` |
| ID-M-10 | N3 | `\int_{0}^{\pi/2}\ln(\sin x)\,dx` | `-\frac{\pi}{2}\ln 2\approx -1.088793045` |
| ID-M-11 | N3 | `\int_{0}^{\infty}\frac{\sin x}{x}\,dx` | `\frac{\pi}{2}` |
| ID-M-12 | N3 | `\int_{0}^{\infty}\frac{\sin^{2}x}{x^{2}}\,dx` | `\frac{\pi}{2}` |
| ID-M-13 | N3 | `\int_{0}^{\infty}e^{-x}\sin x\,dx` | `\frac{1}{2}` |
| ID-M-14 | N3 | `\int_{0}^{\infty}e^{-ax}\cos(bx)\,dx,\ a>0` | `\frac{a}{a^{2}+b^{2}}` |
| ID-M-15 | N3 | `\int_{0}^{1}\frac{\arctan x}{x}\,dx` | `G\approx 0.915965594` (constante de Catalan) |
| ID-M-16 | N3 | `\int_{0}^{1}e^{-x^{2}}\,dx` | `\frac{\sqrt{\pi}}{2}\operatorname{erf}(1)\approx 0.746824133` |
| ID-M-17 | N3 | `\int_{0}^{1}\frac{\sin x}{x}\,dx` | `\operatorname{Si}(1)\approx 0.946083070` |
| ID-M-18 | N3 | `\int_{0}^{\pi/2}\sqrt{1-\frac{1}{2}\sin^{2}x}\,dx` | `E\!\left(\tfrac{1}{2}\right)\approx 1.350643881` (integral elíptica) |
| ID-M-19 | N2 | `\int_{0}^{1}\operatorname{arsinh}x\,dx` | `\ln\left(1+\sqrt{2}\right)-\sqrt{2}+1\approx 0.467160025` |
| ID-M-20 | N3 | `\int_{2}^{3}\operatorname{arcoth}x\,dx` | `3\ln 2-\frac{3}{2}\ln 3\approx 0.431523109` |

---

## 8. Simplificación y series (álgebra simbólica de apoyo)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| SP-01 | N1 | `\ln\left(e^{x}\right)` | `x` |
| SP-02 | N1 | `e^{\ln x},\ x>0` | `x` |
| SP-03 | N2 | `\sqrt{x^{2}}` | `\lvert x\rvert` (no `x`) |
| SP-04 | N2 | `\sqrt[3]{x^{3}}` | `x` |
| SP-05 | N2 | `\ln\left(\sqrt{x}\right),\ x>0` | `\frac{1}{2}\ln x` |
| SP-06 | N2 | `\ln\left(x^{2}\right)` | `2\ln\lvert x\rvert` |
| SP-07 | N2 | `\log_{a}b\cdot\log_{b}a,\ a,b>0,\ a,b\neq 1` | `1` |
| SP-08 | N2 | `\frac{\sqrt{x}\,\sqrt[3]{x}}{\sqrt[6]{x}},\ x>0` | `x^{2/3}` |
| SP-09 | N2 | `\frac{e^{x}-e^{-x}}{e^{x}+e^{-x}}` | `\tanh x` |
| SP-10 | N2 | `\ln\left(\frac{e^{x}+e^{-x}}{2}\right)` | `\ln(\cosh x)` |
| SP-11 | N3 | `\sqrt{-x}\,\sqrt{-x},\ x\le 0` | `-x` |
| SP-12 | N3 | `\sum_{n=1}^{\infty}\frac{1}{2^{n}}` | `1` |
| SP-13 | N3 | `\sum_{n=1}^{\infty}\frac{n}{2^{n}}` | `2` |
| SP-14 | N3 | `\sum_{n=1}^{\infty}\frac{1}{n(n+1)}` | `1` |
| SP-15 | N3 | `\sum_{n=1}^{\infty}\frac{(-1)^{n+1}}{n}` | `\ln 2` |
| SP-16 | N3 | `\sum_{n=1}^{\infty}\frac{1}{n^{2}}` | `\frac{\pi^{2}}{6}` |
| SP-17 | N2 | `\sum_{n=1}^{\infty}\frac{1}{n}` | diverge |
| SP-18 | N2 | `\sum_{n=0}^{\infty}\frac{x^{n}}{n!}` | `e^{x}` |
| SP-19 | N2 | Taylor de `e^{x}` en `0`, orden 4 | `1+x+\frac{x^{2}}{2}+\frac{x^{3}}{6}+\frac{x^{4}}{24}` |
| SP-20 | N2 | Taylor de `\ln(1+x)` en `0`, orden 4 | `x-\frac{x^{2}}{2}+\frac{x^{3}}{3}-\frac{x^{4}}{4}` |
| SP-21 | N2 | Taylor de `\sqrt{1+x}` en `0`, orden 3 | `1+\frac{x}{2}-\frac{x^{2}}{8}+\frac{x^{3}}{16}` |

---

## 9. Casos límite, robustez numérica y manejo de errores

El motor **no debe** devolver un número incorrecto en ninguno de estos casos.

### 9.A Divergencias y no existencia

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| CL-01 | N2 | `\int_{-1}^{1}\frac{dx}{x}` | diverge (el valor principal `0` no es el valor de la integral) |
| CL-02 | N2 | `\int_{0}^{1}\frac{dx}{x}` | diverge a `+\infty` |
| CL-03 | N2 | `\int_{1}^{\infty}\frac{dx}{x}` | diverge a `+\infty` |
| CL-04 | N2 | `\int_{0}^{1}\frac{\ln x}{x}\,dx` | diverge a `-\infty` |
| CL-05 | N2 | `\int_{0}^{\infty}e^{x}\,dx` | diverge a `+\infty` |
| CL-06 | N2 | `\int_{0}^{\infty}\sin x\,dx` | diverge (no converge) |
| CL-07 | N3 | `\int_{-\infty}^{\infty}\frac{x}{1+x^{2}}\,dx` | diverge (no debe devolver `0` sin aclarar valor principal) |
| CL-08 | N3 | `\int_{0}^{\pi}\sec^{2}x\,dx` | diverge (Barrow ingenuo daría `0`, incorrecto) |
| CL-09 | N2 | `\lim_{x\to 0}e^{1/x}` | no existe (laterales `+\infty` y `0`) |
| CL-10 | N2 | `\lim_{x\to\infty}\sin x` | no existe |
| CL-11 | N2 | `\lim_{x\to 0}\frac{1}{\ln\lvert x\rvert}` | `0` |
| CL-12 | N2 | `\frac{d}{dx}\lvert x\rvert` en `x=0` | no existe |

### 9.B Dominio y ramas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| CL-13 | N1 | `\ln x=-5` con `x` real | `x=e^{-5}\approx 0.006737947` |
| CL-14 | N2 | `\sqrt{x-3}+\sqrt{2-x}=1` | sin solución real (dominio vacío) |
| CL-15 | N2 | `\ln(x-3)+\ln(2-x)=0` | sin solución real (dominio vacío) |
| CL-16 | N2 | `\log_{x}(x)=1` | todo `x>0,\ x\neq 1` |
| CL-17 | N2 | `\operatorname{arsech}(2)` | fuera del dominio real (error claro) |
| CL-18 | N2 | `\operatorname{arcoth}\left(\frac{1}{2}\right)` | fuera del dominio real (error claro) |
| CL-19 | N2 | `\left.\frac{d}{dx}\operatorname{arcsec}x\right\rvert_{x=1/2}` | fuera del dominio (error claro) |
| CL-20 | N2 | `\sqrt{x}<-1` | sin solución (`\varnothing`) |
| CL-21 | N2 | `e^{x}<0` | sin solución (`\varnothing`) |
| CL-22 | N2 | `\ln x>x` | sin solución (`\varnothing`) |

### 9.C Robustez numérica

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| RN-01 | N3 | `e^{1000}` | `\approx 1.970071114\times 10^{434}` (sin desbordamiento) |
| RN-02 | N3 | `2^{1000}` | `\approx 1.071508607\times 10^{301}` (entero exacto) |
| RN-03 | N3 | `\frac{e^{1000}}{e^{999}}` | `e` |
| RN-04 | N3 | `\ln\left(2^{1000}\right)` | `1000\ln 2\approx 693.147180560` |
| RN-05 | N3 | `\sqrt{10^{-400}}` | `10^{-200}` |
| RN-06 | N3 | `\ln\left(1+10^{-20}\right)` | `\approx 10^{-20}` (la resta ingenua da `0`) |
| RN-07 | N3 | `e^{10^{-20}}-1` | `\approx 10^{-20}` (cancelación) |
| RN-08 | N3 | `\sqrt{10^{16}+1}-10^{8}` | `\approx 5\times 10^{-9}` (cancelación) |
| RN-09 | N3 | `\frac{1-\cos\left(10^{-8}\right)}{10^{-16}}` | `\approx 0.5` (cancelación) |
| RN-10 | N3 | `\left(1+10^{-16}\right)^{10^{16}}` | `\approx 2.718281828` (aritmética exacta/alta precisión) |
| RN-11 | N3 | `\sin\left(10^{22}\right)` | `\approx -0.852200850` |
| RN-12 | N3 | `\tan\left(\frac{\pi}{2}-10^{-10}\right)` | `\approx 10^{10}` |

---

## Resumen de cobertura

| Sección | Log | Exp | Rad | Mixtas | Trig/Hip |
|---|:-:|:-:|:-:|:-:|:-:|
| 1. Evaluación en un punto | 14 | 14 | 14 | 13 | 12 |
| 2. Ecuaciones | 12 | 15 | 11 | 18 | 12 |
| 3. Inecuaciones | 9 | 10 | 9 | 9 | 7 |
| 4. Límites | 15 | 17 | 15 | 18 | 20 |
| 5. Derivadas | 14 | 12 | 13 | 15 | 15 |
| 6. Integrales indefinidas | 12 | 15 | 15 | 10 | 12 |
| 7. Integrales definidas | 13 | 18 | 21 | 20 | (incl. en M) |

Además: 9 límites multivariable (4.V), 7 integrales no elementales (6.S), 21 de simplificación y series (sección 8) y 34 de casos límite y robustez numérica (sección 9).
