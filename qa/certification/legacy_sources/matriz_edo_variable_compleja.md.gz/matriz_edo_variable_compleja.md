# Matriz de estrés — Ecuaciones diferenciales y Variable compleja

Batería para medir la capacidad real de los motores de la calculadora (Precision Lab Lite / Plus) y localizar oportunidades de mejora.

- **Parte A — Ecuaciones diferenciales:** ordinarias de primer orden (separables, lineales, homogéneas, exactas, Bernoulli, Riccati, Clairaut), de segundo orden y superior, sistemas y exponencial matricial, transformada de Laplace, series y funciones especiales, ecuaciones en derivadas parciales, análisis cualitativo, métodos numéricos, ecuaciones en diferencias, con retardo e integro-diferenciales.
- **Parte B — Variable compleja, análisis complejo y cálculo complejo:** las **cuatro formas de representación** (binómica, polar, trigonométrica y exponencial), potencias y raíces, ecuaciones y lugares geométricos en $\mathbb{C}$, funciones elementales y multivaluadas, límites y series, derivabilidad y funciones armónicas, integrales de contorno, residuos, series de Taylor y Laurent, integrales reales por residuos, transformaciones conformes y teoremas globales.

## Convenciones

**Generales**
- **Nivel:** `N1` básico · `N2` intermedio (requiere estrategia) · `N3` desafío (función especial, rama delicada, cancelación numérica o técnica no trivial).
- Cada ejercicio y cada resultado esperado está en código LaTeX, listo para pegar. "Error claro" = el motor debe avisar (dominio, divergencia, indefinición); devolver un número incorrecto en silencio es el peor resultado.
- Los resultados esperados se calcularon a mano y se verificaron derivando/sustituyendo. Ante una discrepancia, revisar primero el valor esperado.
- Soluciones equivalentes se aceptan (por ejemplo, constantes reescritas, forma implícita o explícita).

**Ecuaciones diferenciales**
- $C,\ C_{1},\ C_{2},\dots$ son constantes arbitrarias. Variable independiente $x$ (o $t$ si se indica). Se acepta solución implícita cuando la explícita no es práctica.
- Cuando se pierden o ganan soluciones (singulares, equilibrios), el resultado esperado las menciona; un motor que solo da la familia general se anota como F4.

**Variable compleja**
- **Binómica:** `z=a+bi`. **Polar:** `z=r_{\theta}` (equivalente a `r\angle\theta`). **Trigonométrica:** `z=r(\cos\theta+i\sin\theta)` (equivalente a `r\operatorname{cis}\theta`). **Exponencial:** `z=re^{i\theta}`.
- $r=\lvert z\rvert\ge0$; argumento principal $\operatorname{Arg}z\in(-\pi,\pi]$. Al pedir una conversión se espera el **argumento normalizado** y el módulo no negativo.
- Ángulos en radianes salvo que se indique `^{\circ}`. $\operatorname{Log}$ es la rama principal; $\log$ es el logaritmo multivaluado. $k\in\mathbb{Z}$.
- Las raíces se listan todas; la "raíz principal" se indica expresamente.
- Donde la rama depende de una convención (signo de la parte imaginaria sobre un corte), el resultado esperado lo marca y el motor debe **declarar** qué convención usa.

## Categorías de fallo sugeridas para el registro

| Código | Significado | Gravedad |
|---|---|---|
| F1 | Resultado matemáticamente incorrecto | Crítica |
| F2 | Pierde soluciones / incluye soluciones extrañas | Alta |
| F3 | No resuelve (sin respuesta, timeout o "no soportado") | Media |
| F4 | Correcto pero incompleto o sin simplificar (falta solución singular, forma poco útil) | Baja |
| F5 | Rama, dominio o intervalo de validez no respetados | Alta |
| F6 | Error numérico (cancelación, desbordamiento, precisión) | Alta |
| F7 | No interpreta la notación de entrada (por ejemplo, la forma polar `r_{\theta}`) | Media |

---

# PARTE A — ECUACIONES DIFERENCIALES

## A1. Primer orden

### A1.S Separables

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-S-01 | N1 | `y'=y` | `y=Ce^{x}` |
| ED-S-02 | N1 | `y'=xy` | `y=Ce^{x^{2}/2}` |
| ED-S-03 | N1 | `\frac{dy}{dx}=\frac{x}{y}` | `y^{2}=x^{2}+C` |
| ED-S-04 | N2 | `y'=y^{2}` | `y=-\frac{1}{x+C}` y la solución singular `y=0` |
| ED-S-05 | N2 | `y'=e^{x-y}` | `y=\ln\left(e^{x}+C\right)` |
| ED-S-06 | N2 | `\frac{dy}{dx}=\frac{1+y^{2}}{1+x^{2}}` | `y=\tan(\arctan x+C)` |
| ED-S-07 | N2 | `xy'=y\ln y` | `y=e^{Cx}` (con `C=0` da `y=1`) |
| ED-S-08 | N2 | `y'=y^{2}-1` | `y=\frac{1+Ce^{2x}}{1-Ce^{2x}}` y la solución singular `y=-1` |
| ED-S-09 | N1 | `y'=2xy,\ y(0)=3` | `y=3e^{x^{2}}` |
| ED-S-10 | N1 | `y'=\frac{y}{x},\ y(1)=2` | `y=2x` |
| ED-S-11 | N2 | `y'=-\frac{x}{y},\ y(0)=2` | `y=\sqrt{4-x^{2}}` |
| ED-S-12 | N2 | `y'=(1+y^{2})\cos x,\ y(0)=0` | `y=\tan(\sin x)` |
| ED-S-13 | N3 | `y'=\sqrt{y}` | `y=\frac{(x+C)^{2}}{4}` con `x+C\ge0`, y `y=0` (no hay unicidad) |
| ED-S-14 | N3 | `y'=\sqrt[3]{y},\ y(0)=0` | `y=0` y `y=\pm\left(\frac{2x}{3}\right)^{3/2},\ x\ge0` (infinitas soluciones) |

### A1.L Lineales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-L-01 | N1 | `y'+y=e^{x}` | `y=\frac{e^{x}}{2}+Ce^{-x}` |
| ED-L-02 | N1 | `y'+2y=x` | `y=\frac{x}{2}-\frac{1}{4}+Ce^{-2x}` |
| ED-L-03 | N1 | `y'+y=\sin x` | `y=\frac{\sin x-\cos x}{2}+Ce^{-x}` |
| ED-L-04 | N2 | `xy'+y=x^{2},\ x>0` | `y=\frac{x^{2}}{3}+\frac{C}{x}` |
| ED-L-05 | N2 | `y'-\frac{2}{x}y=x^{2}` | `y=x^{3}+Cx^{2}` |
| ED-L-06 | N2 | `y'+y\tan x=\sin x` | `y=\cos x\left(C-\ln\lvert\cos x\rvert\right)` |
| ED-L-07 | N2 | `\left(x^{2}+1\right)y'+2xy=x` | `y=\frac{x^{2}/2+C}{x^{2}+1}` |
| ED-L-08 | N2 | `y'+\frac{y}{x}=\frac{\sin x}{x}` | `y=\frac{C-\cos x}{x}` |
| ED-L-09 | N1 | `y'+3y=6,\ y(0)=0` | `y=2-2e^{-3x}` |
| ED-L-10 | N2 | `y'+y=x,\ y(0)=1` | `y=x-1+2e^{-x}` |
| ED-L-11 | N2 | `y'+2xy=e^{-x^{2}},\ y(0)=1` | `y=(x+1)e^{-x^{2}}` |
| ED-L-12 | N3 | `y\,dx+\left(x-y^{3}\right)dy=0` (tomar `x` como función de `y`) | `x=\frac{y^{3}}{4}+\frac{C}{y}` |

### A1.H Homogéneas y reducibles

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-H-01 | N2 | `y'=\frac{x+y}{x}` | `y=x\left(\ln\lvert x\rvert+C\right)` |
| ED-H-02 | N2 | `y'=\frac{y}{x}+\frac{x}{y}` | `y^{2}=x^{2}\left(2\ln\lvert x\rvert+C\right)` |
| ED-H-03 | N2 | `\left(x^{2}+y^{2}\right)dx-2xy\,dy=0` | `x^{2}-y^{2}=Cx` |
| ED-H-04 | N3 | `\frac{dy}{dx}=\frac{2xy}{x^{2}-y^{2}}` | `x^{2}+y^{2}=Cy` |
| ED-H-05 | N3 | `xy'=y+\sqrt{x^{2}+y^{2}},\ x>0` | `\operatorname{arsinh}\frac{y}{x}=\ln x+C` |
| ED-H-06 | N3 | `(x+y+1)\,dx+(2x+2y-1)\,dy=0` | `x+2y+3\ln\lvert x+y-2\rvert=C` |

### A1.X Exactas y factor integrante

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-X-01 | N1 | `(2xy+3)\,dx+\left(x^{2}-1\right)dy=0` | `x^{2}y+3x-y=C` |
| ED-X-02 | N2 | `\left(3x^{2}y+y^{3}\right)dx+\left(x^{3}+3xy^{2}\right)dy=0` | `x^{3}y+xy^{3}=C` |
| ED-X-03 | N2 | `\left(y\cos x+2xe^{y}\right)dx+\left(\sin x+x^{2}e^{y}-1\right)dy=0` | `y\sin x+x^{2}e^{y}-y=C` |
| ED-X-04 | N2 | `\left(2xy+y^{2}\right)dx+\left(x^{2}+2xy\right)dy=0` | `x^{2}y+xy^{2}=C` |
| ED-X-05 | N2 | `(2x+y)\,dx+(x+2y)\,dy=0,\ y(1)=1` | `x^{2}+xy+y^{2}=3` |
| ED-X-06 | N3 | `y\,dx+\left(2x-ye^{y}\right)dy=0` (factor integrante `\mu=y`) | `xy^{2}-e^{y}\left(y^{2}-2y+2\right)=C` |
| ED-X-07 | N3 | `\left(x^{2}+y^{2}+x\right)dx+xy\,dy=0` (factor integrante `\mu=x`) | `6x^{2}y^{2}+3x^{4}+4x^{3}=C` |

### A1.B Bernoulli, Riccati, logística

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-B-01 | N2 | `y'+y=xy^{2}` | `y=\frac{1}{x+1+Ce^{x}}` y `y=0` |
| ED-B-02 | N2 | `y'=y+y^{2},\ y(0)=1` | `y=\frac{e^{x}}{2-e^{x}}` (explota en `x=\ln 2`) |
| ED-B-03 | N3 | `y'-\frac{y}{x}=y^{3}` | `y^{2}=\frac{3x^{2}}{C-2x^{3}}` |
| ED-B-04 | N3 | `xy'+y=x^{2}y^{2}\ln x,\ x>0` | `y=\frac{1}{x^{2}-x^{2}\ln x+Cx}` |
| ED-B-05 | N2 | `y'=ry\left(1-\frac{y}{K}\right)` | `y=\frac{K}{1+Ce^{-rx}}` |
| ED-B-06 | N2 | `y'=ry\left(1-\frac{y}{K}\right),\ y(0)=y_{0}` | `y=\frac{Ky_{0}}{y_{0}+(K-y_{0})e^{-rx}}` |
| ED-B-07 | N3 | Riccati `y'=1+x^{2}-2xy+y^{2}` con solución particular `y_{1}=x` | `y=x-\frac{1}{x+C}` y `y=x` |
| ED-B-08 | N3 | Riccati `y'=y^{2}-\frac{2}{x^{2}}` con `y_{1}=\frac{1}{x}` | `y=\frac{1}{x}+\frac{3x^{2}}{K-x^{3}}` |
| ED-B-09 | N3 | `y'=y^{2}-x` | `y=-\frac{C_{1}\operatorname{Ai}'(x)+C_{2}\operatorname{Bi}'(x)}{C_{1}\operatorname{Ai}(x)+C_{2}\operatorname{Bi}(x)}` |

### A1.C Clairaut, Lagrange e implícitas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-C-01 | N3 | `y=xy'+\left(y'\right)^{2}` | general `y=Cx+C^{2}`; singular `y=-\frac{x^{2}}{4}` |
| ED-C-02 | N3 | `y=xy'+\frac{1}{y'}` | general `y=Cx+\frac{1}{C}`; singular `y^{2}=4x` |
| ED-C-03 | N2 | `\left(y'\right)^{2}-4y'+3=0` | `y=x+C` o `y=3x+C` |
| ED-C-04 | N2 | `\left(y'\right)^{2}=y` | `y=\frac{(x+C)^{2}}{4}` y `y=0` |
| ED-C-05 | N3 | Lagrange `y=2xy'+\left(y'\right)^{2}` con `p=y'` | `x=-\frac{2p}{3}+\frac{C}{p^{2}},\ y=-\frac{p^{2}}{3}+\frac{2C}{p}` y `y=0` |

---

## A2. Segundo orden y orden superior

### A2.K Homogéneas de coeficientes constantes, PVI y PVF

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-K-01 | N1 | `y''-3y'+2y=0` | `y=C_{1}e^{x}+C_{2}e^{2x}` |
| ED-K-02 | N1 | `y''+4y=0` | `y=C_{1}\cos 2x+C_{2}\sin 2x` |
| ED-K-03 | N1 | `y''+2y'+y=0` | `y=(C_{1}+C_{2}x)e^{-x}` |
| ED-K-04 | N2 | `y''-4y'+13y=0` | `y=e^{2x}\left(C_{1}\cos 3x+C_{2}\sin 3x\right)` |
| ED-K-05 | N2 | `y''+y'+y=0` | `y=e^{-x/2}\left(C_{1}\cos\frac{\sqrt{3}x}{2}+C_{2}\sin\frac{\sqrt{3}x}{2}\right)` |
| ED-K-06 | N2 | `y'''-6y''+11y'-6y=0` | `y=C_{1}e^{x}+C_{2}e^{2x}+C_{3}e^{3x}` |
| ED-K-07 | N3 | `y'''-y=0` | `y=C_{1}e^{x}+e^{-x/2}\left(C_{2}\cos\frac{\sqrt{3}x}{2}+C_{3}\sin\frac{\sqrt{3}x}{2}\right)` |
| ED-K-08 | N2 | `y^{(4)}-y=0` | `y=C_{1}e^{x}+C_{2}e^{-x}+C_{3}\cos x+C_{4}\sin x` |
| ED-K-09 | N2 | `y^{(4)}+2y''+y=0` | `y=(C_{1}+C_{2}x)\cos x+(C_{3}+C_{4}x)\sin x` |
| ED-K-10 | N3 | `y^{(4)}+4y=0` | `y=e^{x}\left(C_{1}\cos x+C_{2}\sin x\right)+e^{-x}\left(C_{3}\cos x+C_{4}\sin x\right)` |
| ED-K-11 | N1 | `y''+y=0,\ y(0)=1,\ y'(0)=0` | `y=\cos x` |
| ED-K-12 | N2 | `y''+2y'+5y=0,\ y(0)=1,\ y'(0)=1` | `y=e^{-x}\left(\cos 2x+\sin 2x\right)` |
| ED-K-13 | N2 | `y''-5y'+6y=0,\ y(0)=2,\ y'(0)=5` | `y=e^{2x}+e^{3x}` |
| ED-K-14 | N2 | `y''+y=0,\ y(0)=0,\ y(\pi)=0` | `y=C\sin x` (infinitas soluciones) |
| ED-K-15 | N2 | `y''+y=0,\ y(0)=0,\ y(\pi)=1` | sin solución |
| ED-K-16 | N3 | `y''+\lambda y=0,\ y(0)=0,\ y(\pi)=0` | `\lambda_{n}=n^{2},\ y_{n}=\sin nx,\ n\ge1` |

### A2.N No homogéneas (coeficientes indeterminados y variación de parámetros)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-N-01 | N1 | `y''-y=x` | `y=C_{1}e^{x}+C_{2}e^{-x}-x` |
| ED-N-02 | N1 | `y''-3y'+2y=e^{3x}` | `y=C_{1}e^{x}+C_{2}e^{2x}+\frac{e^{3x}}{2}` |
| ED-N-03 | N2 | `y''-3y'+2y=e^{x}` | `y=C_{1}e^{x}+C_{2}e^{2x}-xe^{x}` |
| ED-N-04 | N2 | `y''+y=\sin x` | `y=C_{1}\cos x+C_{2}\sin x-\frac{x}{2}\cos x` |
| ED-N-05 | N2 | `y''+2y'+y=e^{-x}` | `y=(C_{1}+C_{2}x)e^{-x}+\frac{x^{2}}{2}e^{-x}` |
| ED-N-06 | N2 | `y''-2y'+y=xe^{x}` | `y=(C_{1}+C_{2}x)e^{x}+\frac{x^{3}}{6}e^{x}` |
| ED-N-07 | N2 | `y''+y'-2y=x^{2}` | `y=C_{1}e^{x}+C_{2}e^{-2x}-\frac{x^{2}}{2}-\frac{x}{2}-\frac{3}{4}` |
| ED-N-08 | N3 | `y''+2y'+5y=e^{-x}\cos 2x` | `y=e^{-x}\left(C_{1}\cos 2x+C_{2}\sin 2x\right)+\frac{x}{4}e^{-x}\sin 2x` |
| ED-N-09 | N3 | `y''+y=\tan x` | `y=C_{1}\cos x+C_{2}\sin x-\cos x\ln\lvert\sec x+\tan x\rvert` |
| ED-N-10 | N3 | `y''+y=\sec x` | `y=C_{1}\cos x+C_{2}\sin x+x\sin x+\cos x\ln\lvert\cos x\rvert` |
| ED-N-11 | N3 | `y''+y=\csc x` | `y=C_{1}\cos x+C_{2}\sin x-x\cos x+\sin x\ln\lvert\sin x\rvert` |
| ED-N-12 | N3 | `y''-2y'+y=\frac{e^{x}}{x}` | `y=(C_{1}+C_{2}x)e^{x}+xe^{x}\ln x` |
| ED-N-13 | N2 | `y''+y=t,\ y(0)=0,\ y'(0)=0` (variable `t`) | `y=t-\sin t` |
| ED-N-14 | N2 | `y''+4y'+4y=e^{-2x},\ y(0)=0,\ y'(0)=0` | `y=\frac{x^{2}}{2}e^{-2x}` |
| ED-N-15 | N2 | `y'''-y''=1` | `y=-\frac{x^{2}}{2}+C_{1}e^{x}+C_{2}x+C_{3}` |

### A2.E Cauchy–Euler, reducción de orden y Wronskiano

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-E-01 | N2 | `x^{2}y''-2y=0,\ x>0` | `y=C_{1}x^{2}+\frac{C_{2}}{x}` |
| ED-E-02 | N2 | `x^{2}y''+xy'-y=0` | `y=C_{1}x+\frac{C_{2}}{x}` |
| ED-E-03 | N2 | `x^{2}y''-3xy'+4y=0` | `y=x^{2}\left(C_{1}+C_{2}\ln x\right)` |
| ED-E-04 | N2 | `x^{2}y''+xy'+y=0` | `y=C_{1}\cos(\ln x)+C_{2}\sin(\ln x)` |
| ED-E-05 | N2 | `x^{2}y''-2xy'+2y=x^{3}` | `y=C_{1}x+C_{2}x^{2}+\frac{x^{3}}{2}` |
| ED-E-06 | N2 | `yy''=\left(y'\right)^{2}` | `y=C_{2}e^{C_{1}x}` |
| ED-E-07 | N2 | `y''+\left(y'\right)^{2}=0` | `y=\ln\lvert x+C_{1}\rvert+C_{2}` |
| ED-E-08 | N2 | `xy''=y'` | `y=C_{1}x^{2}+C_{2}` |
| ED-E-09 | N2 | `x^{2}y''-xy'+y=0` con `y_{1}=x` (reducción de orden) | `y=x\left(C_{1}+C_{2}\ln x\right)` |
| ED-E-10 | N1 | `W(\cos x,\sin x)` | `1` |
| ED-E-11 | N1 | `W\left(e^{x},e^{2x}\right)` | `e^{3x}` |
| ED-E-12 | N2 | `W\left(1,x,x^{2}\right)` | `2` |
| ED-E-13 | N2 | `W(x,x\ln x)` | `x` |
| ED-E-14 | N2 | Independencia de `\sin 2x` y `\sin x\cos x` | linealmente dependientes (`W=0`) |

### A2.A Aplicaciones

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-A-01 | N1 | `x''+9x=0,\ x(0)=1,\ x'(0)=0` | `x=\cos 3t` |
| ED-A-02 | N2 | `x''+2x'+10x=0,\ x(0)=0,\ x'(0)=3` | `x=e^{-t}\sin 3t` |
| ED-A-03 | N2 | `x''+x=\cos t,\ x(0)=0,\ x'(0)=0` (resonancia) | `x=\frac{t}{2}\sin t` |
| ED-A-04 | N2 | `x''+\omega^{2}x=\cos\gamma t,\ \gamma\neq\omega,\ x(0)=x'(0)=0` | `x=\frac{\cos\gamma t-\cos\omega t}{\omega^{2}-\gamma^{2}}` |
| ED-A-05 | N1 | `T'=-k\left(T-T_{a}\right),\ T(0)=T_{0}` | `T=T_{a}+\left(T_{0}-T_{a}\right)e^{-kt}` |

---

## A3. Sistemas y exponencial matricial

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-M-01 | N1 | `\begin{cases}x'=x\\ y'=2y\end{cases}` | `x=C_{1}e^{t},\ y=C_{2}e^{2t}` |
| ED-M-02 | N2 | `\begin{cases}x'=y\\ y'=-x\end{cases}` | `x=C_{1}\cos t+C_{2}\sin t,\ y=-C_{1}\sin t+C_{2}\cos t` |
| ED-M-03 | N2 | `\begin{cases}x'=3x+y\\ y'=x+3y\end{cases}` | `x=C_{1}e^{4t}+C_{2}e^{2t},\ y=C_{1}e^{4t}-C_{2}e^{2t}` |
| ED-M-04 | N2 | `\begin{cases}x'=x-y\\ y'=x+y\end{cases}` | `x=e^{t}\left(C_{1}\cos t+C_{2}\sin t\right),\ y=e^{t}\left(C_{1}\sin t-C_{2}\cos t\right)` |
| ED-M-05 | N2 | `\begin{cases}x'=2x+y\\ y'=2y\end{cases}` | `x=\left(C_{1}+C_{2}t\right)e^{2t},\ y=C_{2}e^{2t}` |
| ED-M-06 | N2 | `\begin{cases}x'=y+1\\ y'=-x\end{cases}` | `x=C_{1}\cos t+C_{2}\sin t,\ y=-C_{1}\sin t+C_{2}\cos t-1` |
| ED-M-07 | N2 | `\mathbf{x}'=\begin{pmatrix}0&1\\-2&-3\end{pmatrix}\mathbf{x},\ \mathbf{x}(0)=\begin{pmatrix}1\\0\end{pmatrix}` | `x=2e^{-t}-e^{-2t},\ y=-2e^{-t}+2e^{-2t}` |
| ED-M-08 | N2 | `e^{At},\ A=\begin{pmatrix}0&1\\-1&0\end{pmatrix}` | `\begin{pmatrix}\cos t&\sin t\\-\sin t&\cos t\end{pmatrix}` |
| ED-M-09 | N2 | `e^{At},\ A=\begin{pmatrix}\lambda&1\\0&\lambda\end{pmatrix}` | `e^{\lambda t}\begin{pmatrix}1&t\\0&1\end{pmatrix}` |
| ED-M-10 | N3 | `e^{At},\ A=\begin{pmatrix}2&1\\1&2\end{pmatrix}` | `\frac{1}{2}\begin{pmatrix}e^{3t}+e^{t}&e^{3t}-e^{t}\\e^{3t}-e^{t}&e^{3t}+e^{t}\end{pmatrix}` |
| ED-M-11 | N2 | Clasificar el origen: `A=\begin{pmatrix}1&2\\3&2\end{pmatrix}` | `\lambda=4,\ -1`: punto silla |
| ED-M-12 | N2 | Clasificar el origen: `A=\begin{pmatrix}-1&1\\-1&-1\end{pmatrix}` | `\lambda=-1\pm i`: foco estable |
| ED-M-13 | N2 | Clasificar el origen: `A=\begin{pmatrix}0&1\\-1&0\end{pmatrix}` | `\lambda=\pm i`: centro |
| ED-M-14 | N3 | Lotka–Volterra `\begin{cases}x'=x(1-y)\\ y'=y(x-1)\end{cases}` | integral primera `x-\ln x+y-\ln y=C`; `(1,1)` centro, `(0,0)` silla |
| ED-M-15 | N3 | `\begin{cases}x'=-y+x\left(1-x^{2}-y^{2}\right)\\ y'=x+y\left(1-x^{2}-y^{2}\right)\end{cases}` | en polares `r'=r\left(1-r^{2}\right),\ \theta'=1`; ciclo límite estable `r=1` |
| ED-M-16 | N3 | Lyapunov `\begin{cases}x'=-y-x^{3}\\ y'=x-y^{3}\end{cases}` | con `V=x^{2}+y^{2}`, `\dot V=-2x^{4}-2y^{4}<0`: origen asintóticamente estable |

---

## A4. Transformada de Laplace

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-T-01 | N1 | `\mathcal{L}\{t^{n}\}` | `\frac{n!}{s^{n+1}}` |
| ED-T-02 | N1 | `\mathcal{L}\{e^{at}\}` | `\frac{1}{s-a}` |
| ED-T-03 | N1 | `\mathcal{L}\{\sin bt\}` | `\frac{b}{s^{2}+b^{2}}` |
| ED-T-04 | N2 | `\mathcal{L}\{e^{at}\sin bt\}` | `\frac{b}{(s-a)^{2}+b^{2}}` |
| ED-T-05 | N2 | `\mathcal{L}\{t\sin t\}` | `\frac{2s}{\left(s^{2}+1\right)^{2}}` |
| ED-T-06 | N2 | `\mathcal{L}\{u(t-a)\}` | `\frac{e^{-as}}{s}` |
| ED-T-07 | N2 | `\mathcal{L}\{\delta(t-a)\}` | `e^{-as}` |
| ED-T-08 | N3 | `\mathcal{L}\left\{\frac{\sin t}{t}\right\}` | `\arctan\frac{1}{s}` |
| ED-T-09 | N3 | `\mathcal{L}\left\{\frac{1}{\sqrt{t}}\right\}` | `\sqrt{\frac{\pi}{s}}` |
| ED-T-10 | N1 | `\mathcal{L}^{-1}\left\{\frac{1}{s(s+1)}\right\}` | `1-e^{-t}` |
| ED-T-11 | N2 | `\mathcal{L}^{-1}\left\{\frac{1}{s^{2}+2s+5}\right\}` | `\frac{1}{2}e^{-t}\sin 2t` |
| ED-T-12 | N2 | `\mathcal{L}^{-1}\left\{\frac{1}{s^{2}\left(s^{2}+1\right)}\right\}` | `t-\sin t` |
| ED-T-13 | N2 | `\mathcal{L}^{-1}\left\{\frac{1}{\left(s^{2}+1\right)^{2}}\right\}` | `\frac{\sin t-t\cos t}{2}` |
| ED-T-14 | N2 | `\mathcal{L}^{-1}\left\{\frac{e^{-2s}}{s^{2}}\right\}` | `(t-2)\,u(t-2)` |
| ED-T-15 | N2 | `\mathcal{L}^{-1}\left\{\frac{1}{(s-1)(s-2)(s-3)}\right\}` | `\frac{1}{2}e^{t}-e^{2t}+\frac{1}{2}e^{3t}` |
| ED-T-16 | N2 | Convolución `t*e^{t}` | `e^{t}-t-1` |
| ED-T-17 | N1 | `y'+2y=e^{-t},\ y(0)=1` | `y=e^{-t}` |
| ED-T-18 | N2 | `y''-y=e^{t},\ y(0)=0,\ y'(0)=0` | `y=\frac{te^{t}}{2}-\frac{e^{t}-e^{-t}}{4}` |
| ED-T-19 | N2 | `y''+2y'+y=te^{-t},\ y(0)=0,\ y'(0)=0` | `y=\frac{t^{3}}{6}e^{-t}` |
| ED-T-20 | N2 | `y''+y=\delta(t-\pi),\ y(0)=0,\ y'(0)=0` | `y=-u(t-\pi)\sin t` |
| ED-T-21 | N2 | `y''+4y=u(t-1),\ y(0)=0,\ y'(0)=0` | `y=\frac{1-\cos 2(t-1)}{4}\,u(t-1)` |
| ED-T-22 | N3 | `y'(t)=1-\int_{0}^{t}y(\tau)\,d\tau,\ y(0)=0` | `y=\sin t` |
| ED-T-23 | N3 | `y(t)=t+\int_{0}^{t}\sin(t-\tau)\,y(\tau)\,d\tau` | `y=t+\frac{t^{3}}{6}` |
| ED-T-24 | N3 | `\begin{cases}x'=y\\ y'=-x\end{cases},\ x(0)=1,\ y(0)=0` (por Laplace) | `x=\cos t,\ y=-\sin t` |

---

## A5. Series, Frobenius y funciones especiales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-F-01 | N2 | `y''+y=0` por series en `x=0` | `y=a_{0}\cos x+a_{1}\sin x` |
| ED-F-02 | N3 | `y''-xy=0` | `y=a_{0}\left(1+\frac{x^{3}}{6}+\frac{x^{6}}{180}+\cdots\right)+a_{1}\left(x+\frac{x^{4}}{12}+\frac{x^{7}}{504}+\cdots\right)`; cerrada: `C_{1}\operatorname{Ai}(x)+C_{2}\operatorname{Bi}(x)` |
| ED-F-03 | N3 | `2xy''+y'+y=0` (Frobenius, exponentes `0` y `\frac12`) | `y=C_{1}\cos\sqrt{2x}+C_{2}\sin\sqrt{2x},\ x>0` |
| ED-F-04 | N3 | `x^{2}y''+xy'+x^{2}y=0` | `y=C_{1}J_{0}(x)+C_{2}Y_{0}(x)` |
| ED-F-05 | N3 | `x^{2}y''+xy'+\left(x^{2}-\frac14\right)y=0` | `y=\frac{C_{1}\sin x+C_{2}\cos x}{\sqrt{x}}` |
| ED-F-06 | N3 | Legendre `\left(1-x^{2}\right)y''-2xy'+2y=0` | `y=C_{1}x+C_{2}\left(\frac{x}{2}\ln\frac{1+x}{1-x}-1\right)` |
| ED-F-07 | N2 | Hermite `y''-2xy'+4y=0` (solución polinomial) | `y=x^{2}-\frac{1}{2}` |
| ED-F-08 | N2 | Chebyshev `\left(1-x^{2}\right)y''-xy'+4y=0` (solución polinomial) | `y=2x^{2}-1` |
| ED-F-09 | N2 | Clasificar `x=0` en `x^{2}y''+xy'+\left(x^{2}-\nu^{2}\right)y=0` | punto singular regular |
| ED-F-10 | N2 | Clasificar `x=0` en `x^{3}y''+y=0` | punto singular irregular |

---

## A6. Ecuaciones en derivadas parciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-P-01 | N1 | `u_{x}+u_{y}=0` | `u=f(x-y)` |
| ED-P-02 | N2 | `u_{x}+2u_{y}=0` | `u=f(y-2x)` |
| ED-P-03 | N2 | `u_{x}+u_{y}=u` | `u=e^{x}f(y-x)` |
| ED-P-04 | N2 | `xu_{x}+yu_{y}=u` | `u=x\,f\!\left(\frac{y}{x}\right)` |
| ED-P-05 | N2 | `u_{t}+cu_{x}=0,\ u(x,0)=\phi(x)` | `u=\phi(x-ct)` |
| ED-P-06 | N3 | Burgers `u_{t}+uu_{x}=0,\ u(x,0)=x` | `u=\frac{x}{1+t}` |
| ED-P-07 | N2 | `u_{xy}=0` | `u=f(x)+g(y)` |
| ED-P-08 | N2 | `u_{xy}=x+y` | `u=\frac{x^{2}y}{2}+\frac{xy^{2}}{2}+f(x)+g(y)` |
| ED-P-09 | N2 | Clasificar `u_{xx}+u_{yy}=0`, `u_{tt}=c^{2}u_{xx}`, `u_{t}=ku_{xx}`, `u_{xx}+2u_{xy}+u_{yy}=0` | elíptica, hiperbólica, parabólica, parabólica |
| ED-P-10 | N3 | Clasificar `xu_{xx}+u_{yy}=0` | elíptica si `x>0`, parabólica si `x=0`, hiperbólica si `x<0` |
| ED-P-11 | N2 | d'Alembert `u_{tt}=c^{2}u_{xx},\ u(x,0)=f(x),\ u_{t}(x,0)=g(x)` | `u=\frac{f(x+ct)+f(x-ct)}{2}+\frac{1}{2c}\int_{x-ct}^{x+ct}g(s)\,ds` |
| ED-P-12 | N2 | `u_{tt}=u_{xx},\ u(x,0)=\sin x,\ u_{t}(x,0)=0` | `u=\sin x\cos t` |
| ED-P-13 | N2 | Cuerda con extremos fijos en `0,\pi`: `u_{tt}=u_{xx},\ u(x,0)=\sin 2x,\ u_{t}(x,0)=0` | `u=\sin 2x\cos 2t` |
| ED-P-14 | N2 | Cuerda con extremos fijos en `0,\pi`: `u_{tt}=u_{xx},\ u(x,0)=0,\ u_{t}(x,0)=\sin x` | `u=\sin x\sin t` |
| ED-P-15 | N2 | Calor `u_{t}=u_{xx}`, `u(0,t)=u(\pi,t)=0`, `u(x,0)=\sin 3x` | `u=e^{-9t}\sin 3x` |
| ED-P-16 | N2 | Calor, mismas condiciones, `u(x,0)=\sin x+2\sin 2x` | `u=e^{-t}\sin x+2e^{-4t}\sin 2x` |
| ED-P-17 | N3 | Calor, mismas condiciones, `u(x,0)=x` | `u=\sum_{n=1}^{\infty}\frac{2(-1)^{n+1}}{n}e^{-n^{2}t}\sin nx` |
| ED-P-18 | N2 | Calor con Neumann: `u_{x}(0,t)=u_{x}(\pi,t)=0,\ u(x,0)=\cos 2x` | `u=e^{-4t}\cos 2x` |
| ED-P-19 | N2 | Laplace en `0<x<\pi,\ 0<y<1`: `u(0,y)=u(\pi,y)=0,\ u(x,0)=0,\ u(x,1)=\sin x` | `u=\frac{\sin x\sinh y}{\sinh 1}` |
| ED-P-20 | N2 | Laplace en el disco `r<1`, `u(1,\theta)=\cos 2\theta` | `u=r^{2}\cos 2\theta` |
| ED-P-21 | N2 | Laplace en el disco `r<1`, `u(1,\theta)=1+\sin\theta` | `u=1+r\sin\theta` |
| ED-P-22 | N2 | Poisson `\Delta u=4` en `r<1`, `u=0` en `r=1` | `u=r^{2}-1` |
| ED-P-23 | N2 | `X''+\lambda X=0,\ X'(0)=0,\ X'(L)=0` | `\lambda_{n}=\left(\frac{n\pi}{L}\right)^{2},\ n\ge0,\ X_{n}=\cos\frac{n\pi x}{L}` |
| ED-P-24 | N3 | `X''+\lambda X=0,\ X(0)=0,\ X'(L)=0` | `\lambda_{n}=\left(\frac{(2n-1)\pi}{2L}\right)^{2},\ X_{n}=\sin\frac{(2n-1)\pi x}{2L}` |
| ED-P-25 | N2 | `\Delta\left(e^{x}\sin y\right)` | `0` |
| ED-P-26 | N3 | Calor en la recta `u_{t}=u_{xx},\ u(x,0)=\delta(x)` | `u=\frac{1}{\sqrt{4\pi t}}e^{-x^{2}/(4t)}` |

---

## A7. Cualitativo, existencia, numérico, diferencias, retardo y no elementales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-Q-01 | N2 | Equilibrios de `y'=y(1-y)(y-2)` | `0` estable, `1` inestable, `2` estable |
| ED-Q-02 | N2 | Equilibrios de `x'=x-x^{3}` | `0` inestable; `\pm1` estables |
| ED-Q-03 | N2 | Equilibrio de `x'=x^{2}` | `0` semiestable |
| ED-Q-04 | N3 | `x'=r+x^{2}` | bifurcación silla-nodo en `r=0`; equilibrios `x=\pm\sqrt{-r}` para `r<0` |
| ED-Q-05 | N2 | `y'=y^{2},\ y(0)=1`: solución e intervalo máximo | `y=\frac{1}{1-x}`, en `(-\infty,1)` |
| ED-Q-06 | N2 | `y'=1+y^{2},\ y(0)=0`: solución e intervalo máximo | `y=\tan x`, en `\left(-\frac{\pi}{2},\frac{\pi}{2}\right)` |
| ED-Q-07 | N3 | `y'=y^{2/3},\ y(0)=0` | no hay unicidad: `y=0` y `y=\frac{x^{3}}{27}` |
| ED-Q-08 | N2 | Trayectorias ortogonales a `y=Cx^{2}` | `x^{2}+2y^{2}=K` |
| ED-Q-09 | N2 | Trayectorias ortogonales a `y=Ce^{x}` | `y^{2}=-2x+K` |
| ED-Q-10 | N2 | Trayectorias ortogonales a `x^{2}+y^{2}=C` | `y=Kx` |
| ED-Q-11 | N2 | Iteración de Picard para `y'=y,\ y(0)=1` | `1,\ 1+x,\ 1+x+\frac{x^{2}}{2},\ \ldots` |
| ED-Q-12 | N2 | Picard para `y'=x+y,\ y(0)=0` | `y_{1}=\frac{x^{2}}{2},\ y_{2}=\frac{x^{2}}{2}+\frac{x^{3}}{6}`; exacta `y=e^{x}-x-1` |
| ED-Q-13 | N1 | Euler para `y'=y,\ y(0)=1`, `h=0.1`, `y(1)` | `1.1^{10}\approx 2.593742460` |
| ED-Q-14 | N2 | Heun (Euler mejorado) para `y'=y,\ y(0)=1`, `h=0.1`, un paso | `1.105` |
| ED-Q-15 | N2 | RK4 para `y'=y,\ y(0)=1`, `h=1`, un paso | `\frac{65}{24}\approx 2.708333333` |
| ED-Q-16 | N2 | Euler para `y'=y^{2},\ y(0)=1`, `h=0.5`, dos pasos | `y(1)\approx 2.625` (la solución exacta explota en `x=1`) |
| ED-Q-17 | N2 | `a_{n+1}=2a_{n},\ a_{0}=3` | `a_{n}=3\cdot 2^{n}` |
| ED-Q-18 | N2 | Fibonacci `F_{n+2}=F_{n+1}+F_{n},\ F_{0}=0,\ F_{1}=1` | `F_{n}=\frac{\varphi^{n}-\psi^{n}}{\sqrt{5}},\ \varphi=\frac{1+\sqrt{5}}{2},\ \psi=\frac{1-\sqrt{5}}{2}` |
| ED-Q-19 | N2 | `a_{n+2}-4a_{n+1}+4a_{n}=0,\ a_{0}=1,\ a_{1}=4` | `a_{n}=(n+1)2^{n}` |
| ED-Q-20 | N3 | `a_{n+2}+a_{n}=0,\ a_{0}=1,\ a_{1}=0` | `a_{n}=\cos\frac{n\pi}{2}` |
| ED-Q-21 | N2 | `a_{n+1}=a_{n}+n,\ a_{0}=0` | `a_{n}=\frac{n(n-1)}{2}` |
| ED-Q-22 | N3 | Con retardo `y'(t)=y(t-1)`, `y(t)=1` para `t\le0` | `y=1+t` en `[0,1]`; `y=\frac{t^{2}+3}{2}` en `[1,2]` |
| ED-Q-23 | N3 | `y'=\frac{\sin x}{x},\ y(0)=0` | `y=\operatorname{Si}(x)` |
| ED-Q-24 | N3 | `y'=e^{-x^{2}},\ y(0)=0` | `y=\frac{\sqrt{\pi}}{2}\operatorname{erf}(x)` |
| ED-Q-25 | N3 | `y'=x^{2}+y^{2}` | sin forma elemental; `y=-\frac{u'}{u}` con `u''+x^{2}u=0` (Bessel) |

---

## A8. Casos límite y manejo de errores en ecuaciones diferenciales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| ED-CL-01 | N2 | `y'=\frac{y}{x},\ y(0)=1` | sin solución (toda solución `y=Cx` cumple `y(0)=0`) |
| ED-CL-02 | N2 | `y'=\frac{y}{x},\ y(0)=0` | infinitas soluciones `y=Cx` |
| ED-CL-03 | N2 | `y'=\sqrt{\lvert y\rvert},\ y(0)=0` | no hay unicidad (`y=0` y `y=\frac{x\lvert x\rvert}{4}`) |
| ED-CL-04 | N3 | Evaluar en `x=2` la solución de `y'=y^{2},\ y(0)=1` | fuera del intervalo máximo `(-\infty,1)` (error claro; `\frac{1}{1-x}` daría `-1`, que no es solución) |
| ED-CL-05 | N2 | `y'=\frac{x}{y},\ y(0)=0` | `y^{2}=x^{2}`: `y=\pm x`; la ecuación es singular en `y=0` |
| ED-CL-06 | N2 | `y''+y=0,\ y(0)=0,\ y(\pi)=1` | sin solución (problema de frontera incompatible) |

---

# PARTE B — VARIABLE COMPLEJA

## B1. Conversión entre las cuatro formas de representación

Notación de la columna "De → A": **B** binómica, **P** polar, **T** trigonométrica, **X** exponencial. Se espera el argumento principal normalizado.

### B1.B Desde la forma binómica

| ID | Nivel | De → A | Ejercicio | Resultado esperado |
|---|---|---|---|---|
| VC-CV-B-01 | N1 | B → P, T, X | `z=1+i` | P: `\sqrt{2}_{\pi/4}` · T: `\sqrt{2}\left(\cos\frac{\pi}{4}+i\sin\frac{\pi}{4}\right)` · X: `\sqrt{2}e^{i\pi/4}` |
| VC-CV-B-02 | N1 | B → P, T, X | `z=1+i\sqrt{3}` | P: `2_{\pi/3}` · T: `2\left(\cos\frac{\pi}{3}+i\sin\frac{\pi}{3}\right)` · X: `2e^{i\pi/3}` |
| VC-CV-B-03 | N1 | B → P, T, X | `z=-1+i` | P: `\sqrt{2}_{3\pi/4}` · T: `\sqrt{2}\left(\cos\frac{3\pi}{4}+i\sin\frac{3\pi}{4}\right)` · X: `\sqrt{2}e^{3i\pi/4}` |
| VC-CV-B-04 | N2 | B → P, T, X | `z=-1-i` | P: `\sqrt{2}_{-3\pi/4}` · T: `\sqrt{2}\left(\cos\frac{3\pi}{4}-i\sin\frac{3\pi}{4}\right)` · X: `\sqrt{2}e^{-3i\pi/4}` (no `\frac{5\pi}{4}`) |
| VC-CV-B-05 | N2 | B → P, T, X | `z=1-i\sqrt{3}` | P: `2_{-\pi/3}` · T: `2\left(\cos\frac{\pi}{3}-i\sin\frac{\pi}{3}\right)` · X: `2e^{-i\pi/3}` |
| VC-CV-B-06 | N2 | B → P, T, X | `z=-\sqrt{3}+i` | P: `2_{5\pi/6}` · T: `2\left(\cos\frac{5\pi}{6}+i\sin\frac{5\pi}{6}\right)` · X: `2e^{5i\pi/6}` |
| VC-CV-B-07 | N1 | B → P, T, X | `z=i` | P: `1_{\pi/2}` · T: `\cos\frac{\pi}{2}+i\sin\frac{\pi}{2}` · X: `e^{i\pi/2}` |
| VC-CV-B-08 | N1 | B → P, T, X | `z=-i` | P: `1_{-\pi/2}` · T: `\cos\frac{\pi}{2}-i\sin\frac{\pi}{2}` · X: `e^{-i\pi/2}` |
| VC-CV-B-09 | N2 | B → P, T, X | `z=-2` | P: `2_{\pi}` · T: `2(\cos\pi+i\sin\pi)` · X: `2e^{i\pi}` (argumento `\pi`, no `-\pi`) |
| VC-CV-B-10 | N1 | B → P, T, X | `z=3` | P: `3_{0}` · T: `3(\cos 0+i\sin 0)` · X: `3` |
| VC-CV-B-11 | N2 | B → P, T, X | `z=3+4i` | P: `5_{\alpha}` con `\alpha=\arctan\frac{4}{3}\approx0.927295218` (`53.130102354^{\circ}`) · X: `5e^{i\alpha}` |
| VC-CV-B-12 | N2 | B → P, T, X | `z=-3+4i` | P: `5_{\pi-\arctan(4/3)}`, `\approx 5_{2.214297436}` (`126.869897646^{\circ}`) |
| VC-CV-B-13 | N2 | B → P, T, X | `z=5-12i` | P: `13_{-\arctan(12/5)}`, `\approx13_{-1.176005207}` |
| VC-CV-B-14 | N2 | B → P, T, X | `z=-5-12i` | P: `13_{\arctan(12/5)-\pi}`, `\approx13_{-1.965587447}` |
| VC-CV-B-15 | N2 | B → P, T, X | `z=\frac{1}{2}-\frac{\sqrt{3}}{2}i` | P: `1_{-\pi/3}` · X: `e^{-i\pi/3}` |
| VC-CV-B-16 | N3 | B → P, T, X | `z=\sqrt{2+\sqrt{2}}+i\sqrt{2-\sqrt{2}}` | P: `2_{\pi/8}` · X: `2e^{i\pi/8}` |
| VC-CV-B-17 | N3 | B → P, T, X | `z=0` | módulo `0`; argumento indefinido (aviso claro) |

### B1.P Desde la forma polar

| ID | Nivel | De → A | Ejercicio | Resultado esperado |
|---|---|---|---|---|
| VC-CV-P-01 | N1 | P → B, T, X | `2_{\pi/3}` | B: `1+i\sqrt{3}` · X: `2e^{i\pi/3}` |
| VC-CV-P-02 | N1 | P → B, T, X | `4_{\pi/2}` | B: `4i` |
| VC-CV-P-03 | N1 | P → B, T, X | `1_{\pi}` | B: `-1` |
| VC-CV-P-04 | N2 | P → B, T, X | `6_{5\pi/6}` | B: `-3\sqrt{3}+3i` |
| VC-CV-P-05 | N2 | P → B, T, X | `2_{-\pi/6}` | B: `\sqrt{3}-i` |
| VC-CV-P-06 | N2 | P → B, T, X | `3_{7\pi/4}` | B: `\frac{3\sqrt{2}}{2}-\frac{3\sqrt{2}}{2}i`; normalizado `3_{-\pi/4}` |
| VC-CV-P-07 | N2 | P → B, T, X | `2_{9\pi/4}` | B: `\sqrt{2}+\sqrt{2}i`; normalizado `2_{\pi/4}` |
| VC-CV-P-08 | N2 | P → B, T, X | `5_{60^{\circ}}` | B: `\frac{5}{2}+\frac{5\sqrt{3}}{2}i` |
| VC-CV-P-09 | N2 | P → B, T, X | `2_{225^{\circ}}` | B: `-\sqrt{2}-\sqrt{2}i`; normalizado `2_{-135^{\circ}}` |
| VC-CV-P-10 | N3 | P → B, T, X | `(-2)_{\pi/3}` (módulo negativo) | B: `-1-i\sqrt{3}`; normalizado `2_{-2\pi/3}` (o aviso de módulo inválido) |

### B1.T Desde la forma trigonométrica

| ID | Nivel | De → A | Ejercicio | Resultado esperado |
|---|---|---|---|---|
| VC-CV-T-01 | N1 | T → B, P, X | `2\left(\cos\frac{\pi}{6}+i\sin\frac{\pi}{6}\right)` | B: `\sqrt{3}+i` · P: `2_{\pi/6}` · X: `2e^{i\pi/6}` |
| VC-CV-T-02 | N1 | T → B, P, X | `\cos\frac{\pi}{2}+i\sin\frac{\pi}{2}` | B: `i` · P: `1_{\pi/2}` |
| VC-CV-T-03 | N2 | T → B, P, X | `4\left(\cos\frac{2\pi}{3}+i\sin\frac{2\pi}{3}\right)` | B: `-2+2\sqrt{3}i` · P: `4_{2\pi/3}` |
| VC-CV-T-04 | N2 | T → B, P, X | `3\left(\cos 210^{\circ}+i\sin 210^{\circ}\right)` | B: `-\frac{3\sqrt{3}}{2}-\frac{3}{2}i` · P normalizado: `3_{-150^{\circ}}` |
| VC-CV-T-05 | N2 | T → B, P, X | `2\left(\cos\frac{\pi}{5}+i\sin\frac{\pi}{5}\right)` | B: `\approx1.618033989+1.175570505i` |
| VC-CV-T-06 | N3 | T → B, P, X | `-2\left(\cos\frac{\pi}{6}+i\sin\frac{\pi}{6}\right)` | B: `-\sqrt{3}-i` · P: `2_{-5\pi/6}` |
| VC-CV-T-07 | N3 | T → B, P, X | `2\left(\cos\frac{\pi}{6}-i\sin\frac{\pi}{6}\right)` | B: `\sqrt{3}-i` · P: `2_{-\pi/6}` |
| VC-CV-T-08 | N3 | T → B, P, X | `2\left(\sin\frac{\pi}{3}+i\cos\frac{\pi}{3}\right)` (seno y coseno permutados) | B: `\sqrt{3}+i` · P: `2_{\pi/6}` |
| VC-CV-T-09 | N3 | T → P, X | `1+\cos\theta+i\sin\theta,\ 0<\theta<\pi` | P: `\left(2\cos\frac{\theta}{2}\right)_{\theta/2}` · X: `2\cos\frac{\theta}{2}\,e^{i\theta/2}` |
| VC-CV-T-10 | N3 | T → P, X | `1-\cos\theta+i\sin\theta,\ 0<\theta<\pi` | módulo `2\sin\frac{\theta}{2}`, argumento `\frac{\pi-\theta}{2}` |

### B1.X Desde la forma exponencial

| ID | Nivel | De → A | Ejercicio | Resultado esperado |
|---|---|---|---|---|
| VC-CV-X-01 | N1 | X → B, P, T | `e^{i\pi}` | B: `-1` · P: `1_{\pi}` |
| VC-CV-X-02 | N1 | X → B, P, T | `2e^{i\pi/2}` | B: `2i` |
| VC-CV-X-03 | N1 | X → B, P, T | `e^{-i\pi/3}` | B: `\frac{1}{2}-\frac{\sqrt{3}}{2}i` |
| VC-CV-X-04 | N2 | X → B, P, T | `3e^{i\pi/4}` | B: `\frac{3\sqrt{2}}{2}+\frac{3\sqrt{2}}{2}i` |
| VC-CV-X-05 | N2 | X → B, P, T | `e^{1+i\pi}` | B: `-e\approx-2.718281828` · P: `e_{\pi}` |
| VC-CV-X-06 | N2 | X → B, P, T | `e^{2+i}` | B: `\approx3.992324048+6.217676312i` · P: `\left(e^{2}\right)_{1}` |
| VC-CV-X-07 | N2 | X → B, P, T | `e^{i}` | B: `\approx0.540302306+0.841470985i` |
| VC-CV-X-08 | N3 | X → B, P, T | `e^{i\pi/3+2\pi i}` | normalizado `e^{i\pi/3}`; B: `\frac{1}{2}+\frac{\sqrt{3}}{2}i` |
| VC-CV-X-09 | N3 | X → B, P, T | `2e^{-5i\pi/3}` | normalizado `2e^{i\pi/3}`; B: `1+i\sqrt{3}` |
| VC-CV-X-10 | N3 | X → B, P, T | `e^{\ln 2+i\pi/3}` | B: `1+i\sqrt{3}` |
| VC-CV-X-11 | N3 | X → B, P, T | `-e^{i\pi/6}` | B: `-\frac{\sqrt{3}}{2}-\frac{i}{2}` · P: `1_{-5\pi/6}` |
| VC-CV-X-12 | N2 | X → B, P, T | `e^{-i\theta},\ \theta\in\mathbb{R}` | T: `\cos\theta-i\sin\theta` · P: `1_{-\theta}` |

---

## B2. Operaciones en cada forma

### B2.B Forma binómica

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-OP-B-01 | N1 | `(2+3i)+(1-i)` | `3+2i` |
| VC-OP-B-02 | N1 | `(2+3i)-(1-i)` | `1+4i` |
| VC-OP-B-03 | N1 | `(2+3i)(1-i)` | `5+i` |
| VC-OP-B-04 | N2 | `\frac{3+4i}{1-2i}` | `-1+2i` |
| VC-OP-B-05 | N2 | `\frac{(2+i)^{2}}{3-4i}` | `\frac{-7+24i}{25}` |
| VC-OP-B-06 | N1 | `i^{2026}` | `-1` |
| VC-OP-B-07 | N2 | `(1+i)^{10}` | `32i` |
| VC-OP-B-08 | N2 | `\frac{1+i}{1-i}` | `i` |
| VC-OP-B-09 | N1 | `\overline{3-4i}` y `\lvert3-4i\rvert` | `3+4i` y `5` |
| VC-OP-B-10 | N2 | `\operatorname{Re}\frac{1}{1+i}` y `\operatorname{Im}\frac{1}{1+i}` | `\frac{1}{2}` y `-\frac{1}{2}` |
| VC-OP-B-11 | N2 | `\frac{1}{i}+\frac{1}{1+i}` | `\frac{1}{2}-\frac{3}{2}i` |

### B2.P Forma polar

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-OP-P-01 | N1 | `2_{\pi/6}\cdot3_{\pi/3}` | `6_{\pi/2}=6i` |
| VC-OP-P-02 | N1 | `\frac{8_{\pi}}{2_{\pi/2}}` | `4_{\pi/2}=4i` |
| VC-OP-P-03 | N2 | `\left(2_{\pi/6}\right)^{3}` | `8_{\pi/2}=8i` |
| VC-OP-P-04 | N2 | `\left(\sqrt{2}_{\pi/4}\right)^{4}` | `4_{\pi}=-4` |
| VC-OP-P-05 | N2 | `\frac{1}{2_{\pi/3}}` | `\left(\frac{1}{2}\right)_{-\pi/3}` |
| VC-OP-P-06 | N2 | `\overline{3_{\pi/5}}` | `3_{-\pi/5}` |
| VC-OP-P-07 | N2 | `2_{3\pi/4}\cdot3_{3\pi/4}` | `6_{3\pi/2}`; normalizado `6_{-\pi/2}=-6i` |
| VC-OP-P-08 | N2 | `\left(1_{\pi/3}\right)^{6}` | `1_{0}=1` |
| VC-OP-P-09 | N3 | `\left(2_{-\pi/4}\right)^{8}` | `256` |

### B2.T Forma trigonométrica (De Moivre)

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-OP-T-01 | N2 | `\left(\cos\frac{\pi}{12}+i\sin\frac{\pi}{12}\right)^{6}` | `i` |
| VC-OP-T-02 | N2 | `\left[2\left(\cos15^{\circ}+i\sin15^{\circ}\right)\right]^{4}` | `8+8\sqrt{3}i` |
| VC-OP-T-03 | N2 | `\frac{\cos\frac{2\pi}{3}+i\sin\frac{2\pi}{3}}{\cos\frac{\pi}{6}+i\sin\frac{\pi}{6}}` | `i` |
| VC-OP-T-04 | N2 | `\left(\cos\theta+i\sin\theta\right)^{n}` | `\cos n\theta+i\sin n\theta` |
| VC-OP-T-05 | N2 | `(\cos\alpha+i\sin\alpha)(\cos\beta+i\sin\beta)` | `\cos(\alpha+\beta)+i\sin(\alpha+\beta)` |
| VC-OP-T-06 | N3 | `\cos3\theta` mediante De Moivre | `4\cos^{3}\theta-3\cos\theta` |
| VC-OP-T-07 | N3 | `\sin3\theta` mediante De Moivre | `3\sin\theta-4\sin^{3}\theta` |
| VC-OP-T-08 | N3 | `\cos^{4}\theta` como suma de cosenos | `\frac{3+4\cos2\theta+\cos4\theta}{8}` |
| VC-OP-T-09 | N3 | `\sum_{k=0}^{n}\cos k\theta` | `\frac{\sin\frac{(n+1)\theta}{2}\cos\frac{n\theta}{2}}{\sin\frac{\theta}{2}}` |

### B2.X Forma exponencial

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-OP-X-01 | N1 | `e^{i\pi/3}\cdot e^{i\pi/6}` | `i` |
| VC-OP-X-02 | N2 | `\frac{e^{i\pi}}{e^{-i\pi/2}}` | `-i` |
| VC-OP-X-03 | N2 | `\left(e^{i\pi/4}\right)^{8}` | `1` |
| VC-OP-X-04 | N2 | `\left(2e^{i\pi/6}\right)^{5}` | `-16\sqrt{3}+16i` |
| VC-OP-X-05 | N1 | `e^{i\theta}+e^{-i\theta}` | `2\cos\theta` |
| VC-OP-X-06 | N1 | `e^{i\theta}-e^{-i\theta}` | `2i\sin\theta` |
| VC-OP-X-07 | N2 | `e^{i\pi}+1` | `0` |
| VC-OP-X-08 | N2 | `\overline{re^{i\theta}}` | `re^{-i\theta}` |
| VC-OP-X-09 | N2 | `\left\lvert e^{a+bi}\right\rvert,\ a,b\in\mathbb{R}` | `e^{a}` |
| VC-OP-X-10 | N2 | `\left(e^{i\theta}\right)^{n}` | `e^{in\theta}` |
| VC-OP-X-11 | N3 | `\frac{1}{1-e^{i\theta}},\ \theta\notin2\pi\mathbb{Z}` | `\frac{1}{2}+\frac{i}{2}\cot\frac{\theta}{2}` |
| VC-OP-X-12 | N3 | `\left\lvert1+e^{i\theta}\right\rvert` | `2\left\lvert\cos\frac{\theta}{2}\right\rvert` |

---

## B3. Potencias y raíces

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-PR-01 | N2 | `\left(1+i\sqrt{3}\right)^{9}` | `-512` |
| VC-PR-02 | N2 | `\left(\sqrt{3}-i\right)^{6}` | `-64` |
| VC-PR-03 | N2 | `\left(\frac{-1+i\sqrt{3}}{2}\right)^{3}` | `1` |
| VC-PR-04 | N2 | `(1+i)^{20}` | `-1024` |
| VC-PR-05 | N2 | `(1+i)^{-4}` | `-\frac{1}{4}` |
| VC-PR-06 | N2 | `\left(\frac{1+i}{\sqrt{2}}\right)^{8}` | `1` |
| VC-PR-07 | N2 | `\sqrt{i}` (ambas raíces) | `\pm\frac{\sqrt{2}}{2}(1+i)` |
| VC-PR-08 | N2 | `\sqrt{-3+4i}` | `\pm(1+2i)` |
| VC-PR-09 | N2 | `\sqrt{5-12i}` | `\pm(3-2i)` |
| VC-PR-10 | N2 | `\sqrt[3]{8}` (todas) | `2,\ -1+i\sqrt{3},\ -1-i\sqrt{3}` (exponencial: `2e^{2\pi ik/3}`) |
| VC-PR-11 | N2 | `\sqrt[3]{-8}` (todas) | `1+i\sqrt{3},\ -2,\ 1-i\sqrt{3}` |
| VC-PR-12 | N3 | `\sqrt[3]{i}` (todas) | `\frac{\sqrt{3}}{2}+\frac{i}{2},\ -\frac{\sqrt{3}}{2}+\frac{i}{2},\ -i` |
| VC-PR-13 | N3 | `\sqrt[4]{-4}` (todas) | `\pm1\pm i` |
| VC-PR-14 | N2 | `\sqrt[4]{1}` (todas) | `1,\ i,\ -1,\ -i` |
| VC-PR-15 | N2 | `\sqrt[6]{1}` (todas) | `e^{i\pi k/3},\ k=0,\ldots,5` |
| VC-PR-16 | N3 | `\sqrt[3]{1+i}` (raíz principal) | `2^{1/6}e^{i\pi/12}\approx1.084215+0.290515i` |
| VC-PR-17 | N3 | `\sum_{k=0}^{n-1}e^{2\pi ik/n},\ n\ge2` | `0` |
| VC-PR-18 | N3 | Producto de las raíces cuartas de la unidad | `-1` (en general `(-1)^{n+1}`) |
| VC-PR-19 | N3 | `\cos\frac{2\pi}{5}` a partir de `z^{5}=1` | `\frac{\sqrt{5}-1}{4}\approx0.309016994` |

---

## B4. Ecuaciones en $\mathbb{C}$

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-EC-01 | N1 | `z^{2}+1=0` | `z=\pm i` |
| VC-EC-02 | N1 | `z^{2}+2z+5=0` | `z=-1\pm2i` |
| VC-EC-03 | N2 | `z^{2}-2iz-1=0` | `z=i` (raíz doble) |
| VC-EC-04 | N2 | `z^{2}-(3+i)z+(2+i)=0` | `z=1,\ z=2+i` |
| VC-EC-05 | N2 | `z^{2}+(1-2i)z-2i=0` | `z=2i,\ z=-1` |
| VC-EC-06 | N2 | `z^{2}=3+4i` | `z=\pm(2+i)` |
| VC-EC-07 | N2 | `z^{2}=-5+12i` | `z=\pm(2+3i)` |
| VC-EC-08 | N2 | `z^{3}=1` | `z=1,\ -\frac{1}{2}\pm\frac{\sqrt{3}}{2}i` |
| VC-EC-09 | N2 | `z^{4}+4=0` | `z=\pm1\pm i` |
| VC-EC-10 | N2 | `z^{6}=64` | `z=2e^{i\pi k/3},\ k=0,\ldots,5` |
| VC-EC-11 | N2 | `z^{3}+z^{2}+z+1=0` | `z=-1,\ \pm i` |
| VC-EC-12 | N3 | `z^{4}+z^{2}+1=0` | `z=\pm\frac{1}{2}\pm\frac{\sqrt{3}}{2}i` |
| VC-EC-13 | N2 | `z^{3}-3z^{2}+3z-2=0` | `z=2,\ \frac{1\pm i\sqrt{3}}{2}` |
| VC-EC-14 | N2 | `(1+i)z=2-i` | `z=\frac{1-3i}{2}` |
| VC-EC-15 | N2 | `\frac{z-i}{z+i}=2` | `z=-3i` |
| VC-EC-16 | N3 | `z^{2}+\bar z=0` | `z=0,\ -1,\ \frac{1}{2}\pm\frac{\sqrt{3}}{2}i` |
| VC-EC-17 | N3 | `z^{2}=\bar z` | `z=0,\ 1,\ -\frac{1}{2}\pm\frac{\sqrt{3}}{2}i` |
| VC-EC-18 | N3 | `z^{3}=\bar z` | `z=0,\ \pm1,\ \pm i` |
| VC-EC-19 | N2 | `z\bar z+2z=3+2i` | `z=-1\pm\sqrt{3}+i` |
| VC-EC-20 | N3 | `\lvert z\rvert-z=1+2i` | `z=\frac{3}{2}-2i` |
| VC-EC-21 | N2 | `\lvert z\rvert=z^{2}` | `z=0,\ 1,\ -1` |
| VC-EC-22 | N2 | `\begin{cases}z_{1}+z_{2}=1+i\\ z_{1}-z_{2}=1-i\end{cases}` | `z_{1}=1,\ z_{2}=i` |
| VC-EC-23 | N2 | `e^{z}=1` | `z=2\pi ik` |
| VC-EC-24 | N2 | `e^{z}=-1` | `z=i\pi(2k+1)` |
| VC-EC-25 | N2 | `e^{z}=1+i` | `z=\frac{1}{2}\ln2+i\left(\frac{\pi}{4}+2\pi k\right)` |
| VC-EC-26 | N2 | `e^{2z}-3e^{z}+2=0` | `z=2\pi ik` o `z=\ln2+2\pi ik` |
| VC-EC-27 | N2 | `\sin z=0` | `z=k\pi` |
| VC-EC-28 | N3 | `\sin z=2` | `z=\frac{\pi}{2}+2\pi k\pm i\ln\left(2+\sqrt{3}\right)` |
| VC-EC-29 | N3 | `\cos z=2` | `z=2\pi k\pm i\ln\left(2+\sqrt{3}\right)` |
| VC-EC-30 | N3 | `\sin z=i` | `z=2\pi k+i\ln\left(1+\sqrt{2}\right)` o `z=(2k+1)\pi-i\ln\left(1+\sqrt{2}\right)` |
| VC-EC-31 | N3 | `\tan z=i` | sin solución |
| VC-EC-32 | N2 | `\cosh z=0` | `z=i\pi\left(\frac{1}{2}+k\right)` |
| VC-EC-33 | N2 | `\cosh z=2` | `z=\pm\ln\left(2+\sqrt{3}\right)+2\pi ik` |
| VC-EC-34 | N2 | `\operatorname{Log}z=1+\frac{i\pi}{2}` | `z=ie` |

---

## B5. Lugares geométricos y desigualdades

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-LG-01 | N1 | `\lvert z\rvert=2` | circunferencia de centro `0` y radio `2` |
| VC-LG-02 | N1 | `\lvert z-1\rvert<2` | disco abierto de centro `1` y radio `2` |
| VC-LG-03 | N1 | `1<\lvert z\rvert\le2` | corona circular |
| VC-LG-04 | N1 | `\operatorname{Re}z>1` | semiplano `x>1` |
| VC-LG-05 | N1 | `\arg z=\frac{\pi}{4}` | semirrecta `y=x,\ x>0` |
| VC-LG-06 | N2 | `\frac{\pi}{6}\le\arg z\le\frac{\pi}{3}` | sector angular |
| VC-LG-07 | N2 | `\operatorname{Re}\left(z^{2}\right)=1` | hipérbola `x^{2}-y^{2}=1` |
| VC-LG-08 | N2 | `\operatorname{Im}\left(z^{2}\right)=2` | hipérbola `xy=1` |
| VC-LG-09 | N2 | `\lvert z-1\rvert=\lvert z+1\rvert` | eje imaginario `x=0` |
| VC-LG-10 | N3 | `\lvert z-1\rvert=2\lvert z+1\rvert` | circunferencia de centro `-\frac{5}{3}` y radio `\frac{4}{3}` |
| VC-LG-11 | N2 | `\lvert z-1\rvert+\lvert z+1\rvert=4` | elipse `\frac{x^{2}}{4}+\frac{y^{2}}{3}=1` |
| VC-LG-12 | N3 | `\lvert z-2\rvert-\lvert z+2\rvert=2` | rama izquierda `x\le-1` de `x^{2}-\frac{y^{2}}{3}=1` |
| VC-LG-13 | N3 | `\operatorname{Re}\frac{1}{z}=\frac{1}{2}` | circunferencia `(x-1)^{2}+y^{2}=1`, sin `z=0` |
| VC-LG-14 | N3 | `\operatorname{Im}\frac{1}{z}>1` | disco abierto `x^{2}+\left(y+\frac{1}{2}\right)^{2}<\frac{1}{4}` |
| VC-LG-15 | N3 | `\lvert z\rvert<\operatorname{Re}z+1` | interior de la parábola `y^{2}<2x+1` |
| VC-LG-16 | N3 | `\lvert z\rvert=\operatorname{Re}z+1` | parábola `y^{2}=2x+1` |
| VC-LG-17 | N3 | `\operatorname{Re}\frac{z-1}{z+1}=0` | circunferencia `\lvert z\rvert=1`, sin `z=-1` |
| VC-LG-18 | N2 | `\frac{z-1}{z+1}\in\mathbb{R}` | eje real, sin `z=-1` |
| VC-LG-19 | N2 | `z^{2}\in\mathbb{R}` | ejes real e imaginario |
| VC-LG-20 | N2 | `\operatorname{Im}\left(z^{2}\right)>0` | primer y tercer cuadrantes (`xy>0`) |
| VC-LG-21 | N2 | `\operatorname{Re}(iz)>0` | semiplano inferior `y<0` |
| VC-LG-22 | N2 | Curva `z=2e^{it},\ t\in[0,\pi]` (forma exponencial) | semicircunferencia superior de radio `2` |
| VC-LG-23 | N2 | Curva `z=1+e^{it},\ t\in[0,2\pi]` | circunferencia de centro `1` y radio `1` |
| VC-LG-24 | N2 | Curva `z=2\left(\cos t+i\sin t\right),\ t\in[0,\pi]` (forma trigonométrica) | semicircunferencia superior de radio `2` |
| VC-LG-25 | N3 | Curva `z=\cosh t+i\sinh t` | rama derecha de la hipérbola `x^{2}-y^{2}=1` |

---

## B6. Funciones elementales y multivaluadas

### B6.E Exponencial y logaritmo

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-FE-01 | N1 | `e^{i\pi/2}` | `i` |
| VC-FE-02 | N2 | `e^{-i\pi/4}` | `\frac{\sqrt{2}}{2}(1-i)` |
| VC-FE-03 | N2 | `e^{\ln2+i\pi/3}` | `1+i\sqrt{3}` |
| VC-FE-04 | N2 | `\lvert e^{z}\rvert`, `z=x+iy` | `e^{x}` |
| VC-FE-05 | N1 | `\operatorname{Log}(-1)` | `i\pi` |
| VC-FE-06 | N1 | `\operatorname{Log}(i)` | `\frac{i\pi}{2}` |
| VC-FE-07 | N2 | `\operatorname{Log}(1+i)` | `\frac{1}{2}\ln2+\frac{i\pi}{4}` |
| VC-FE-08 | N2 | `\operatorname{Log}(-1-i)` | `\frac{1}{2}\ln2-\frac{3\pi i}{4}` |
| VC-FE-09 | N2 | `\operatorname{Log}(3-3i)` | `\frac{1}{2}\ln18-\frac{i\pi}{4}\approx1.445186-0.785398i` |
| VC-FE-10 | N2 | `\operatorname{Log}(-e)` | `1+i\pi` |
| VC-FE-11 | N2 | `\log(1)` (multivaluado) | `2\pi ik` |
| VC-FE-12 | N3 | `\operatorname{Log}((-1)(-1))` frente a `\operatorname{Log}(-1)+\operatorname{Log}(-1)` | `0` frente a `2\pi i` (no es aditivo) |
| VC-FE-13 | N3 | `\operatorname{Log}\left(e^{3\pi i}\right)` | `i\pi` (no `3\pi i`) |
| VC-FE-14 | N2 | `\operatorname{Log}(0)` | indefinido (error claro) |

### B6.P Potencias complejas y ramas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-FE-15 | N2 | `i^{i}` (valor principal) | `e^{-\pi/2}\approx0.207879576`; todos los valores `e^{-\pi/2-2\pi k}` |
| VC-FE-16 | N2 | `(-1)^{i}` | `e^{-\pi}\approx0.043213918` |
| VC-FE-17 | N2 | `2^{i}` | `\cos(\ln2)+i\sin(\ln2)\approx0.769239+0.638961i` |
| VC-FE-18 | N3 | `(1+i)^{i}` | `e^{-\pi/4}\left(\cos\frac{\ln2}{2}+i\sin\frac{\ln2}{2}\right)\approx0.4288+0.1549i` |
| VC-FE-19 | N2 | `(-1)^{1/3}` (valor principal) | `\frac{1}{2}+\frac{\sqrt{3}}{2}i` |
| VC-FE-20 | N3 | `\sqrt{z^{2}}` en `z=-i` | `i` (no `-i`) |
| VC-FE-21 | N3 | `\sqrt{-1}\cdot\sqrt{-1}` frente a `\sqrt{(-1)(-1)}` | `-1` frente a `1` |
| VC-FE-22 | N3 | `\sqrt{\frac{1}{z}}` frente a `\frac{1}{\sqrt{z}}` en `z=-1` | `i` frente a `-i` |

### B6.T Trigonométricas e hiperbólicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-FE-23 | N2 | `\sin(i)` | `i\sinh1\approx1.175201194i` |
| VC-FE-24 | N2 | `\cos(i)` | `\cosh1\approx1.543080635` |
| VC-FE-25 | N2 | `\tan(i)` | `i\tanh1\approx0.761594156i` |
| VC-FE-26 | N2 | `\cot(i)` | `-i\coth1\approx-1.313035285i` |
| VC-FE-27 | N2 | `\sin(1+i)` | `\sin1\cosh1+i\cos1\sinh1\approx1.298457581+0.634963915i` |
| VC-FE-28 | N2 | `\cos(1+i)` | `\cos1\cosh1-i\sin1\sinh1\approx0.833730025-0.988897706i` |
| VC-FE-29 | N2 | `\sin\left(\frac{\pi}{2}+i\right)` | `\cosh1` |
| VC-FE-30 | N2 | `\cos(\pi+i)` | `-\cosh1` |
| VC-FE-31 | N2 | `\sin(2i)` | `i\sinh2\approx3.626860408i` |
| VC-FE-32 | N3 | `\left\lvert\sin(x+iy)\right\rvert^{2}` | `\sin^{2}x+\sinh^{2}y` |
| VC-FE-33 | N3 | `\left\lvert\cos(x+iy)\right\rvert^{2}` | `\cos^{2}x+\sinh^{2}y` |
| VC-FE-34 | N2 | `\frac{e^{iz}+e^{-iz}}{2}` | `\cos z` |
| VC-FE-35 | N2 | `\frac{e^{iz}-e^{-iz}}{2i}` | `\sin z` |
| VC-FE-36 | N2 | `\sin^{2}z+\cos^{2}z` | `1` |
| VC-FE-37 | N2 | `\sinh(i\pi)` y `\cosh(i\pi)` | `0` y `-1` |
| VC-FE-38 | N2 | `\sinh\left(\frac{i\pi}{2}\right)` | `i` |
| VC-FE-39 | N2 | `\tanh\left(\frac{i\pi}{4}\right)` | `i` |
| VC-FE-40 | N2 | `\cosh(1+i\pi)` | `-\cosh1` |
| VC-FE-41 | N3 | `\sinh\left(1+\frac{i\pi}{2}\right)` | `i\cosh1` |

### B6.I Inversas trigonométricas e hiperbólicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-FE-42 | N2 | `-i\ln\left(iz+\sqrt{1-z^{2}}\right)` en `z=\frac{1}{2}` | `\frac{\pi}{6}` |
| VC-FE-43 | N2 | `\arcsin(i)` | `i\ln\left(1+\sqrt{2}\right)\approx0.881373587i` |
| VC-FE-44 | N2 | `\arccos(i)` | `\frac{\pi}{2}-i\ln\left(1+\sqrt{2}\right)` |
| VC-FE-45 | N3 | `\arcsin(2)` | `\frac{\pi}{2}\mp i\ln\left(2+\sqrt{3}\right)` (el signo depende de la convención sobre el corte; debe declararse) |
| VC-FE-46 | N3 | `\arctan(1+i)` | `\frac{1}{2}(\pi-\arctan2)+\frac{i}{4}\ln5\approx1.017222+0.402359i` |
| VC-FE-47 | N2 | `\frac{1}{2i}\ln\frac{1+iz}{1-iz}` en `z=1` | `\frac{\pi}{4}` |
| VC-FE-48 | N3 | `\arctan(i)` | indefinido (singularidad) |
| VC-FE-49 | N3 | `\arctan(2i)` | `\frac{\pi}{2}+\frac{i}{2}\ln3` (convención estándar; debe declararse) |
| VC-FE-50 | N2 | `\operatorname{arsinh}(i)` | `\frac{i\pi}{2}` |
| VC-FE-51 | N2 | `\operatorname{arcosh}(0)` | `\frac{i\pi}{2}` |
| VC-FE-52 | N2 | `\operatorname{arcosh}(-1)` | `i\pi` |
| VC-FE-53 | N3 | `\operatorname{artanh}(2)` | `\frac{1}{2}\ln3\pm\frac{i\pi}{2}` (debe declararse la convención) |

---

## B7. Límites, continuidad, sucesiones y series

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-LM-01 | N1 | `\lim_{z\to i}\frac{z^{2}+1}{z-i}` | `2i` |
| VC-LM-02 | N2 | `\lim_{z\to1+i}\frac{z^{2}-2z+2}{z-1-i}` | `2i` |
| VC-LM-03 | N1 | `\lim_{z\to0}\frac{\sin z}{z}` | `1` |
| VC-LM-04 | N1 | `\lim_{z\to0}\frac{e^{z}-1}{z}` | `1` |
| VC-LM-05 | N2 | `\lim_{z\to0}\frac{\cos z-1}{z^{2}}` | `-\frac{1}{2}` |
| VC-LM-06 | N2 | `\lim_{z\to0}\frac{\bar z}{z}` | no existe |
| VC-LM-07 | N2 | `\lim_{z\to0}\frac{\operatorname{Re}z}{z}` | no existe |
| VC-LM-08 | N2 | `\lim_{z\to0}\frac{z\bar z}{z}` | `0` |
| VC-LM-09 | N2 | `\lim_{z\to0}\frac{\operatorname{Re}\left(z^{2}\right)}{\lvert z\rvert^{2}}` | no existe |
| VC-LM-10 | N1 | `\lim_{z\to\infty}\frac{z^{2}+1}{2z^{2}-3}` | `\frac{1}{2}` |
| VC-LM-11 | N2 | `\lim_{z\to\infty}e^{z}` | no existe |
| VC-LM-12 | N2 | `\lim_{n\to\infty}\left(1+\frac{z}{n}\right)^{n}` | `e^{z}` |
| VC-LM-13 | N2 | `\lim_{n\to\infty}\left(1+\frac{i\pi}{n}\right)^{n}` | `-1` |
| VC-LM-14 | N2 | `\lim_{n\to\infty}\left(\frac{1+i}{2}\right)^{n}` | `0` |
| VC-LM-15 | N2 | `\lim_{n\to\infty}\left(\frac{1+i}{\sqrt{2}}\right)^{n}` | no existe (giro periódico de periodo `8`) |
| VC-LM-16 | N2 | `\lim_{n\to\infty}\frac{n+i}{2n-i}` | `\frac{1}{2}` |
| VC-LM-17 | N2 | `\lim_{n\to\infty}n\sin\frac{i}{n}` | `i` |
| VC-LM-18 | N2 | Continuidad de `\operatorname{Arg}z` | discontinua en el eje real negativo |
| VC-LM-19 | N2 | Continuidad de `\operatorname{Log}z` | continua en `\mathbb{C}\setminus(-\infty,0]` |
| VC-LM-20 | N2 | `\sum_{n=0}^{\infty}\left(\frac{1+i}{2}\right)^{n}` | `1+i` |
| VC-LM-21 | N3 | `\sum_{n=1}^{\infty}\frac{i^{n}}{n}` | `-\frac{1}{2}\ln2+\frac{i\pi}{4}` |
| VC-LM-22 | N3 | `\sum_{n=0}^{\infty}\frac{\cos n\theta}{2^{n}}` | `\frac{4-2\cos\theta}{5-4\cos\theta}` |
| VC-LM-23 | N3 | `\sum_{n=1}^{\infty}\frac{\sin n\theta}{2^{n}}` | `\frac{2\sin\theta}{5-4\cos\theta}` |
| VC-LM-24 | N2 | Radio de convergencia de `\sum\frac{z^{n}}{n!}` | `\infty` |
| VC-LM-25 | N2 | Radio de convergencia de `\sum n!\,z^{n}` | `0` |
| VC-LM-26 | N2 | Radio de convergencia de `\sum\frac{(z-i)^{n}}{2^{n}}` | `2` (centro `i`) |
| VC-LM-27 | N3 | Radio de convergencia de `\sum\frac{(n!)^{2}}{(2n)!}z^{n}` | `4` |

---

## B8. Derivabilidad, Cauchy–Riemann, Wirtinger y funciones armónicas

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-DV-01 | N1 | Cauchy–Riemann para `f(z)=z^{2}` | analítica en `\mathbb{C}`, `f'=2z` |
| VC-DV-02 | N2 | `f(z)=\bar z` | no derivable en ningún punto |
| VC-DV-03 | N2 | `f(z)=\lvert z\rvert^{2}` | derivable solo en `z=0`, con `f'(0)=0` |
| VC-DV-04 | N2 | `f=x^{2}+iy^{2}` | derivable en la recta `y=x`; analítica en ningún punto |
| VC-DV-05 | N2 | `f=e^{x}(\cos y+i\sin y)` | `f=e^{z}`, `f'=f` |
| VC-DV-06 | N2 | `f=x^{3}-3xy^{2}+i\left(3x^{2}y-y^{3}\right)` | `f=z^{3}` |
| VC-DV-07 | N2 | `f(z)=\operatorname{Re}z` | no derivable |
| VC-DV-08 | N1 | `\frac{d}{dz}\sin z` | `\cos z` |
| VC-DV-09 | N1 | `\frac{d}{dz}\operatorname{Log}z` | `\frac{1}{z}` |
| VC-DV-10 | N2 | `\frac{d}{dz}e^{z^{2}}` | `2ze^{z^{2}}` |
| VC-DV-11 | N2 | `\frac{d}{dz}\tan z` | `\sec^{2}z` |
| VC-DV-12 | N2 | `\frac{d}{dz}\arctan z` | `\frac{1}{1+z^{2}}` |
| VC-DV-13 | N2 | `\frac{d}{dz}z^{i}` (valor principal) | `iz^{i-1}` |
| VC-DV-14 | N2 | `\left.\frac{d}{dz}z^{3}\right\rvert_{z=1+i}` | `6i` |
| VC-DV-15 | N2 | `\left.\frac{d}{dz}e^{z}\right\rvert_{z=i\pi}` | `-1` |
| VC-DV-16 | N2 | `\left.\frac{d}{dz}\sin z\right\rvert_{z=i}` | `\cosh1\approx1.543080635` |
| VC-DV-17 | N2 | `\left.\frac{d}{dz}\frac{1}{z}\right\rvert_{z=i}` | `1` |
| VC-DV-18 | N2 | `\frac{\partial}{\partial z}\left(z\bar z\right)` | `\bar z` |
| VC-DV-19 | N2 | `\frac{\partial}{\partial\bar z}\left(z^{2}\bar z\right)` | `z^{2}` |
| VC-DV-20 | N2 | `\frac{\partial}{\partial\bar z}e^{z}` | `0` |
| VC-DV-21 | N2 | `\frac{\partial}{\partial z}\lvert z\rvert^{2}` | `\bar z` |
| VC-DV-22 | N3 | `\frac{\partial}{\partial\bar z}\lvert z\rvert` | `\frac{z}{2\lvert z\rvert}` |
| VC-DV-23 | N2 | `\frac{\partial}{\partial z}\operatorname{Re}z` | `\frac{1}{2}` |
| VC-DV-24 | N3 | `4\frac{\partial^{2}}{\partial z\,\partial\bar z}\left(x^{2}+y^{2}\right)` | `4` |
| VC-DV-25 | N1 | `u=x^{2}-y^{2}`: armónica y conjugada | `\Delta u=0`; `v=2xy+C`; `f=z^{2}` |
| VC-DV-26 | N2 | `u=e^{x}\cos y`: conjugada | `v=e^{x}\sin y`; `f=e^{z}` |
| VC-DV-27 | N2 | `u=\sin x\cosh y`: conjugada | `v=\cos x\sinh y`; `f=\sin z` |
| VC-DV-28 | N2 | `u=\frac{x}{x^{2}+y^{2}}`: conjugada | `v=-\frac{y}{x^{2}+y^{2}}`; `f=\frac{1}{z}` |
| VC-DV-29 | N2 | `u=x^{2}+y^{2}` | no armónica (`\Delta u=4`) |
| VC-DV-30 | N3 | `v=2xy+x`: hallar `u` y `f` | `u=x^{2}-y^{2}-y+C`; `f=z^{2}+iz+C'` |
| VC-DV-31 | N3 | `u=\ln\sqrt{x^{2}+y^{2}}`: conjugada | `v=\arg z` (multivaluada); `f=\log z` |
| VC-DV-32 | N3 | `u=xy`: conjugada | `v=\frac{y^{2}-x^{2}}{2}`; `f=-\frac{i}{2}z^{2}` |

---

## B9. Integrales de contorno y residuos

### B9.C Integrales de contorno

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-IN-01 | N1 | `\int_{\gamma}z\,dz,\ \gamma:z(t)=t+it,\ t\in[0,1]` | `i` |
| VC-IN-02 | N2 | `\oint_{\lvert z\rvert=1}\bar z\,dz` (antihorario) | `2\pi i` |
| VC-IN-03 | N2 | `\int_{\gamma}\operatorname{Re}z\,dz`, `\gamma`: de `0` a `1` y de `1` a `1+i` | `\frac{1}{2}+i` |
| VC-IN-04 | N2 | `\int_{\gamma}\operatorname{Re}z\,dz,\ \gamma:z(t)=t+it` | `\frac{1+i}{2}` (depende del camino) |
| VC-IN-05 | N1 | `\int_{0}^{1+i}e^{z}\,dz` | `e^{1+i}-1` |
| VC-IN-06 | N3 | `\int_{-i}^{i}\frac{dz}{z}` por la semicircunferencia `\lvert z\rvert=1,\ \operatorname{Re}z\ge0` | `i\pi` |
| VC-IN-07 | N3 | `\int_{-i}^{i}\frac{dz}{z}` por la semicircunferencia `\lvert z\rvert=1,\ \operatorname{Re}z\le0` | `-i\pi` |
| VC-IN-08 | N1 | `\oint_{\lvert z\rvert=1}\frac{dz}{z}` | `2\pi i` |
| VC-IN-09 | N1 | `\oint_{\lvert z\rvert=1}\frac{dz}{z-2}` | `0` |
| VC-IN-10 | N1 | `\oint_{\lvert z\rvert=2}\frac{dz}{z-1}` | `2\pi i` |
| VC-IN-11 | N2 | `\oint_{\lvert z\rvert=1}z^{n}\,dz,\ n\in\mathbb{Z}` | `2\pi i` si `n=-1`; `0` en otro caso |
| VC-IN-12 | N2 | `\oint_{\lvert z\rvert=2}\frac{e^{z}}{z}\,dz` | `2\pi i` |
| VC-IN-13 | N2 | `\oint_{\lvert z\rvert=2}\frac{e^{z}}{z^{2}}\,dz` | `2\pi i` |
| VC-IN-14 | N2 | `\oint_{\lvert z\rvert=1}\frac{\cos z}{z^{3}}\,dz` | `-\pi i` |
| VC-IN-15 | N2 | `\oint_{\lvert z\rvert=1}\frac{\sin z}{z^{2}}\,dz` | `2\pi i` |
| VC-IN-16 | N2 | `\oint_{\lvert z\rvert=2}\frac{dz}{z^{2}+1}` | `0` |
| VC-IN-17 | N2 | `\oint_{\lvert z\rvert=3}\frac{z}{(z-1)(z-2)}\,dz` | `2\pi i` |
| VC-IN-18 | N2 | `\oint_{\lvert z\rvert=3/2}\frac{z}{(z-1)(z-2)}\,dz` | `-2\pi i` |
| VC-IN-19 | N2 | `\oint_{\lvert z\rvert=2}\frac{dz}{z^{2}(z-1)}` | `0` |
| VC-IN-20 | N2 | `\oint_{\lvert z\rvert=1}\frac{e^{z}}{z^{n+1}}\,dz` | `\frac{2\pi i}{n!}` |
| VC-IN-21 | N2 | `\oint_{\lvert z\rvert=1}e^{1/z}\,dz` | `2\pi i` |
| VC-IN-22 | N3 | `\oint_{\lvert z\rvert=1}z^{2}e^{1/z}\,dz` | `\frac{\pi i}{3}` |
| VC-IN-23 | N3 | `\oint_{\lvert z\rvert=2}\tan z\,dz` | `-4\pi i` |
| VC-IN-24 | N2 | `\oint_{\lvert z\rvert=1}\frac{dz}{\sin z}` | `2\pi i` |
| VC-IN-25 | N3 | `\oint_{\lvert z\rvert=4}\frac{dz}{\sin z}` | `-2\pi i` |
| VC-IN-26 | N2 | `\oint_{\lvert z\rvert=2}\frac{\sin z}{(z-1)^{2}}\,dz` | `2\pi i\cos1` |
| VC-IN-27 | N2 | `\oint_{\lvert z-i\rvert=1}\frac{e^{z}}{z^{2}+1}\,dz` | `\pi e^{i}` |
| VC-IN-28 | N2 | `\oint_{\lvert z\rvert=3}\frac{e^{z}}{z^{2}+1}\,dz` | `2\pi i\sin1` |
| VC-IN-29 | N2 | `\oint_{\lvert z\rvert=2}\frac{e^{z}}{z^{2}-1}\,dz` | `2\pi i\sinh1` |

### B9.R Residuos

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-IN-30 | N1 | `\operatorname{Res}\left(\frac{1}{z^{2}+1},\,i\right)` | `-\frac{i}{2}` |
| VC-IN-31 | N2 | `\operatorname{Res}\left(\frac{e^{z}}{z^{3}},\,0\right)` | `\frac{1}{2}` |
| VC-IN-32 | N2 | `\operatorname{Res}\left(\frac{z}{(z-1)^{2}},\,1\right)` | `1` |
| VC-IN-33 | N2 | `\operatorname{Res}\left(\tan z,\,\frac{\pi}{2}\right)` | `-1` |
| VC-IN-34 | N2 | `\operatorname{Res}\left(\frac{1}{\sin z},\,k\pi\right)` | `(-1)^{k}` |
| VC-IN-35 | N2 | `\operatorname{Res}\left(\frac{1}{z(z-1)(z-2)},\,0\right)` | `\frac{1}{2}` |
| VC-IN-36 | N2 | `\operatorname{Res}\left(\frac{e^{z}}{z^{2}-1},\,1\right)` | `\frac{e}{2}` |
| VC-IN-37 | N3 | `\operatorname{Res}\left(\frac{1}{\left(z^{2}+1\right)^{2}},\,i\right)` | `-\frac{i}{4}` |
| VC-IN-38 | N3 | `\operatorname{Res}\left(\frac{\sin z}{z^{4}},\,0\right)` | `-\frac{1}{6}` |
| VC-IN-39 | N3 | `\operatorname{Res}\left(z\cos\frac{1}{z},\,0\right)` | `-\frac{1}{2}` |
| VC-IN-40 | N3 | `\operatorname{Res}\left(\frac{1}{z^{4}+1},\,e^{i\pi/4}\right)` | `-\frac{\sqrt{2}}{8}(1+i)` |
| VC-IN-41 | N3 | `\operatorname{Res}\left(\frac{z^{2}}{z^{4}+1},\,e^{i\pi/4}\right)` | `\frac{\sqrt{2}}{8}(1-i)` |
| VC-IN-42 | N2 | `\operatorname{Res}\left(\frac{1}{z^{n}-1},\,1\right)` | `\frac{1}{n}` |
| VC-IN-43 | N3 | `\operatorname{Res}\left(\frac{1}{z^{2}+1},\,\infty\right)` | `0` |
| VC-IN-44 | N2 | `\operatorname{Res}\left(\frac{1}{z},\,\infty\right)` | `-1` |

---

## B10. Singularidades, series de Taylor y de Laurent

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-SL-01 | N1 | `\frac{\sin z}{z}` en `z=0` | singularidad evitable |
| VC-SL-02 | N1 | `\frac{1}{z^{2}}` en `z=0` | polo de orden `2` |
| VC-SL-03 | N2 | `\frac{1}{\sin z}` | polos simples en `z=k\pi` |
| VC-SL-04 | N2 | `e^{1/z}` en `z=0` | singularidad esencial |
| VC-SL-05 | N2 | `\sin\frac{1}{z}` en `z=0` | singularidad esencial |
| VC-SL-06 | N2 | `\frac{e^{z}-1-z}{z^{3}}` en `z=0` | polo simple |
| VC-SL-07 | N2 | `\frac{\cos z-1}{z^{2}}` en `z=0` | evitable (valor `-\frac{1}{2}`) |
| VC-SL-08 | N2 | `\frac{z}{e^{z}-1}` | evitable en `0`; polos simples en `z=2\pi ik,\ k\neq0` |
| VC-SL-09 | N2 | `\frac{1}{(z-1)^{3}(z+2)}` | polo de orden `3` en `1`; polo simple en `-2` |
| VC-SL-10 | N2 | `\tan z` | polos simples en `\frac{\pi}{2}+k\pi` |
| VC-SL-11 | N2 | `z^{2}`, `e^{z}`, `\frac{1}{z}` en `z=\infty` | polo de orden `2`; esencial; cero |
| VC-SL-12 | N2 | `\operatorname{Log}z` y `\sqrt{z}` en `z=0` | punto de ramificación |
| VC-SL-13 | N2 | Laurent de `\frac{1}{z(1-z)}` en `0<\lvert z\rvert<1` | `\frac{1}{z}+1+z+z^{2}+\cdots` |
| VC-SL-14 | N3 | Laurent de `\frac{1}{z(1-z)}` en `\lvert z\rvert>1` | `-\sum_{n=2}^{\infty}z^{-n}` |
| VC-SL-15 | N2 | Laurent de `e^{1/z}` | `\sum_{n=0}^{\infty}\frac{z^{-n}}{n!}` |
| VC-SL-16 | N2 | Laurent de `\frac{\sin z}{z^{3}}` | `z^{-2}-\frac{1}{6}+\frac{z^{2}}{120}-\cdots` |
| VC-SL-17 | N3 | Laurent de `\frac{1}{(z-1)(z-2)}` en `1<\lvert z\rvert<2` | `-\sum_{n=0}^{\infty}\frac{z^{n}}{2^{n+1}}-\sum_{n=1}^{\infty}z^{-n}` |
| VC-SL-18 | N3 | Laurent de `\cot z` en `0` | `\frac{1}{z}-\frac{z}{3}-\frac{z^{3}}{45}-\cdots` |
| VC-SL-19 | N1 | Taylor de `\operatorname{Log}(1+z)` | `z-\frac{z^{2}}{2}+\frac{z^{3}}{3}-\cdots`, radio `1` |
| VC-SL-20 | N2 | Taylor de `\frac{1}{1+z^{2}}` | `1-z^{2}+z^{4}-\cdots`, radio `1` |
| VC-SL-21 | N2 | Taylor de `\tan z` | `z+\frac{z^{3}}{3}+\frac{2z^{5}}{15}+\cdots`, radio `\frac{\pi}{2}` |
| VC-SL-22 | N3 | Taylor de `\frac{z}{e^{z}-1}` | `1-\frac{z}{2}+\frac{z^{2}}{12}-\frac{z^{4}}{720}+\cdots`, radio `2\pi` |
| VC-SL-23 | N3 | Taylor de `\sec z` | `1+\frac{z^{2}}{2}+\frac{5z^{4}}{24}+\cdots`, radio `\frac{\pi}{2}` |
| VC-SL-24 | N2 | Taylor de `e^{z}` en `z_{0}=i` | `e^{i}\sum_{n=0}^{\infty}\frac{(z-i)^{n}}{n!}` |
| VC-SL-25 | N3 | Taylor de `(1+z)^{i}` | `1+iz+\frac{-1-i}{2}z^{2}+\cdots` |
| VC-SL-26 | N2 | Taylor de `\frac{1}{z}` en `z_{0}=1` | `\sum_{n=0}^{\infty}(-1)^{n}(z-1)^{n}`, radio `1` |

---

## B11. Integrales reales y sumas por residuos

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-IR-01 | N2 | `\int_{-\infty}^{\infty}\frac{dx}{x^{2}+1}` | `\pi` |
| VC-IR-02 | N2 | `\int_{-\infty}^{\infty}\frac{dx}{x^{4}+1}` | `\frac{\pi}{\sqrt{2}}` |
| VC-IR-03 | N2 | `\int_{-\infty}^{\infty}\frac{dx}{\left(x^{2}+1\right)^{2}}` | `\frac{\pi}{2}` |
| VC-IR-04 | N2 | `\int_{-\infty}^{\infty}\frac{x^{2}}{x^{4}+1}\,dx` | `\frac{\pi}{\sqrt{2}}` |
| VC-IR-05 | N2 | `\int_{-\infty}^{\infty}\frac{dx}{x^{2}+4x+5}` | `\pi` |
| VC-IR-06 | N3 | `\int_{-\infty}^{\infty}\frac{dx}{\left(x^{2}+1\right)\left(x^{2}+4\right)}` | `\frac{\pi}{6}` |
| VC-IR-07 | N2 | `\int_{0}^{\infty}\frac{dx}{x^{6}+1}` | `\frac{\pi}{3}` |
| VC-IR-08 | N2 | `\int_{0}^{\infty}\frac{dx}{x^{4}+1}` | `\frac{\pi\sqrt{2}}{4}` |
| VC-IR-09 | N3 | `\int_{0}^{\infty}\frac{x^{a-1}}{1+x}\,dx,\ 0<a<1` | `\frac{\pi}{\sin\pi a}` |
| VC-IR-10 | N3 | `\int_{0}^{\infty}\frac{\sqrt{x}}{x^{2}+1}\,dx` | `\frac{\pi}{\sqrt{2}}` |
| VC-IR-11 | N2 | `\int_{-\infty}^{\infty}\frac{\cos x}{x^{2}+1}\,dx` | `\frac{\pi}{e}` |
| VC-IR-12 | N2 | `\int_{-\infty}^{\infty}\frac{\sin x}{x^{2}+1}\,dx` | `0` |
| VC-IR-13 | N3 | `\int_{-\infty}^{\infty}\frac{x\sin x}{x^{2}+1}\,dx` | `\frac{\pi}{e}` |
| VC-IR-14 | N3 | `\int_{-\infty}^{\infty}\frac{\cos ax}{x^{2}+b^{2}}\,dx,\ a,b>0` | `\frac{\pi}{b}e^{-ab}` |
| VC-IR-15 | N3 | `\int_{-\infty}^{\infty}\frac{\cos x}{x^{4}+1}\,dx` | `\frac{\pi}{\sqrt{2}}e^{-1/\sqrt{2}}\left(\cos\frac{1}{\sqrt{2}}+\sin\frac{1}{\sqrt{2}}\right)\approx1.5443` |
| VC-IR-16 | N2 | `\int_{0}^{2\pi}\frac{d\theta}{2+\cos\theta}` | `\frac{2\pi}{\sqrt{3}}\approx3.627598728` |
| VC-IR-17 | N2 | `\int_{0}^{2\pi}\frac{d\theta}{5+4\cos\theta}` | `\frac{2\pi}{3}` |
| VC-IR-18 | N3 | `\int_{0}^{2\pi}\frac{d\theta}{1-2a\cos\theta+a^{2}},\ \lvert a\rvert<1` | `\frac{2\pi}{1-a^{2}}` |
| VC-IR-19 | N2 | `\int_{0}^{2\pi}\cos^{4}\theta\,d\theta` | `\frac{3\pi}{4}` |
| VC-IR-20 | N3 | `\int_{0}^{2\pi}\frac{\cos2\theta}{5-4\cos\theta}\,d\theta` | `\frac{\pi}{6}` |
| VC-IR-21 | N3 | `\int_{0}^{\infty}\frac{\sin x}{x}\,dx` | `\frac{\pi}{2}` |
| VC-IR-22 | N3 | `\int_{0}^{\infty}\sin\left(x^{2}\right)dx` | `\frac{1}{2}\sqrt{\frac{\pi}{2}}\approx0.626657069` |
| VC-IR-23 | N3 | `\int_{-\infty}^{\infty}e^{-x^{2}}\cos(2bx)\,dx` | `\sqrt{\pi}\,e^{-b^{2}}` |
| VC-IR-24 | N3 | `\sum_{n=1}^{\infty}\frac{1}{n^{2}+1}` | `\frac{\pi\coth\pi-1}{2}\approx1.076674047` |

---

## B12. Transformaciones conformes

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-TC-01 | N2 | `w=\frac{z-i}{z+i}`: valores en `z=0,\ 1,\ i,\ \infty` | `w=-1,\ -i,\ 0,\ 1` |
| VC-TC-02 | N3 | `w=\frac{z-i}{z+i}`: imagen del semiplano superior | disco unitario abierto `\lvert w\rvert<1` |
| VC-TC-03 | N3 | Möbius que lleva `0,1,\infty` a `-1,-i,1` | `w=\frac{z-i}{z+i}` |
| VC-TC-04 | N2 | `w=\frac{1}{z}`: imagen de `\lvert z\rvert=2` | `\lvert w\rvert=\frac{1}{2}` |
| VC-TC-05 | N3 | `w=\frac{1}{z}`: imagen de `\operatorname{Re}z=1` | circunferencia `\left\lvert w-\frac{1}{2}\right\rvert=\frac{1}{2}` |
| VC-TC-06 | N3 | `w=\frac{1}{z}`: imagen de `\operatorname{Im}z=1` | circunferencia `\left\lvert w+\frac{i}{2}\right\rvert=\frac{1}{2}` |
| VC-TC-07 | N2 | `w=z^{2}`: imagen de `\operatorname{Re}z=1` | parábola `v^{2}=4(1-u)` |
| VC-TC-08 | N2 | `w=z^{2}`: imagen de `\operatorname{Im}z=1` | parábola `v^{2}=4(u+1)` |
| VC-TC-09 | N2 | `w=z^{2}`: imagen del sector `0<\arg z<\frac{\pi}{4}` | primer cuadrante `0<\arg w<\frac{\pi}{2}` |
| VC-TC-10 | N2 | `w=e^{z}`: imagen de la franja `0<\operatorname{Im}z<\pi` | semiplano superior |
| VC-TC-11 | N2 | `w=e^{z}`: imagen de `\operatorname{Re}z=a` y de `\operatorname{Im}z=b` | circunferencia `\lvert w\rvert=e^{a}` y semirrecta `\arg w=b` |
| VC-TC-12 | N2 | `w=\operatorname{Log}z`: imagen de `\mathbb{C}\setminus(-\infty,0]` | franja `\lvert\operatorname{Im}w\rvert<\pi` |
| VC-TC-13 | N3 | Joukowski `w=\frac{1}{2}\left(z+\frac{1}{z}\right)`: imagen de `\lvert z\rvert=1` | segmento `[-1,1]` |
| VC-TC-14 | N3 | Joukowski: imagen de `\lvert z\rvert=r>1` | elipse de semiejes `\frac{r+1/r}{2}` y `\frac{r-1/r}{2}` |
| VC-TC-15 | N2 | Puntos fijos de `w=\frac{z+1}{z-1}` | `z=1\pm\sqrt{2}` |
| VC-TC-16 | N2 | Razón doble `(z_{1},z_{2};z_{3},z_{4})=\frac{(z_{1}-z_{3})(z_{2}-z_{4})}{(z_{1}-z_{4})(z_{2}-z_{3})}` para `1,2,3,4` | `\frac{4}{3}` |
| VC-TC-17 | N2 | `w=z^{2}` en `z_{0}=1+i`: factor de escala y ángulo de giro | `\lvert f'\rvert=2\sqrt{2}`, giro `\frac{\pi}{4}` |
| VC-TC-18 | N3 | `w=\sin z`: imagen de `\lvert\operatorname{Re}z\rvert<\frac{\pi}{2}` | `\mathbb{C}\setminus\left((-\infty,-1]\cup[1,\infty)\right)` |

---

## B13. Teoremas globales

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-TE-01 | N2 | Principio del argumento: `\frac{1}{2\pi i}\oint_{\lvert z\rvert=2}\frac{f'}{f}\,dz`, `f=z^{3}-1` | `3` |
| VC-TE-02 | N3 | Ídem con `f=\frac{z^{2}+1}{z-1}` en `\lvert z\rvert=2` | `1` (2 ceros menos 1 polo) |
| VC-TE-03 | N3 | Rouché: ceros de `z^{5}+3z+1` en `\lvert z\rvert<1` | `1` |
| VC-TE-04 | N3 | Rouché: ceros de `z^{5}+3z+1` en `\lvert z\rvert<2` | `5` |
| VC-TE-05 | N3 | Rouché: ceros de `z^{4}-5z+1` en `1<\lvert z\rvert<2` | `3` |
| VC-TE-06 | N2 | `\max_{\lvert z\rvert\le1}\left\lvert z^{2}+1\right\rvert` | `2` (en `z=\pm1`) |
| VC-TE-07 | N2 | `\max_{\lvert z\rvert\le1}\lvert z-2\rvert` | `3` (en `z=-1`) |
| VC-TE-08 | N2 | `\min_{\lvert z\rvert\le1}\lvert z-2\rvert` | `1` (en `z=1`) |
| VC-TE-09 | N2 | `\max_{\lvert z\rvert\le1}\left\lvert e^{z}\right\rvert` | `e` (en `z=1`) |

---

## B14. Combinaciones: ecuaciones diferenciales, Laplace y Fourier con números complejos

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-CB-01 | N1 | `y'=iy,\ y(0)=1` | `y=e^{ix}=\cos x+i\sin x` |
| VC-CB-02 | N2 | `y'=(1+i)y` | `y=Ce^{(1+i)x}=Ce^{x}(\cos x+i\sin x)` |
| VC-CB-03 | N2 | `y''+2iy'+3y=0` | `y=c_{1}e^{ix}+c_{2}e^{-3ix}` |
| VC-CB-04 | N2 | `y''-2iy'-y=0` | `y=\left(c_{1}+c_{2}x\right)e^{ix}` |
| VC-CB-05 | N2 | `y'+iy=e^{ix}` | `y=-\frac{i}{2}e^{ix}+Ce^{-ix}` |
| VC-CB-06 | N3 | `y''+y=e^{ix}`; luego resolver `y''+y=\cos x` tomando la parte real | `y_{p}=-\frac{i}{2}xe^{ix}`; para el coseno, `y_{p}=\frac{x}{2}\sin x` |
| VC-CB-07 | N3 | `y''+2y'+5y=e^{(-1+2i)x}`; luego la parte real | `y_{p}=-\frac{i}{4}xe^{(-1+2i)x}`; parte real `\frac{x}{4}e^{-x}\sin2x` |
| VC-CB-08 | N2 | `x^{2}y''+xy'+y=0,\ x>0` con exponentes complejos | `y=c_{1}x^{i}+c_{2}x^{-i}` (equivale a `\cos(\ln x),\ \sin(\ln x)`) |
| VC-CB-09 | N2 | `\mathcal{L}\left\{e^{it}\right\}` | `\frac{1}{s-i}` |
| VC-CB-10 | N2 | `\mathcal{L}\left\{e^{(a+ib)t}\right\}` | `\frac{1}{s-a-ib}` |
| VC-CB-11 | N2 | `\mathcal{L}\{\cos bt\}` como `\operatorname{Re}\frac{1}{s-ib}` | `\frac{s}{s^{2}+b^{2}}` |
| VC-CB-12 | N2 | `\mathcal{L}^{-1}\left\{\frac{1}{s^{2}+1}\right\}` por residuos | `\sin t` |
| VC-CB-13 | N3 | `\int_{-\infty}^{\infty}e^{-x^{2}}e^{-i\omega x}\,dx` | `\sqrt{\pi}\,e^{-\omega^{2}/4}` |
| VC-CB-14 | N3 | `\int_{-\infty}^{\infty}\frac{e^{-i\omega x}}{x^{2}+1}\,dx` | `\pi e^{-\lvert\omega\rvert}` |
| VC-CB-15 | N3 | Onda plana `\psi=e^{i(kx-\omega t)}` en `i\psi_{t}=-\frac{1}{2}\psi_{xx}` | se cumple si `\omega=\frac{k^{2}}{2}` |

---

## B15. Casos límite, ramas y robustez numérica en $\mathbb{C}$

| ID | Nivel | Ejercicio | Resultado esperado |
|---|---|---|---|
| VC-CL-01 | N2 | `\arg(0)` | indefinido (error claro) |
| VC-CL-02 | N2 | `\operatorname{Arg}(-8)` | `\pi` (no `-\pi`) |
| VC-CL-03 | N2 | `0^{0}` | indeterminada |
| VC-CL-04 | N2 | `0^{i}` | indefinido |
| VC-CL-05 | N2 | `\frac{1}{0}` | indefinido (o `\infty` en la esfera de Riemann, si se declara) |
| VC-CL-06 | N2 | `\sqrt[3]{-1}` | valor principal `\frac{1}{2}+\frac{\sqrt{3}}{2}i`; raíz real `-1`; debe declarar la convención |
| VC-CL-07 | N3 | `e^{1000i}` | `\approx0.562379076+0.826879541i` (reducción de argumento) |
| VC-CL-08 | N3 | `\sin(100i)` | `\approx1.344058571\times10^{43}\,i` |
| VC-CL-09 | N3 | `\left\lvert e^{i10^{20}}\right\rvert` | `1` |
| VC-CL-10 | N3 | `\left(1+10^{-10}i\right)^{10^{10}}` | `\approx e^{i}\approx0.540302+0.841471i` |
| VC-CL-11 | N3 | `\operatorname{Log}\left(-10^{-300}\right)` | `-300\ln10+i\pi\approx-690.775528+3.141593i` |
| VC-CL-12 | N3 | `\cos\left(1+10^{-20}i\right)` | `\approx0.540302306-8.41470985\times10^{-21}\,i` (no perder la parte imaginaria) |

---

## Resumen de cobertura por forma de representación (Parte B, secciones B1 y B2)

| Forma de entrada | Conversión (B1) | Operaciones (B2) |
|---|:-:|:-:|
| Binómica | 17 | 11 |
| Polar | 10 | 9 |
| Trigonométrica | 10 | 9 |
| Exponencial | 12 | 12 |

Las secciones B3 a B15 mezclan las cuatro formas de forma deliberada (raíces en exponencial, ecuaciones en binómica, curvas en trigonométrica y exponencial, etc.).
