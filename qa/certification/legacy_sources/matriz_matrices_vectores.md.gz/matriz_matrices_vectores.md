# Matriz de estrés — Matrices y vectores

Cubre álgebra lineal (operaciones, determinantes, inversas, sistemas, rango y núcleo, valores propios, diagonalización) y vectores (producto punto y cruz, ángulos, proyecciones, planos y rectas). Los resultados esperados se **calcularon con SymPy** como oráculo.

**Total: 153 ejercicios** (N1: 35 · N2: 83 · N3: 35).

## Cómo usar esta matriz

1. Escribir la columna **Entrada** en Lite y en Plus.
2. Comparar con **Resultado esperado** según el tipo de comparación (tabla siguiente).
3. Registrar `✓`, `✗` o `–` (no soportado) por motor y clasificar toda diferencia entre Lite y Plus como **PARIDAD**, **DIFERENCIA INTENCIONAL** o **GAP**.
4. Cada fallo se convierte en un caso de regresión permanente.

**Formato ejecutable:** los mismos ejercicios están en `matrices_ejecutables.jsonl` (una línea JSON por ejercicio), listos para un ejecutor automático (Playwright en Lite, API en Plus).

## Tipos de comparación

| Valor de `comparacion` | Qué se verifica |
|---|---|
| `numerica_o_exacta` | Valor numérico (tolerancia relativa `10^{-9}`) o exacto cuando es racional o entero. |
| `equivalencia_simbolica` | Equivalencia: la diferencia con el esperado se simplifica a `0`, o coincide en puntos de prueba aleatorios. |
| `forma_factorizada` | Equivalencia **y** que la expresión esté efectivamente factorizada (producto de factores irreducibles). |
| `conjunto_solucion` | Mismo conjunto de soluciones (valores, intervalos o tuplas), sin importar el orden ni el nombre del parámetro. |
| `conjunto_salvo_escalares` | Mismos valores propios con multiplicidad; vectores propios iguales salvo múltiplos escalares. |
| `estructura` | La interpretación sintáctica es la indicada (por ejemplo, `3\cdot\sin(x)` y no `\sin(3x)`). |
| `convencion_declarada` | Cualquiera de las lecturas válidas se acepta **si la interfaz declara cuál usó**. Elegir una en silencio es fallo. |
| `aviso_de_error` | Mensaje claro y sin valor numérico falso. No debe bloquearse ni ejecutar código. |

## Campos del archivo JSONL

| Campo | Contenido |
|---|---|
| `id` | Identificador único (por ejemplo `SY-P-03`). |
| `matriz` | Código de la matriz: `SY`, `MV` o `AS`. |
| `seccion` | Código de la sección. |
| `nivel` | `N1` básico, `N2` intermedio, `N3` desafío. |
| `operacion` | Qué se pide (`valor`, `det`, `inversa`, `factorizar`, `resolver`, ...). |
| `comparacion` | Cómo comparar el resultado (ver tabla). |
| `entrada` | LaTeX que se escribe en la calculadora. |
| `esperado` | Resultado esperado en LaTeX. Si empieza por `T:` es una descripción en texto (error claro, caso con condiciones, etc.). |
| `nota` | Aclaración opcional. |

## Convenciones

- **Nivel:** `N1` básico · `N2` intermedio · `N3` desafío (rama delicada, precisión, rendimiento o función especial).
- "Error claro" significa un mensaje comprensible; devolver un número incorrecto en silencio es el peor resultado posible.
- Cuando una expresión admite dos lecturas matemáticas razonables, el ejercicio es de tipo `convencion`: la interfaz debe **mostrar** la que usa.
- Los valores aproximados se dan con 9 cifras significativas.

---

## MV-A. Operaciones básicas con matrices

Se usan `A=\begin{pmatrix}1&2\\3&4\end{pmatrix}`, `B=\begin{pmatrix}0&1\\1&0\end{pmatrix}`, `C` de 2×3 y `D` de 3×2. Todas las entradas ya llevan las matrices escritas explícitamente.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-A-01 | N1 | `suma` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}+\begin{pmatrix}0&1\\1&0\end{pmatrix}` | `\begin{pmatrix}1&3\\4&4\end{pmatrix}` |  |
| MV-A-02 | N1 | `suma` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}-\begin{pmatrix}0&1\\1&0\end{pmatrix}` | `\begin{pmatrix}1&1\\2&4\end{pmatrix}` |  |
| MV-A-03 | N1 | `producto` | `3\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}3&6\\9&12\end{pmatrix}` |  |
| MV-A-04 | N1 | `producto` | `\frac{1}{2}\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}\frac{1}{2}&1\\\frac{3}{2}&2\end{pmatrix}` |  |
| MV-A-05 | N1 | `producto` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}\cdot\begin{pmatrix}0&1\\1&0\end{pmatrix}` | `\begin{pmatrix}2&1\\4&3\end{pmatrix}` |  |
| MV-A-06 | N1 | `producto` | `\begin{pmatrix}0&1\\1&0\end{pmatrix}\cdot\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}3&4\\1&2\end{pmatrix}` | Distinto de `AB`: el producto no es conmutativo. |
| MV-A-07 | N1 | `potencia` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{2}` | `\begin{pmatrix}7&10\\15&22\end{pmatrix}` |  |
| MV-A-08 | N1 | `potencia` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{3}` | `\begin{pmatrix}37&54\\81&118\end{pmatrix}` |  |
| MV-A-09 | N1 | `matriz` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{T}` | `\begin{pmatrix}1&3\\2&4\end{pmatrix}` |  |
| MV-A-10 | N1 | `valor` | `\operatorname{tr}\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `5` |  |
| MV-A-11 | N2 | `potencia` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{0}` | `\begin{pmatrix}1&0\\0&1\end{pmatrix}` | La potencia cero es la identidad. |
| MV-A-12 | N2 | `potencia` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{-1}` | `\begin{pmatrix}-2&1\\\frac{3}{2}&- \frac{1}{2}\end{pmatrix}` |  |
| MV-A-13 | N2 | `potencia` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{-2}` | `\begin{pmatrix}\frac{11}{2}&- \frac{5}{2}\\- \frac{15}{4}&\frac{7}{4}\end{pmatrix}` |  |
| MV-A-14 | N2 | `producto` | `\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}\cdot\begin{pmatrix}1&0\\2&1\\3&2\end{pmatrix}` | `\begin{pmatrix}14&8\\32&17\end{pmatrix}` | Producto 2×3 por 3×2 da 2×2. |
| MV-A-15 | N2 | `producto` | `\begin{pmatrix}1&0\\2&1\\3&2\end{pmatrix}\cdot\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}` | `\begin{pmatrix}1&2&3\\6&9&12\\11&16&21\end{pmatrix}` | Producto 3×2 por 2×3 da 3×3. |
| MV-A-16 | N2 | `matriz` | `\left(\begin{pmatrix}2&1\\4&3\end{pmatrix}\right)^{T}` | `\begin{pmatrix}2&4\\1&3\end{pmatrix}` | Coincide con `B^{T}A^{T}`. |
| MV-A-17 | N1 | `suma` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}-\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}0&0\\0&0\end{pmatrix}` |  |
| MV-A-18 | N2 | `producto` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}\cdot\begin{pmatrix}-2&1\\\frac{3}{2}&- \frac{1}{2}\end{pmatrix}` | `\begin{pmatrix}1&0\\0&1\end{pmatrix}` |  |
| MV-A-19 | N2 | `matriz` | `\begin{pmatrix}1&3\\2&4\end{pmatrix}\cdot\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}10&14\\14&20\end{pmatrix}` | Resultado simétrico. |
| MV-A-20 | N2 | `error` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}+\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}` | error claro: dimensiones 2×2 y 2×3 incompatibles para la suma |  |
| MV-A-21 | N2 | `error` | `\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}\cdot\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}` | error claro: producto 2×3 por 2×3 no está definido |  |
| MV-A-22 | N2 | `error` | `\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}^{-1}` | error claro: la matriz no es cuadrada |  |
| MV-A-23 | N2 | `error` | `\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}^{2}` | error claro: la potencia exige matriz cuadrada |  |
| MV-A-24 | N3 | `matriz` | `\left(A+B\right)^{2}-\left(A^{2}+2AB+B^{2}\right),\ A,B\text{ como arriba}` | `\begin{pmatrix}1&3\\-3&-1\end{pmatrix}` | No es la matriz nula: `AB\neq BA`. Prueba de que no se aplica el binomio como en escalares. |
| MV-A-25 | N2 | `matriz` | `\begin{pmatrix}\frac{1}{2}&\frac{1}{3}\\\frac{1}{4}&\frac{1}{5}\end{pmatrix}+\begin{pmatrix}\frac{1}{2}&\frac{2}{3}\\\frac{3}{4}&\frac{4}{5}\end{pmatrix}` | `\begin{pmatrix}1&1\\1&1\end{pmatrix}` | Fracciones exactas. |

---

## MV-B. Determinantes

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-B-01 | N1 | `det` | `\det\begin{pmatrix}5\end{pmatrix}` | `5` |  |
| MV-B-02 | N1 | `det` | `\det\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `-2` |  |
| MV-B-03 | N1 | `det` | `\det\begin{pmatrix}2&0\\0&3\end{pmatrix}` | `6` | Diagonal. |
| MV-B-04 | N1 | `det` | `\det\begin{pmatrix}1&2&3\\0&4&5\\0&0&6\end{pmatrix}` | `24` | Triangular: producto de la diagonal. |
| MV-B-05 | N1 | `det` | `\det\begin{pmatrix}1&2&3\\4&5&6\\7&8&9\end{pmatrix}` | `0` | Singular. |
| MV-B-06 | N2 | `det` | `\det\begin{pmatrix}2&-1&0\\-1&2&-1\\0&-1&2\end{pmatrix}` | `4` |  |
| MV-B-07 | N2 | `det` | `\det\begin{pmatrix}2&1&3\\0&-1&4\\5&2&0\end{pmatrix}` | `19` |  |
| MV-B-08 | N2 | `det` | `\det\begin{pmatrix}1&0&2&-1\\3&0&0&5\\2&1&4&-3\\1&0&5&0\end{pmatrix}` | `30` | 4×4 con columna casi nula. |
| MV-B-09 | N3 | `det` | `\det\begin{pmatrix}1&\frac{1}{2}&\frac{1}{3}&\frac{1}{4}\\\frac{1}{2}&\frac{1}{3}&\frac{1}{4}&\frac{1}{5}\\\frac{1}{3}&\frac{1}{4}&\frac{1}{5}&\frac{1}{6}\\\frac{1}{4}&\frac{1}{5}&\frac{1}{6}&\frac{1}{7}\end{pmatrix}` | `\frac{1}{6048000}` | Matriz de Hilbert 4×4: requiere aritmética exacta. |
| MV-B-10 | N3 | `det` | `\det\begin{pmatrix}1&\frac{1}{2}&\frac{1}{3}&\frac{1}{4}&\frac{1}{5}\\\frac{1}{2}&\frac{1}{3}&\frac{1}{4}&\frac{1}{5}&\frac{1}{6}\\\frac{1}{3}&\frac{1}{4}&\frac{1}{5}&\frac{1}{6}&\frac{1}{7}\\\frac{1}{4}&\frac{1}{5}&\frac{1}{6}&\frac{1}{7}&\frac{1}{8}\\\frac{1}{5}&\frac{1}{6}&\frac{1}{7}&\frac{1}{8}&\frac{1}{9}\end{pmatrix}` | `\frac{1}{266716800000}` | Matriz de Hilbert 5×5. |
| MV-B-11 | N3 | `det` | `\det\begin{pmatrix}2&-1&0&0&0&0\\-1&2&-1&0&0&0\\0&-1&2&-1&0&0\\0&0&-1&2&-1&0\\0&0&0&-1&2&-1\\0&0&0&0&-1&2\end{pmatrix}` | `7` | Tridiagonal 6×6 (2 en la diagonal, -1 a los lados): `n+1`. |
| MV-B-12 | N2 | `det` | `\det\begin{pmatrix}1&2&3\\2&4&6\\1&0&1\end{pmatrix}` | `0` | Filas proporcionales: determinante nulo. |
| MV-B-13 | N2 | `det` | `\det\left(2\begin{pmatrix}1&2\\3&4\end{pmatrix}\right)` | `-8` | `\det(kA)=k^{n}\det A` con `n=2`. |
| MV-B-14 | N2 | `det` | `\det\left(\begin{pmatrix}1&2\\3&4\end{pmatrix}\begin{pmatrix}0&1\\1&0\end{pmatrix}\right)` | `2` | Igual a `\det A\cdot\det B`. |
| MV-B-15 | N2 | `det` | `\det\begin{pmatrix}0.1&0.2\\0.3&0.4\end{pmatrix}` | `-0.02` | No `-0.020000000000000004`. |
| MV-B-16 | N2 | `det` | `\det\begin{pmatrix}a&b\\c&d\end{pmatrix}` | `a d - b c` |  |
| MV-B-17 | N2 | `det` | `\det\begin{pmatrix}1&x\\x&1\end{pmatrix}` | `1 - x^{2}` |  |
| MV-B-18 | N3 | `det` | `\det\begin{pmatrix}1&a&a^{2}\\1&b&b^{2}\\1&c&c^{2}\end{pmatrix}` | `- \left(a - b\right) \left(a - c\right) \left(b - c\right)` | Determinante de Vandermonde, forma factorizada. |
| MV-B-19 | N3 | `det` | `\det\begin{pmatrix}a&1&1\\1&a&1\\1&1&a\end{pmatrix}` | `\left(a - 1\right)^{2} \left(a + 2\right)` | Forma factorizada: se anula en `a=1` y `a=-2`. |
| MV-B-20 | N3 | `det` | `\det\begin{pmatrix}\cos\theta&-\sin\theta\\\sin\theta&\cos\theta\end{pmatrix}` | `1` | Debe simplificar con `\sin^{2}+\cos^{2}=1`. |
| MV-B-21 | N2 | `det` | `\det\begin{pmatrix}i&1\\1&-i\end{pmatrix}` | `0` | Entradas complejas. |
| MV-B-22 | N2 | `error` | `\det\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}` | error claro: el determinante exige matriz cuadrada |  |

---

## MV-C. Inversa, adjunta y matrices singulares

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-C-01 | N1 | `inversa` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{-1}` | `\begin{pmatrix}-2&1\\\frac{3}{2}&- \frac{1}{2}\end{pmatrix}` |  |
| MV-C-02 | N1 | `inversa` | `\begin{pmatrix}2&0\\0&4\end{pmatrix}^{-1}` | `\begin{pmatrix}\frac{1}{2}&0\\0&\frac{1}{4}\end{pmatrix}` | Diagonal. |
| MV-C-03 | N2 | `inversa` | `\begin{pmatrix}2&-1&0\\-1&2&-1\\0&-1&2\end{pmatrix}^{-1}` | `\begin{pmatrix}\frac{3}{4}&\frac{1}{2}&\frac{1}{4}\\\frac{1}{2}&1&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}&\frac{3}{4}\end{pmatrix}` |  |
| MV-C-04 | N2 | `inversa` | `\begin{pmatrix}1&2&3\\0&1&4\\5&6&0\end{pmatrix}^{-1}` | `\begin{pmatrix}-24&18&5\\20&-15&-4\\-5&4&1\end{pmatrix}` | La inversa tiene entradas enteras. |
| MV-C-05 | N2 | `inversa` | `\begin{pmatrix}\frac{1}{2}&\frac{1}{3}\\\frac{1}{4}&\frac{1}{5}\end{pmatrix}^{-1}` | `\begin{pmatrix}12&-20\\-15&30\end{pmatrix}` | Fracciones exactas. |
| MV-C-06 | N3 | `inversa` | `\begin{pmatrix}1&\frac{1}{2}&\frac{1}{3}\\\frac{1}{2}&\frac{1}{3}&\frac{1}{4}\\\frac{1}{3}&\frac{1}{4}&\frac{1}{5}\end{pmatrix}^{-1}` | `\begin{pmatrix}9&-36&30\\-36&192&-180\\30&-180&180\end{pmatrix}` | Inversa de Hilbert 3×3: entradas enteras. |
| MV-C-07 | N3 | `inversa` | `\begin{pmatrix}1&\frac{1}{2}&\frac{1}{3}&\frac{1}{4}\\\frac{1}{2}&\frac{1}{3}&\frac{1}{4}&\frac{1}{5}\\\frac{1}{3}&\frac{1}{4}&\frac{1}{5}&\frac{1}{6}\\\frac{1}{4}&\frac{1}{5}&\frac{1}{6}&\frac{1}{7}\end{pmatrix}^{-1}` | `\begin{pmatrix}16&-120&240&-140\\-120&1200&-2700&1680\\240&-2700&6480&-4200\\-140&1680&-4200&2800\end{pmatrix}` | Inversa de Hilbert 4×4: entradas enteras grandes. |
| MV-C-08 | N2 | `inversa` | `\begin{pmatrix}1&i\\i&1\end{pmatrix}^{-1}` | `\begin{pmatrix}\frac{1}{2}&- \frac{i}{2}\\- \frac{i}{2}&\frac{1}{2}\end{pmatrix}` | Entradas complejas. |
| MV-C-09 | N2 | `inversa` | `\begin{pmatrix}2.5&1\\1&0.5\end{pmatrix}^{-1}` | `\begin{pmatrix}2&-4\\-4&10\end{pmatrix}` | Entradas decimales. |
| MV-C-10 | N2 | `inversa` | `\begin{pmatrix}a&b\\c&d\end{pmatrix}^{-1}` | `\begin{pmatrix}\frac{d}{a d - b c}&- \frac{b}{a d - b c}\\- \frac{c}{a d - b c}&\frac{a}{a d - b c}\end{pmatrix}` | Válida cuando `ad-bc\neq0`. |
| MV-C-11 | N2 | `matriz` | `\begin{pmatrix}\cos\theta&-\sin\theta\\\sin\theta&\cos\theta\end{pmatrix}^{-1}` | `\begin{pmatrix}\cos\theta&\sin\theta\\-\sin\theta&\cos\theta\end{pmatrix}` | La inversa de una rotación es su transpuesta. |
| MV-C-12 | N2 | `error` | `\begin{pmatrix}1&2\\2&4\end{pmatrix}^{-1}` | error claro: matriz no invertible (determinante 0) |  |
| MV-C-13 | N2 | `error` | `\begin{pmatrix}1&2&3\\4&5&6\\7&8&9\end{pmatrix}^{-1}` | error claro: matriz no invertible (determinante 0) |  |
| MV-C-14 | N2 | `matriz` | `\operatorname{adj}\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}4&-2\\-3&1\end{pmatrix}` |  |
| MV-C-15 | N3 | `matriz` | `\operatorname{adj}\begin{pmatrix}1&2&3\\0&1&4\\5&6&0\end{pmatrix}` | `\begin{pmatrix}-24&18&5\\20&-15&-4\\-5&4&1\end{pmatrix}` |  |
| MV-C-16 | N3 | `matriz` | `\operatorname{cof}\begin{pmatrix}1&2&3\\0&1&4\\5&6&0\end{pmatrix}` | `\begin{pmatrix}-24&20&-5\\18&-15&4\\5&-4&1\end{pmatrix}` | Matriz de cofactores. |
| MV-C-17 | N2 | `matriz` | `\left(\begin{pmatrix}2&1\\4&3\end{pmatrix}\right)^{-1}` | `\begin{pmatrix}\frac{3}{2}&- \frac{1}{2}\\-2&1\end{pmatrix}` | Igual a `B^{-1}A^{-1}`. |
| MV-C-18 | N2 | `resolver` | `X\begin{pmatrix}1&2\\3&4\end{pmatrix}=\begin{pmatrix}5&6\\7&8\end{pmatrix}` | `\begin{pmatrix}-1&2\\-2&3\end{pmatrix}` | Ecuación matricial: `X=BA^{-1}` (no `A^{-1}B`). |
| MV-C-19 | N2 | `resolver` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}X=\begin{pmatrix}5&6\\7&8\end{pmatrix}` | `\begin{pmatrix}-3&-4\\4&5\end{pmatrix}` | Ecuación matricial: `X=A^{-1}B`. |

---

## MV-D. Sistemas lineales, forma escalonada y factorizaciones

Soluciones con parámetro libre: el parámetro puede llamarse distinto; se aceptan las representaciones equivalentes.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-D-01 | N1 | `resolver` | `\begin{cases}x + y = 3\\ x - y = 1\end{cases}` | `(x,y)=\left(2,\ 1\right)` |  |
| MV-D-02 | N1 | `resolver` | `\begin{cases}3 x + 2 y = 12\\ x - y = -1\end{cases}` | `(x,y)=\left(2,\ 3\right)` |  |
| MV-D-03 | N2 | `resolver` | `\begin{cases}x + y + z = 6\\ 2 x - y + z = 3\\ x + 2 y - z = 2\end{cases}` | `(x,y,z)=\left(1,\ 2,\ 3\right)` |  |
| MV-D-04 | N2 | `resolver` | `\begin{cases}x + 2 y + 3 z = 14\\ 2 x + y + z = 7\\ 3 x + 3 y + 4 z = 21\end{cases}` | `(x,y,z)=\left(\frac{t}{3},\ 7 - \frac{5 t}{3},\ t\right),\ t\in\mathbb{R}` | La tercera ecuación es la suma de las dos primeras: infinitas soluciones. |
| MV-D-05 | N1 | `resolver` | `\begin{cases}x + y = 1\\ x + y = 3\end{cases}` | sin solución (sistema incompatible) | Rectas paralelas. |
| MV-D-06 | N1 | `resolver` | `\begin{cases}2 x - y = 1\\ 4 x - 2 y = 2\end{cases}` | `(x,y)=\left(\frac{t}{2} + \frac{1}{2},\ t\right),\ t\in\mathbb{R}` | Rectas coincidentes. |
| MV-D-07 | N2 | `resolver` | `\begin{cases}x + y + z = 0\\ 2 x + 2 y + 2 z = 0\\ x - y = 0\end{cases}` | `(x,y,z)=\left(- \frac{t}{2},\ - \frac{t}{2},\ t\right),\ t\in\mathbb{R}` | Sistema homogéneo con solución no trivial. |
| MV-D-08 | N2 | `resolver` | `\begin{cases}w + x + y + z = 10\\ - w + x - y + z = -2\\ - w + x + y - z = -4\\ w + x - y - z = 0\end{cases}` | `(x,y,z,w)=\left(1,\ 2,\ 3,\ 4\right)` | 4×4. |
| MV-D-09 | N2 | `resolver` | `\begin{cases}x + y = 3\\ x - y = 1\\ 2 x + y = 5\end{cases}` | `(x,y)=\left(2,\ 1\right)` | Sobredeterminado y compatible. |
| MV-D-10 | N2 | `resolver` | `\begin{cases}x + y = 3\\ x - y = 1\\ x + 2 y = 5\end{cases}` | sin solución (sistema incompatible) | Sobredeterminado e incompatible. |
| MV-D-11 | N2 | `resolver` | `\begin{cases}x + y + z = 1\\ x - y + z = 0\end{cases}` | `(x,y,z)=\left(\frac{1}{2} - t,\ \frac{1}{2},\ t\right),\ t\in\mathbb{R}` | Subdeterminado: 2 ecuaciones y 3 incógnitas. |
| MV-D-12 | N2 | `resolver` | `\begin{cases}\frac{x}{2} + \frac{y}{4} = 1\\ x - y = \frac{1}{2}\end{cases}` | `(x,y)=\left(\frac{3}{2},\ 1\right)` | Coeficientes fraccionarios. |
| MV-D-13 | N3 | `resolver` | `\begin{cases}x+y=1\\ x+ay=a\end{cases}` | si `a\neq1`: `(x,y)=(0,1)` · si `a=1`: infinitas soluciones `x+y=1` | Sistema con parámetro: debe distinguir casos. |
| MV-D-14 | N2 | `matriz` | `\operatorname{rref}\begin{pmatrix}1&2&3&4\\2&4&7&8\\3&6&10&12\end{pmatrix}` | `\begin{pmatrix}1&2&0&4\\0&0&1&0\\0&0&0&0\end{pmatrix}` | Forma escalonada reducida. |
| MV-D-15 | N2 | `matriz` | `\operatorname{rref}\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}1&0\\0&1\end{pmatrix}` | Matriz invertible: la identidad. |
| MV-D-16 | N3 | `matriz` | `\text{LU de }\begin{pmatrix}2&1&1\\4&3&3\\8&7&9\end{pmatrix}` | `L=\begin{pmatrix}1&0&0\\2&1&0\\4&3&1\end{pmatrix},\ U=\begin{pmatrix}2&1&1\\0&1&1\\0&0&2\end{pmatrix}` | Sin pivoteo (no hacen falta intercambios de filas). |
| MV-D-17 | N3 | `vectores` | `\text{Gram–Schmidt de }(1,1,0),(1,0,1),(0,1,1)\ \text{(sin normalizar)}` | `\begin{pmatrix}1\\1\\0\end{pmatrix},\ \begin{pmatrix}\frac{1}{2}\\- \frac{1}{2}\\1\end{pmatrix},\ \begin{pmatrix}- \frac{2}{3}\\\frac{2}{3}\\\frac{2}{3}\end{pmatrix}` | Vectores mutuamente ortogonales. |

---

## MV-E. Rango, núcleo, imagen y traza

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-E-01 | N1 | `rango` | `\operatorname{rank}\begin{pmatrix}1&2\\2&4\end{pmatrix}` | `1` |  |
| MV-E-02 | N1 | `rango` | `\operatorname{rank}\begin{pmatrix}1&0&0\\0&1&0\\0&0&1\end{pmatrix}` | `3` |  |
| MV-E-03 | N1 | `rango` | `\operatorname{rank}\begin{pmatrix}0&0\\0&0\end{pmatrix}` | `0` |  |
| MV-E-04 | N1 | `rango` | `\operatorname{rank}\begin{pmatrix}1&2&3\\4&5&6\end{pmatrix}` | `2` |  |
| MV-E-05 | N2 | `rango` | `\operatorname{rank}\begin{pmatrix}1&2&3\\4&5&6\\7&8&9\end{pmatrix}` | `2` |  |
| MV-E-06 | N2 | `rango` | `\operatorname{rank}\begin{pmatrix}1&2&3&4\\2&4&7&8\\3&6&10&12\end{pmatrix}` | `2` |  |
| MV-E-07 | N2 | `rango` | `\operatorname{rank}\begin{pmatrix}1&0&1\\0&1&1\\1&1&2\end{pmatrix}` | `2` |  |
| MV-E-08 | N3 | `rango` | `\operatorname{rank}\begin{pmatrix}1&a\\a&1\end{pmatrix}` | `2` si `a\neq\pm1`; `1` si `a=\pm1` | Rango dependiente de un parámetro. |
| MV-E-09 | N2 | `vectores` | `\ker\begin{pmatrix}1&2&3\\4&5&6\\7&8&9\end{pmatrix}\ \text{(base)}` | `\begin{pmatrix}1\\-2\\1\end{pmatrix}` | Una base del núcleo; se aceptan múltiplos. |
| MV-E-10 | N2 | `vectores` | `\operatorname{Col}\begin{pmatrix}1&2&3\\4&5&6\\7&8&9\end{pmatrix}\ \text{(base)}` | `\begin{pmatrix}1\\4\\7\end{pmatrix},\ \begin{pmatrix}2\\5\\8\end{pmatrix}` | Columnas pivote. |
| MV-E-11 | N3 | `vectores` | `\ker\begin{pmatrix}1&2&3&4\\2&4&7&8\\3&6&10&12\end{pmatrix}\ \text{(base)}` | `\begin{pmatrix}-2\\1\\0\\0\end{pmatrix},\ \begin{pmatrix}-4\\0\\0\\1\end{pmatrix}` | Dimensión del núcleo = 4 − rango. |
| MV-E-12 | N3 | `rango` | `\operatorname{rank}\begin{pmatrix}1&2&3&4\\2&4&7&8\\3&6&10&12\end{pmatrix}+\dim\ker\begin{pmatrix}1&2&3&4\\2&4&7&8\\3&6&10&12\end{pmatrix}` | `4` | Teorema rango–nulidad (número de columnas). |

---

## MV-F. Valores y vectores propios, diagonalización

Los vectores propios se aceptan salvo múltiplos escalares. Para valores complejos se esperan en forma binómica.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-F-01 | N1 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}2&0\\0&3\end{pmatrix}` | `\lambda=2\ (m=1):\ \begin{pmatrix}1\\0\end{pmatrix};\ \lambda=3\ (m=1):\ \begin{pmatrix}0\\1\end{pmatrix}` | Diagonal. |
| MV-F-02 | N1 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}2&1\\1&2\end{pmatrix}` | `\lambda=1\ (m=1):\ \begin{pmatrix}-1\\1\end{pmatrix};\ \lambda=3\ (m=1):\ \begin{pmatrix}1\\1\end{pmatrix}` | Simétrica. |
| MV-F-03 | N2 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}4&1\\2&3\end{pmatrix}` | `\lambda=2\ (m=1):\ \begin{pmatrix}- \frac{1}{2}\\1\end{pmatrix};\ \lambda=5\ (m=1):\ \begin{pmatrix}1\\1\end{pmatrix}` |  |
| MV-F-04 | N2 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}5&4\\1&2\end{pmatrix}` | `\lambda=1\ (m=1):\ \begin{pmatrix}-1\\1\end{pmatrix};\ \lambda=6\ (m=1):\ \begin{pmatrix}4\\1\end{pmatrix}` |  |
| MV-F-05 | N2 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}0&1\\-1&0\end{pmatrix}` | `\lambda=- i\ (m=1):\ \begin{pmatrix}i\\1\end{pmatrix};\ \lambda=i\ (m=1):\ \begin{pmatrix}- i\\1\end{pmatrix}` | Valores propios complejos. |
| MV-F-06 | N2 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}0&1\\1&1\end{pmatrix}` | `\lambda=\frac{1}{2} - \frac{\sqrt{5}}{2}\ (m=1):\ \begin{pmatrix}- \frac{\sqrt{5}}{2} - \frac{1}{2}\\1\end{pmatrix};\ \lambda=\frac{1}{2} + \frac{\sqrt{5}}{2}\ (m=1):\ \begin{pmatrix}- \frac{1}{2} + \frac{\sqrt{5}}{2}\\1\end{pmatrix}` | Aparece la razón áurea. |
| MV-F-07 | N3 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}2&1\\0&2\end{pmatrix}` | `\lambda=2\ (m=2):\ \begin{pmatrix}1\\0\end{pmatrix}` | Defectuosa: multiplicidad 2 pero un solo vector propio. |
| MV-F-08 | N2 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}2&-1&0\\-1&2&-1\\0&-1&2\end{pmatrix}` | `\lambda=2\ (m=1):\ \begin{pmatrix}-1\\0\\1\end{pmatrix};\ \lambda=2 - \sqrt{2}\ (m=1):\ \begin{pmatrix}1\\\sqrt{2}\\1\end{pmatrix};\ \lambda=\sqrt{2} + 2\ (m=1):\ \begin{pmatrix}1\\- \sqrt{2}\\1\end{pmatrix}` | Simétrica 3×3 con raíces cuadradas. |
| MV-F-09 | N2 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}1&2&3\\0&4&5\\0&0&6\end{pmatrix}` | `\lambda=1\ (m=1):\ \begin{pmatrix}1\\0\\0\end{pmatrix};\ \lambda=4\ (m=1):\ \begin{pmatrix}\frac{2}{3}\\1\\0\end{pmatrix};\ \lambda=6\ (m=1):\ \begin{pmatrix}\frac{8}{5}\\\frac{5}{2}\\1\end{pmatrix}` | Triangular: valores propios en la diagonal. |
| MV-F-10 | N3 | `propios` | `\text{valores y vectores propios de }\begin{pmatrix}2&0&0\\0&2&0\\0&0&5\end{pmatrix}` | `\lambda=2\ (m=2):\ \begin{pmatrix}1\\0\\0\end{pmatrix},\ \begin{pmatrix}0\\1\\0\end{pmatrix};\ \lambda=5\ (m=1):\ \begin{pmatrix}0\\0\\1\end{pmatrix}` | Multiplicidad 2 con dos vectores propios. |
| MV-F-11 | N2 | `matriz` | `\det\left(\lambda I-\begin{pmatrix}1&2\\3&4\end{pmatrix}\right)` | `\lambda^{2} - 5 \lambda - 2` | Polinomio característico. |
| MV-F-12 | N3 | `matriz` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{2}-5\begin{pmatrix}1&2\\3&4\end{pmatrix}-2I` | `\begin{pmatrix}0&0\\0&0\end{pmatrix}` | Cayley–Hamilton: debe dar la matriz nula. |
| MV-F-13 | N3 | `matriz` | `\text{diagonalizar }\begin{pmatrix}4&1\\2&3\end{pmatrix}\ \text{como }PDP^{-1}` | `P=\begin{pmatrix}-1&1\\2&1\end{pmatrix},\ D=\begin{pmatrix}2&0\\0&5\end{pmatrix}` | `P` y `D` no son únicas (orden de los valores propios y escala de columnas). |
| MV-F-14 | N3 | `potencia` | `\begin{pmatrix}4&1\\2&3\end{pmatrix}^{10}` | `\begin{pmatrix}6510758&3254867\\6509734&3255891\end{pmatrix}` | Por diagonalización o potencia directa. |
| MV-F-15 | N3 | `potencia` | `\begin{pmatrix}1&1\\1&0\end{pmatrix}^{30}` | `\begin{pmatrix}1346269&832040\\832040&514229\end{pmatrix}` | Contiene los números de Fibonacci `F_{29}, F_{30}, F_{31}`. |
| MV-F-16 | N2 | `potencia` | `\begin{pmatrix}2&1\\0&2\end{pmatrix}^{5}` | `\begin{pmatrix}32&80\\0&32\end{pmatrix}` | Bloque de Jordan: `\begin{pmatrix}\lambda^{n}&n\lambda^{n-1}\\0&\lambda^{n}\end{pmatrix}`. |
| MV-F-17 | N2 | `potencia` | `\begin{pmatrix}0&1\\0&0\end{pmatrix}^{2}` | `\begin{pmatrix}0&0\\0&0\end{pmatrix}` | Matriz nilpotente. |

---

## MV-G. Vectores en el plano y en el espacio

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-G-01 | N1 | `vectores` | `\begin{pmatrix}1\\2\\3\end{pmatrix}+\begin{pmatrix}4\\5\\6\end{pmatrix}` | `\begin{pmatrix}5\\7\\9\end{pmatrix}` |  |
| MV-G-02 | N1 | `vectores` | `\begin{pmatrix}1\\2\\3\end{pmatrix}\cdot\begin{pmatrix}4\\5\\6\end{pmatrix}` | `32` |  |
| MV-G-03 | N2 | `vectores` | `\begin{pmatrix}1\\2\\3\end{pmatrix}\times\begin{pmatrix}4\\5\\6\end{pmatrix}` | `\begin{pmatrix}-3\\6\\-3\end{pmatrix}` | Producto cruz. |
| MV-G-04 | N2 | `vectores` | `\begin{pmatrix}4\\5\\6\end{pmatrix}\times\begin{pmatrix}1\\2\\3\end{pmatrix}` | `\begin{pmatrix}3\\-6\\3\end{pmatrix}` | Anticonmutativo: cambia de signo. |
| MV-G-05 | N1 | `vectores` | `\left\lVert\begin{pmatrix}1\\2\\3\end{pmatrix}\right\rVert` | `\sqrt{14}` |  |
| MV-G-06 | N2 | `vectores` | `\frac{\begin{pmatrix}1\\2\\3\end{pmatrix}}{\left\lVert\begin{pmatrix}1\\2\\3\end{pmatrix}\right\rVert}` | `\begin{pmatrix}\frac{\sqrt{14}}{14}\\\frac{\sqrt{14}}{7}\\\frac{3 \sqrt{14}}{14}\end{pmatrix}` | Vector unitario. |
| MV-G-07 | N2 | `vectores` | `\angle\left(\begin{pmatrix}1\\2\\3\end{pmatrix},\begin{pmatrix}4\\5\\6\end{pmatrix}\right)` | `\arccos{\left(\frac{16 \sqrt{22}}{77} \right)}\approx0.22572613\ \text{rad}\approx12.9332^{\circ}` |  |
| MV-G-08 | N2 | `vectores` | `\operatorname{proj}_{\begin{pmatrix}1\\2\\3\end{pmatrix}}\begin{pmatrix}4\\5\\6\end{pmatrix}` | `\begin{pmatrix}\frac{16}{7}\\\frac{32}{7}\\\frac{48}{7}\end{pmatrix}` | Proyección de `v` sobre `u`. |
| MV-G-09 | N2 | `vectores` | `\left\lVert\begin{pmatrix}1\\2\\3\end{pmatrix}\times\begin{pmatrix}4\\5\\6\end{pmatrix}\right\rVert` | `3 \sqrt{6}` | Área del paralelogramo. |
| MV-G-10 | N2 | `vectores` | `\left\lvert\begin{pmatrix}1\\2\\3\end{pmatrix}\cdot\left(\begin{pmatrix}4\\5\\6\end{pmatrix}\times\begin{pmatrix}7\\8\\10\end{pmatrix}\right)\right\rvert` | `3` | Volumen del paralelepípedo (producto triple). |
| MV-G-11 | N1 | `vectores` | `\begin{pmatrix}1\\2\\3\end{pmatrix}\cdot\begin{pmatrix}3\\0\\-1\end{pmatrix}` | `0` | Vectores ortogonales. |
| MV-G-12 | N2 | `vectores` | `\begin{pmatrix}1\\2\\3\end{pmatrix}\times\begin{pmatrix}2\\4\\6\end{pmatrix}` | `\begin{pmatrix}0\\0\\0\end{pmatrix}` | Vectores paralelos: cruz nulo. |
| MV-G-13 | N2 | `vectores` | `\begin{pmatrix}3\\4\end{pmatrix}\cdot\begin{pmatrix}-4\\3\end{pmatrix}` | `0` |  |
| MV-G-14 | N2 | `error` | `\begin{pmatrix}1\\2\end{pmatrix}\cdot\begin{pmatrix}1\\2\\3\end{pmatrix}` | error claro: vectores de distinta dimensión |  |
| MV-G-15 | N2 | `error` | `\begin{pmatrix}1\\2\end{pmatrix}\times\begin{pmatrix}3\\4\end{pmatrix}` | error claro o declaración: el producto cruz exige 3D (o se interpreta con `z=0` y se avisa) |  |
| MV-G-16 | N2 | `error` | `\frac{\begin{pmatrix}0\\0\\0\end{pmatrix}}{\left\lVert\begin{pmatrix}0\\0\\0\end{pmatrix}\right\rVert}` | error claro: no se puede normalizar el vector nulo |  |
| MV-G-17 | N3 | `vectores` | `P=(1,0,0),\ Q=(0,1,0),\ R=(0,0,1):\ \text{plano por los tres puntos}` | `x+y+z=1` |  |
| MV-G-18 | N3 | `valor` | `\text{distancia de }(1,2,3)\text{ al plano }2x-y+2z=5` | `\frac{1}{3}` | Fórmula `\frac{\lvert Ax_0+By_0+Cz_0-D\rvert}{\sqrt{A^{2}+B^{2}+C^{2}}}`. |
| MV-G-19 | N3 | `valor` | `\text{distancia de }(1,2,3)\text{ a la recta }(t,\,0,\,0)` | `\sqrt{13}` | La recta es el eje `x`. |
| MV-G-20 | N3 | `vectores` | `\text{recta }(t,2t,3t)\text{ y plano }x+y+z=12:\ \text{intersección}` | `(2,4,6)` |  |
| MV-G-21 | N3 | `vectores` | `\text{rectas }(1+t,\,2t,\,3)\ \text{y}\ (s,\,1+s,\,3):\ \text{intersección}` | `(3,\,4,\,3)` | Con `t=2` y `s=3`. |
| MV-G-22 | N2 | `matriz` | `\text{ángulo entre }(1,0)\text{ y }(1,1)` | `\frac{\pi}{4}` |  |

---

## MV-H. Formatos especiales, tamaños y rendimiento

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-H-01 | N1 | `producto` | `\begin{pmatrix}1&2&3\end{pmatrix}\begin{pmatrix}4\\5\\6\end{pmatrix}` | `\begin{pmatrix}32\end{pmatrix}` | Fila por columna da una matriz 1×1. |
| MV-H-02 | N2 | `producto` | `\begin{pmatrix}1\\2\\3\end{pmatrix}\begin{pmatrix}4&5&6\end{pmatrix}` | `\begin{pmatrix}4&5&6\\8&10&12\\12&15&18\end{pmatrix}` | Producto exterior 3×3. |
| MV-H-03 | N1 | `matriz` | `\begin{pmatrix}7\end{pmatrix}^{-1}` | `\begin{pmatrix}\frac{1}{7}\end{pmatrix}` | Matriz 1×1. |
| MV-H-04 | N2 | `matriz` | `\begin{pmatrix}0&0\\0&0\end{pmatrix}^{-1}` | error claro: matriz nula, no invertible |  |
| MV-H-05 | N2 | `matriz` | `\begin{pmatrix}\frac{1}{2}&\frac{1}{2}\\\frac{1}{2}&\frac{1}{2}\end{pmatrix}^{2}` | `\begin{pmatrix}\frac{1}{2}&\frac{1}{2}\\\frac{1}{2}&\frac{1}{2}\end{pmatrix}` | Matriz de proyección: `P^{2}=P`. |
| MV-H-06 | N2 | `matriz` | `\begin{pmatrix}1&i\\2&-3i\end{pmatrix}^{H}` | `\begin{pmatrix}1&2\\- i&3 i\end{pmatrix}` | Transpuesta conjugada. |
| MV-H-07 | N3 | `valor` | `\text{matriz }10\times10\text{ con }a_{ij}=i+j:\ \operatorname{rank}` | `2` | Rango 2 de una matriz grande y estructurada. |
| MV-H-08 | N3 | `det` | `\det\left(\text{tridiagonal }10\times10\text{ con }2,-1\right)` | `11` | Debe terminar en un tiempo razonable. |
| MV-H-09 | N3 | `det` | `\det\begin{pmatrix}a&b&c&d\\e&f&g&h\\i&j&k&l\\m&n&o&p\end{pmatrix}` | desarrollo simbólico de 24 términos | Prueba de rendimiento simbólico 4×4. |
| MV-H-10 | N3 | `inversa` | `\text{matriz }8\times8\text{ de Hilbert}^{-1}` | entradas enteras exactas, sin errores de redondeo | La matriz de Hilbert está muy mal condicionada: con decimales de 64 bits el resultado se degrada. |
| MV-H-11 | N3 | `error` | `\text{matriz }200\times200\text{ aleatoria}:\ \det` | resultado numérico o aviso de límite de tamaño; sin bloqueo |  |
| MV-H-12 | N3 | `error` | `\begin{pmatrix}1&2\\3&x\end{pmatrix}\cdot\begin{pmatrix}\text{abc}&1\\0&1\end{pmatrix}` | error claro: entrada no numérica ni simbólica válida |  |

---

## MV-J. Transformaciones lineales

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| MV-J-01 | N1 | `producto` | `\begin{pmatrix}0&-1\\1&0\end{pmatrix}\begin{pmatrix}1\\0\end{pmatrix}` | `\begin{pmatrix}0\\1\end{pmatrix}` | Rotación de `90^{\circ}` aplicada a `(1,0)`. |
| MV-J-02 | N2 | `det` | `\det\begin{pmatrix}0&-1\\1&0\end{pmatrix}` | `1` | Una rotación conserva el área. |
| MV-J-03 | N2 | `matriz` | `\begin{pmatrix}0&-1\\1&0\end{pmatrix}^{4}` | `\begin{pmatrix}1&0\\0&1\end{pmatrix}` | Cuatro cuartos de vuelta. |
| MV-J-04 | N2 | `producto` | `\begin{pmatrix}1&0\\0&-1\end{pmatrix}\begin{pmatrix}3\\2\end{pmatrix}` | `\begin{pmatrix}3\\-2\end{pmatrix}` | Reflexión respecto al eje `x`. |
| MV-J-05 | N2 | `producto` | `\begin{pmatrix}1&2\\0&1\end{pmatrix}\begin{pmatrix}1\\1\end{pmatrix}` | `\begin{pmatrix}3\\1\end{pmatrix}` | Cizalladura horizontal. |
| MV-J-06 | N3 | `matriz` | `\begin{pmatrix}\cos\theta&-\sin\theta\\\sin\theta&\cos\theta\end{pmatrix}\begin{pmatrix}\cos\varphi&-\sin\varphi\\\sin\varphi&\cos\varphi\end{pmatrix}` | `\begin{pmatrix}\cos(\theta+\varphi)&-\sin(\theta+\varphi)\\\sin(\theta+\varphi)&\cos(\theta+\varphi)\end{pmatrix}` | Composición de rotaciones: las entradas deben simplificarse a ángulos sumados. |
| MV-J-07 | N2 | `det` | `\det\left(\begin{pmatrix}2&0\\0&3\end{pmatrix}\right)` | `6` | La transformación multiplica las áreas por 6. |

---

## Resumen de cobertura

| Sección | Ejercicios |
|---|:-:|
| MV-A · Operaciones básicas con matrices | 25 |
| MV-B · Determinantes | 22 |
| MV-C · Inversa, adjunta y matrices singulares | 19 |
| MV-D · Sistemas lineales, forma escalonada y factorizaciones | 17 |
| MV-E · Rango, núcleo, imagen y traza | 12 |
| MV-F · Valores y vectores propios, diagonalización | 17 |
| MV-G · Vectores en el plano y en el espacio | 22 |
| MV-H · Formatos especiales, tamaños y rendimiento | 12 |
| MV-J · Transformaciones lineales | 7 |
| **Total** | **153** |
