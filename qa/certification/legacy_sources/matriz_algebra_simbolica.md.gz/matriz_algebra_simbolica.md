# Matriz de estrés — Álgebra simbólica

Cubre expansión, factorización, fracciones algebraicas, división de polinomios, fracciones parciales, radicales y exponentes, leyes de logaritmos, ecuaciones y desigualdades de una variable, sumatorias, funciones y trampas de dominio. Los resultados esperados se **calcularon con SymPy** como oráculo.

**Total: 229 ejercicios** (N1: 43 · N2: 132 · N3: 54).

## Cómo usar esta matriz

1. Escribir la columna **Entrada** en Lite y en Plus.
2. Comparar con **Resultado esperado** según el tipo de comparación (tabla siguiente).
3. Registrar `✓`, `✗` o `–` (no soportado) por motor y clasificar toda diferencia entre Lite y Plus como **PARIDAD**, **DIFERENCIA INTENCIONAL** o **GAP**.
4. Cada fallo se convierte en un caso de regresión permanente.

**Formato ejecutable:** los mismos ejercicios están en `matrices_ejecutables.jsonl` (una línea JSON por ejercicio), listos para un ejecutor automático (Playwright en Lite, API en Plus).

## Tipos de comparación

| Valor de `comparacion` | Qué se verifica |
|---|---|
| `numerica_o_exacta` | Valor numérico (tolerancia relativa `10^{-9}`) o exacto cuando es racional o entero. |
| `equivalencia_simbolica` | Equivalencia: la diferencia con el esperado se simplifica a `0`, o coincide en puntos de prueba aleatorios. |
| `forma_factorizada` | Equivalencia **y** que la expresión esté efectivamente factorizada (producto de factores irreducibles). |
| `conjunto_solucion` | Mismo conjunto de soluciones (valores, intervalos o tuplas), sin importar el orden ni el nombre del parámetro. |
| `conjunto_salvo_escalares` | Mismos valores propios con multiplicidad; vectores propios iguales salvo múltiplos escalares. |
| `estructura` | La interpretación sintáctica es la indicada (por ejemplo, `3\cdot\sin(x)` y no `\sin(3x)`). |
| `convencion_declarada` | Cualquiera de las lecturas válidas se acepta **si la interfaz declara cuál usó**. Elegir una en silencio es fallo. |
| `aviso_de_error` | Mensaje claro y sin valor numérico falso. No debe bloquearse ni ejecutar código. |

## Campos del archivo JSONL

| Campo | Contenido |
|---|---|
| `id` | Identificador único (por ejemplo `SY-P-03`). |
| `matriz` | Código de la matriz: `SY`, `MV` o `AS`. |
| `seccion` | Código de la sección. |
| `nivel` | `N1` básico, `N2` intermedio, `N3` desafío. |
| `operacion` | Qué se pide (`valor`, `det`, `inversa`, `factorizar`, `resolver`, ...). |
| `comparacion` | Cómo comparar el resultado (ver tabla). |
| `entrada` | LaTeX que se escribe en la calculadora. |
| `esperado` | Resultado esperado en LaTeX. Si empieza por `T:` es una descripción en texto (error claro, caso con condiciones, etc.). |
| `nota` | Aclaración opcional. |

## Convenciones

- **Nivel:** `N1` básico · `N2` intermedio · `N3` desafío (rama delicada, precisión, rendimiento o función especial).
- "Error claro" significa un mensaje comprensible; devolver un número incorrecto en silencio es el peor resultado posible.
- Cuando una expresión admite dos lecturas matemáticas razonables, el ejercicio es de tipo `convencion`: la interfaz debe **mostrar** la que usa.
- Los valores aproximados se dan con 9 cifras significativas.

---

## AS-A. Expansión y productos notables

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-A-01 | N1 | `expandir` | `(x+1)^{2}` | `x^{2} + 2 x + 1` |  |
| AS-A-02 | N1 | `expandir` | `(x-y)^{3}` | `x^{3} - 3 x^{2} y + 3 x y^{2} - y^{3}` |  |
| AS-A-03 | N1 | `expandir` | `(a+b)(a-b)` | `a^{2} - b^{2}` |  |
| AS-A-04 | N1 | `expandir` | `(x+2)\left(x^{2}-2x+4\right)` | `x^{3} + 8` |  |
| AS-A-05 | N1 | `expandir` | `(x-1)\left(x^{2}+x+1\right)` | `x^{3} - 1` |  |
| AS-A-06 | N2 | `expandir` | `(x+y+z)^{2}` | `x^{2} + 2 x y + 2 x z + y^{2} + 2 y z + z^{2}` |  |
| AS-A-07 | N2 | `expandir` | `(2x-3)^{4}` | `16 x^{4} - 96 x^{3} + 216 x^{2} - 216 x + 81` |  |
| AS-A-08 | N2 | `expandir` | `(x-1)^{5}` | `x^{5} - 5 x^{4} + 10 x^{3} - 10 x^{2} + 5 x - 1` |  |
| AS-A-09 | N2 | `expandir` | `(x+1)(x+2)(x+3)(x+4)` | `x^{4} + 10 x^{3} + 35 x^{2} + 50 x + 24` |  |
| AS-A-10 | N2 | `expandir` | `\left(x^{2}+x+1\right)^{3}` | `x^{6} + 3 x^{5} + 6 x^{4} + 7 x^{3} + 6 x^{2} + 3 x + 1` |  |
| AS-A-11 | N2 | `expandir` | `(a+b+c)^{3}` | `a^{3} + 3 a^{2} b + 3 a^{2} c + 3 a b^{2} + 6 a b c + 3 a c^{2} + b^{3} + 3 b^{2} c + 3 b c^{2} + c^{3}` |  |
| AS-A-12 | N2 | `expandir` | `\left(x^{2}-1\right)^{2}` | `x^{4} - 2 x^{2} + 1` |  |
| AS-A-13 | N2 | `expandir` | `(x+h)^{3}-x^{3}` | `h^{3} + 3 h^{2} x + 3 h x^{2}` |  |
| AS-A-14 | N2 | `expandir` | `\left(\sqrt{2}+\sqrt{3}\right)^{2}` | `2 \sqrt{6} + 5` | Resultado con radical: `5+2\sqrt{6}`. |
| AS-A-15 | N3 | `expandir` | `\left(x+\frac{1}{x}\right)^{3}` | `x^{3} + 3 x + \frac{3}{x} + \frac{1}{x^{3}}` | Exponentes negativos tras expandir. |
| AS-A-16 | N2 | `expandir` | `(1+i)^{4}` | `-4` | Con la unidad imaginaria. |
| AS-A-17 | N2 | `expandir` | `(2x-y)^{5}` | `32 x^{5} - 80 x^{4} y + 80 x^{3} y^{2} - 40 x^{2} y^{3} + 10 x y^{4} - y^{5}` | Cada coeficiente es un número combinatorio por una potencia de 2. |

---

## AS-B. Factorización

Sobre los racionales salvo que se indique otra cosa. La forma esperada es la **factorizada completa**; un polinomio irreducible debe quedar igual (sin inventar factores).

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-B-01 | N1 | `factorizar` | `x^{2}-5x+6` | `\left(x - 3\right) \left(x - 2\right)` |  |
| AS-B-02 | N1 | `factorizar` | `x^{2}-9` | `\left(x - 3\right) \left(x + 3\right)` |  |
| AS-B-03 | N1 | `factorizar` | `x^{3}-8` | `\left(x - 2\right) \left(x^{2} + 2 x + 4\right)` | Diferencia de cubos: factor cuadrático irreducible. |
| AS-B-04 | N1 | `factorizar` | `x^{3}+27` | `\left(x + 3\right) \left(x^{2} - 3 x + 9\right)` |  |
| AS-B-05 | N2 | `factorizar` | `x^{4}-1` | `\left(x - 1\right) \left(x + 1\right) \left(x^{2} + 1\right)` | Sobre ℚ: `(x-1)(x+1)(x^{2}+1)`. |
| AS-B-06 | N3 | `factorizar` | `x^{4}+4` | `\left(x^{2} - 2 x + 2\right) \left(x^{2} + 2 x + 2\right)` | Identidad de Sophie Germain. |
| AS-B-07 | N2 | `factorizar` | `x^{6}-1` | `\left(x - 1\right) \left(x + 1\right) \left(x^{2} - x + 1\right) \left(x^{2} + x + 1\right)` |  |
| AS-B-08 | N2 | `factorizar` | `x^{4}-5x^{2}+4` | `\left(x - 2\right) \left(x - 1\right) \left(x + 1\right) \left(x + 2\right)` |  |
| AS-B-09 | N2 | `factorizar` | `6x^{2}+5x-4` | `\left(2 x - 1\right) \left(3 x + 4\right)` |  |
| AS-B-10 | N2 | `factorizar` | `x^{3}+3x^{2}+3x+1` | `\left(x + 1\right)^{3}` |  |
| AS-B-11 | N2 | `factorizar` | `ax+ay+bx+by` | `\left(a + b\right) \left(x + y\right)` | Agrupación de términos. |
| AS-B-12 | N2 | `factorizar` | `x^{5}-x` | `x \left(x - 1\right) \left(x + 1\right) \left(x^{2} + 1\right)` |  |
| AS-B-13 | N3 | `factorizar` | `2x^{3}-x^{2}-13x-6` | `\left(x - 3\right) \left(x + 2\right) \left(2 x + 1\right)` |  |
| AS-B-14 | N3 | `factorizar` | `x^{4}+x^{2}+1` | `\left(x^{2} - x + 1\right) \left(x^{2} + x + 1\right)` | Se factoriza como diferencia de cuadrados en ℚ. |
| AS-B-15 | N2 | `factorizar` | `x^{3}-x^{2}-x+1` | `\left(x - 1\right)^{2} \left(x + 1\right)` |  |
| AS-B-16 | N2 | `factorizar` | `a^{3}-b^{3}` | `\left(a - b\right) \left(a^{2} + a b + b^{2}\right)` |  |
| AS-B-17 | N2 | `factorizar` | `a^{3}+b^{3}` | `\left(a + b\right) \left(a^{2} - a b + b^{2}\right)` |  |
| AS-B-18 | N2 | `factorizar` | `x^{8}-1` | `\left(x - 1\right) \left(x + 1\right) \left(x^{2} + 1\right) \left(x^{4} + 1\right)` |  |
| AS-B-19 | N2 | `factorizar` | `x^{2}y-xy^{2}` | `x y \left(x - y\right)` |  |
| AS-B-20 | N3 | `factorizar` | `x^{4}+x^{2}y^{2}+y^{4}` | `\left(x^{2} - x y + y^{2}\right) \left(x^{2} + x y + y^{2}\right)` |  |
| AS-B-21 | N3 | `factorizar` | `\left(x^{2}+1\right)^{2}-4x^{2}` | `\left(x - 1\right)^{2} \left(x + 1\right)^{2}` |  |
| AS-B-22 | N1 | `factorizar` | `x^{2}+1` | `x^{2} + 1` | Irreducible sobre ℚ y ℝ: debe quedar igual. |
| AS-B-23 | N2 | `factorizar` | `x^{2}-2` | `x^{2} - 2` | Irreducible sobre ℚ: debe quedar igual. |
| AS-B-24 | N3 | `factorizar` | `x^{2}-2\ \text{sobre }\mathbb{R}` | `\left(x - \sqrt{2}\right) \left(x + \sqrt{2}\right)` | Con raíces permitidas: `(x-\sqrt{2})(x+\sqrt{2})`. |
| AS-B-25 | N3 | `factorizar` | `x^{2}+1\ \text{sobre }\mathbb{C}` | `\left(x - i\right) \left(x + i\right)` | Sobre ℂ se descompone. |
| AS-B-26 | N2 | `factorizar` | `\text{factorizar el entero }360` | `2^{3}\cdot 3^{2}\cdot 5` |  |
| AS-B-27 | N2 | `factorizar` | `\text{factorizar el entero }1001` | `7\cdot 11\cdot 13` |  |
| AS-B-28 | N3 | `factorizar` | `\text{factorizar el entero }4294967297` | `641\cdot 6700417` |  |
| AS-B-29 | N2 | `factorizar` | `\text{factorizar el entero }123456789` | `3^{2}\cdot 3607\cdot 3803` |  |
| AS-B-30 | N3 | `valor` | `\text{¿es primo }1000000007?` | sí, es primo |  |

---

## AS-C. Expresiones racionales, división de polinomios, MCD y MCM

Las simplificaciones por cancelación válidas solo si se excluyen los ceros del denominador; un motor que cancela debe, al menos, no devolver un resultado falso al evaluar en esos puntos.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-C-01 | N1 | `simplificar` | `\frac{x^{2}-1}{x-1}` | `x + 1` | Válido para `x\neq1`. |
| AS-C-02 | N2 | `simplificar` | `\frac{x^{3}-1}{x^{2}-1}` | `\frac{x^{2} + x + 1}{x + 1}` |  |
| AS-C-03 | N2 | `simplificar` | `\frac{x^{2}+3x+2}{x^{2}-x-2}` | `\frac{x + 2}{x - 2}` |  |
| AS-C-04 | N2 | `simplificar` | `\frac{x^{2}-4}{x^{2}+4x+4}\cdot\frac{x+2}{x-2}` | `1` |  |
| AS-C-05 | N1 | `simplificar` | `\frac{1}{x}+\frac{1}{y}` | `\frac{x + y}{x y}` | Suma de fracciones con denominador común. |
| AS-C-06 | N2 | `simplificar` | `\frac{\frac{1}{x}-\frac{1}{y}}{x-y}` | `- \frac{1}{x y}` |  |
| AS-C-07 | N2 | `simplificar` | `\frac{1}{x-1}-\frac{1}{x+1}` | `\frac{2}{\left(x - 1\right) \left(x + 1\right)}` |  |
| AS-C-08 | N2 | `simplificar` | `\frac{x+1}{x^{2}-1}-\frac{1}{x-1}` | `0` |  |
| AS-C-09 | N2 | `simplificar` | `\frac{a}{b}+\frac{b}{a}` | `\frac{a^{2} + b^{2}}{a b}` |  |
| AS-C-10 | N2 | `simplificar` | `\frac{1-\frac{1}{x^{2}}}{1-\frac{1}{x}}` | `\frac{x + 1}{x}` |  |
| AS-C-11 | N3 | `simplificar` | `\frac{1}{1+\frac{1}{1+\frac{1}{x}}}` | `\frac{x + 1}{2 x + 1}` | Fracción continua de tres niveles. |
| AS-C-12 | N2 | `simplificar` | `\frac{x^{2}-y^{2}}{(x-y)^{2}}` | `\frac{x + y}{x - y}` |  |
| AS-C-13 | N2 | `division` | `\left(x^{3}+2x^{2}-x+3\right)\div(x-2)` | `q=x^{2} + 4 x + 7,\ r=17` | Cociente y resto; coincide con la regla de Ruffini. |
| AS-C-14 | N2 | `division` | `\left(x^{4}-1\right)\div\left(x^{2}+1\right)` | `q=x^{2} - 1,\ r=0` |  |
| AS-C-15 | N3 | `division` | `\left(2x^{3}+3x^{2}-5x+7\right)\div\left(x^{2}+1\right)` | `q=2 x + 3,\ r=4 - 7 x` |  |
| AS-C-16 | N2 | `division` | `\left(x^{5}-1\right)\div(x-1)` | `q=x^{4} + x^{3} + x^{2} + x + 1,\ r=0` |  |
| AS-C-17 | N2 | `valor` | `\gcd\left(x^{2}-1,\ x^{2}-2x+1\right)` | `x - 1` |  |
| AS-C-18 | N2 | `valor` | `\operatorname{lcm}\left(x^{2}-1,\ x^{2}-2x+1\right)` | `\left(x - 1\right)^{2} \left(x + 1\right)` |  |
| AS-C-19 | N2 | `valor` | `\gcd\left(12x^{2}y,\ 18xy^{2}\right)` | `6 x y` |  |
| AS-C-20 | N1 | `valor` | `\gcd(48,180)` | `12` |  |
| AS-C-21 | N1 | `valor` | `\operatorname{lcm}(48,180)` | `720` |  |
| AS-C-22 | N2 | `valor` | `\text{resto de }x^{100}-1\ \text{entre}\ x-1` | `0` | Teorema del resto: `p(1)=0`. |
| AS-C-23 | N2 | `valor` | `p(2)\ \text{con}\ p(x)=x^{3}-3x+1` | `3` | Evaluar un polinomio en un punto. |

---

## AS-D. Fracciones parciales

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-D-01 | N1 | `fracciones_parciales` | `\frac{1}{x^{2}-1}` | `- \frac{1}{2 \left(x + 1\right)} + \frac{1}{2 \left(x - 1\right)}` |  |
| AS-D-02 | N2 | `fracciones_parciales` | `\frac{3x+5}{(x+1)(x+2)}` | `\frac{1}{x + 2} + \frac{2}{x + 1}` |  |
| AS-D-03 | N2 | `fracciones_parciales` | `\frac{1}{x(x+1)^{2}}` | `- \frac{1}{x + 1} - \frac{1}{\left(x + 1\right)^{2}} + \frac{1}{x}` | Factor lineal repetido. |
| AS-D-04 | N2 | `fracciones_parciales` | `\frac{x^{2}+1}{x(x-1)^{2}}` | `\frac{2}{\left(x - 1\right)^{2}} + \frac{1}{x}` |  |
| AS-D-05 | N2 | `fracciones_parciales` | `\frac{x^{3}+1}{x^{2}-1}` | `x + \frac{1}{x - 1}` | Fracción impropia: parte polinómica más parciales. |
| AS-D-06 | N3 | `fracciones_parciales` | `\frac{1}{x^{3}+x}` | `- \frac{x}{x^{2} + 1} + \frac{1}{x}` | Factor cuadrático irreducible. |
| AS-D-07 | N3 | `fracciones_parciales` | `\frac{1}{x^{2}\left(x^{2}+1\right)}` | `- \frac{1}{x^{2} + 1} + \frac{1}{x^{2}}` |  |
| AS-D-08 | N3 | `fracciones_parciales` | `\frac{x^{2}+2x+3}{(x+1)\left(x^{2}+1\right)}` | `\frac{2}{x^{2} + 1} + \frac{1}{x + 1}` |  |
| AS-D-09 | N3 | `fracciones_parciales` | `\frac{2x+3}{x^{2}+2x+5}` | `\frac{2 x + 3}{x^{2} + 2 x + 5}` | Ya es irreducible: debe quedar igual. |

---

## AS-E. Radicales y exponentes

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-E-01 | N1 | `simplificar` | `\sqrt{12}` | `2 \sqrt{3}` |  |
| AS-E-02 | N1 | `simplificar` | `\sqrt{50}` | `5 \sqrt{2}` |  |
| AS-E-03 | N1 | `simplificar` | `\sqrt{8}+\sqrt{18}` | `5 \sqrt{2}` |  |
| AS-E-04 | N1 | `simplificar` | `\sqrt{72}` | `6 \sqrt{2}` |  |
| AS-E-05 | N2 | `simplificar` | `\sqrt[3]{54}` | `3 \sqrt[3]{2}` |  |
| AS-E-06 | N2 | `simplificar` | `\frac{\sqrt{18}}{\sqrt{2}}` | `3` |  |
| AS-E-07 | N2 | `simplificar` | `5^{1/2}\cdot5^{1/3}` | `5^{\frac{5}{6}}` |  |
| AS-E-08 | N2 | `simplificar` | `8^{-2/3}` | `\frac{1}{4}` |  |
| AS-E-09 | N2 | `simplificar` | `16^{3/4}` | `8` |  |
| AS-E-10 | N2 | `simplificar` | `\left(\sqrt{2}+\sqrt{3}\right)\left(\sqrt{2}-\sqrt{3}\right)` | `-1` |  |
| AS-E-11 | N3 | `simplificar` | `\sqrt{3+2\sqrt{2}}` | `1 + \sqrt{2}` | Radical anidado que se simplifica. |
| AS-E-12 | N3 | `simplificar` | `\sqrt{7+4\sqrt{3}}` | `\sqrt{3} + 2` | Radical anidado que se simplifica. |
| AS-E-13 | N3 | `simplificar` | `\sqrt{5+2\sqrt{6}}` | `\sqrt{2} + \sqrt{3}` | Radical anidado que se simplifica. |
| AS-E-14 | N2 | `simplificar` | `\frac{1}{1+\sqrt{2}}` | `-1 + \sqrt{2}` | Racionalizar el denominador. |
| AS-E-15 | N2 | `simplificar` | `\frac{1}{\sqrt{3}-\sqrt{2}}` | `\sqrt{2} + \sqrt{3}` | Racionalizar el denominador. |
| AS-E-16 | N2 | `simplificar` | `\frac{3}{\sqrt[3]{2}}` | `\frac{3 \cdot 2^{\frac{2}{3}}}{2}` | Racionalizar el denominador. |
| AS-E-17 | N3 | `simplificar` | `\frac{1}{1+\sqrt{2}+\sqrt{3}}` | `\frac{- \sqrt{6} + \sqrt{2} + 2}{4}` | Racionalizar el denominador. |
| AS-E-18 | N2 | `simplificar` | `\sqrt{x^{4}}` | `x^{2}` | Para `x` real. |
| AS-E-19 | N3 | `simplificar` | `\sqrt{x^{6}}` | `\lvert x\rvert^{3}` | No `x^{3}`: para `x<0` esa respuesta sería incorrecta. |
| AS-E-20 | N2 | `simplificar` | `\sqrt{x^{2}}` | `\lvert x\rvert` | No `x`. |
| AS-E-21 | N3 | `simplificar` | `\left(x^{2/3}\right)^{3/2}` | `\lvert x\rvert` | Con `x` real: `x^{2/3}\ge0`. |
| AS-E-22 | N2 | `simplificar` | `\left(\sqrt{x}\,y^{2}\right)^{4}` | `x^{2}y^{8}` |  |
| AS-E-23 | N2 | `simplificar` | `\sqrt[3]{\sqrt{x}},\ x\ge0` | `x^{1/6}` |  |
| AS-E-24 | N3 | `simplificar` | `\sqrt{(x-1)^{2}}` | `\lvert x-1\rvert` |  |
| AS-E-25 | N3 | `convencion` | `\sqrt{x}\sqrt{y}\ \text{frente a}\ \sqrt{xy}` | iguales solo si `x,y\ge0`; con ambos negativos difieren (`\sqrt{-1}\sqrt{-1}=-1`, `\sqrt{1}=1`) |  |
| AS-E-26 | N3 | `convencion` | `\left(-8\right)^{2/6}\ \text{frente a}\ \sqrt[3]{-8}^{\,2}` | `(-8)^{1/3}` es ambiguo (real o principal); `(-8)^{2/6}` se reduce o se rechaza: declarar |  |

---

## AS-F. Logaritmos y exponenciales (leyes)

Las expansiones de logaritmos exigen argumentos positivos; el motor debe indicarlo o resolver con `\lvert\cdot\rvert` cuando corresponda.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-F-01 | N1 | `expandir` | `\log_{2}(8x),\ x>0` | `3+\log_{2}x` |  |
| AS-F-02 | N1 | `expandir` | `\ln\left(x^{3}\right),\ x>0` | `3\ln x` |  |
| AS-F-03 | N2 | `expandir` | `\ln\left(x^{2}\right)` | `2\ln\lvert x\rvert` | Para `x` real no nulo; con `x>0` queda `2\ln x`. |
| AS-F-04 | N1 | `expandir` | `\ln(xy),\ x,y>0` | `\ln x+\ln y` |  |
| AS-F-05 | N1 | `expandir` | `\ln\frac{x}{y},\ x,y>0` | `\ln x-\ln y` |  |
| AS-F-06 | N2 | `expandir` | `\ln\frac{x^{2}\sqrt{y}}{z^{3}},\ x,y,z>0` | `2\ln x+\frac{1}{2}\ln y-3\ln z` |  |
| AS-F-07 | N2 | `simplificar` | `3\ln x-\ln y+\frac{1}{2}\ln z,\ x,y,z>0` | `\ln\frac{x^{3}\sqrt{z}}{y}` |  |
| AS-F-08 | N1 | `simplificar` | `e^{\ln x},\ x>0` | `x` |  |
| AS-F-09 | N1 | `simplificar` | `\ln\left(e^{x}\right),\ x\in\mathbb{R}` | `x` |  |
| AS-F-10 | N1 | `valor` | `2^{\log_{2}5}` | `5` |  |
| AS-F-11 | N1 | `valor` | `e^{2\ln3}` | `9` |  |
| AS-F-12 | N2 | `valor` | `\log_{4}8` | `\frac{3}{2}` |  |
| AS-F-13 | N2 | `valor` | `\log_{1/2}8` | `-3` |  |
| AS-F-14 | N2 | `valor` | `\log_{2}10` | `3.321928095` |  |
| AS-F-15 | N2 | `simplificar` | `\log_{a}b\cdot\log_{b}a,\ a,b>0,\ a,b\neq1` | `1` |  |
| AS-F-16 | N2 | `simplificar` | `e^{x}e^{y}\ \text{y}\ \left(e^{x}\right)^{2}` | `e^{x+y}\ \text{y}\ e^{2x}` |  |
| AS-F-17 | N2 | `valor` | `\ln\sqrt{e}` | `\frac{1}{2}` |  |
| AS-F-18 | N3 | `convencion` | `\ln(xy)\ \text{con}\ x=y=-1` | `\ln1=0` pero `\ln(-1)+\ln(-1)=2\pi i`: la propiedad no vale sin positividad |  |

---

## AS-G. Ecuaciones de una variable

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-G-01 | N1 | `resolver` | `3x-7=2x+5` | `x=12` |  |
| AS-G-02 | N2 | `resolver` | `\frac{x+1}{2}-\frac{x-1}{3}=1` | `x=1` |  |
| AS-G-03 | N1 | `resolver` | `x^{2}-5x+6=0` | `x=2,\ x=3` |  |
| AS-G-04 | N1 | `resolver` | `x^{2}+6x+9=0` | `x=-3` | Raíz doble. |
| AS-G-05 | N2 | `resolver` | `2x^{2}-3x-2=0` | `x=- \frac{1}{2},\ x=2` |  |
| AS-G-06 | N2 | `resolver` | `x^{2}+2x+5=0\ \text{en }\mathbb{C}` | `x=-1 - 2 i,\ x=-1 + 2 i` | En ℝ no hay solución. |
| AS-G-07 | N2 | `resolver` | `x^{3}-6x^{2}+11x-6=0` | `x=1,\ x=2,\ x=3` |  |
| AS-G-08 | N2 | `resolver` | `x^{4}-5x^{2}+4=0` | `x=-2,\ x=-1,\ x=1,\ x=2` |  |
| AS-G-09 | N2 | `resolver` | `x^{3}-x^{2}-x+1=0` | `x=-1,\ x=1` | `x=1` es raíz doble. |
| AS-G-10 | N2 | `resolver` | `x^{3}-2=0\ \text{en }\mathbb{R}` | `x=\sqrt[3]{2}` |  |
| AS-G-11 | N3 | `resolver` | `x^{3}-2=0\ \text{en }\mathbb{C}` | `x=- \frac{\sqrt[3]{2}}{2} - \frac{\sqrt[3]{2} \sqrt{3} i}{2},\ x=- \frac{\sqrt[3]{2}}{2} + \frac{\sqrt[3]{2} \sqrt{3} i}{2},\ x=\sqrt[3]{2}` | Tres raíces: la real y dos complejas conjugadas. |
| AS-G-12 | N3 | `resolver` | `x^{5}-x-1=0` | `x\approx1.16730398` | Quíntica sin solución por radicales: una raíz real (numérica) y cuatro complejas. No debe inventar una forma cerrada. |
| AS-G-13 | N2 | `resolver` | `\frac{1}{x}+\frac{1}{x+1}=1` | `x=\frac{1}{2} - \frac{\sqrt{5}}{2},\ x=\frac{1}{2} + \frac{\sqrt{5}}{2}` |  |
| AS-G-14 | N2 | `resolver` | `\frac{x^{2}-1}{x-1}=2` | sin solución | La candidata `x=1` anula el denominador: se descarta. |
| AS-G-15 | N2 | `resolver` | `\frac{x}{x-2}=\frac{2}{x-2}` | sin solución | La candidata `x=2` se descarta. |
| AS-G-16 | N2 | `resolver` | `\sqrt{x+2}=x` | `x=2` | `x=-1` es extraña (raíz introducida al elevar al cuadrado). |
| AS-G-17 | N3 | `resolver` | `\sqrt{2x+1}-\sqrt{x-3}=2` | `x=4,\ x=12` |  |
| AS-G-18 | N2 | `resolver` | `\lvert2x-1\rvert=5` | `x=-2,\ x=3` |  |
| AS-G-19 | N2 | `resolver` | `\lvert x\rvert=-1` | sin solución |  |
| AS-G-20 | N3 | `resolver` | `\lvert x-1\rvert=\lvert2x+3\rvert` | `x=-4,\ x=- \frac{2}{3}` |  |
| AS-G-21 | N1 | `resolver` | `2^{x}=8` | `x=3` |  |
| AS-G-22 | N2 | `resolver` | `2^{x}=3` | `x=\frac{\ln{\left(3 \right)}}{\ln{\left(2 \right)}}` |  |
| AS-G-23 | N2 | `resolver` | `3^{2x-1}=27` | `x=2` |  |
| AS-G-24 | N2 | `resolver` | `4^{x}-6\cdot2^{x}+8=0` | `x=1,\ x=2` |  |
| AS-G-25 | N2 | `resolver` | `e^{x}=e^{2x-1}` | `x=1` |  |
| AS-G-26 | N2 | `resolver` | `\ln x+\ln(x-1)=\ln2` | `x=2` | La candidata `x=-1` está fuera del dominio. (SymPy `solveset` la incluye por error; el valor se fijó a mano.) |
| AS-G-27 | N2 | `resolver` | `\log_{2}(x+1)=3` | `x=7` |  |
| AS-G-28 | N3 | `resolver` | `x^{2}=2` | `x=- \sqrt{2},\ x=\sqrt{2}` |  |
| AS-G-29 | N2 | `resolver` | `ax^{2}+bx+c=0,\ a\neq0` | `x=\frac{-b\pm\sqrt{b^{2}-4ac}}{2a}` | Fórmula general. |
| AS-G-30 | N3 | `resolver` | `ax+b=cx+d` | si `a\neq c`: `x=\frac{d-b}{a-c}`; si `a=c` y `b=d`: infinitas; si `a=c` y `b\neq d`: ninguna | Ecuación con parámetros: casos. |
| AS-G-31 | N2 | `resolver` | `V=\pi r^{2}h\ \text{despejar }r\ (r>0)` | `r=\sqrt{\frac{V}{\pi h}}` |  |
| AS-G-32 | N2 | `resolver` | `y=\frac{x+1}{x-2}\ \text{despejar }x` | `x=\frac{2y+1}{y-1}` |  |
| AS-G-33 | N2 | `resolver` | `\frac{1}{f}=\frac{1}{p}+\frac{1}{q}\ \text{despejar }q` | `q=\frac{fp}{p-f}` |  |
| AS-G-34 | N3 | `resolver` | `S=\frac{n}{2}\left(2a+(n-1)d\right)\ \text{despejar }d` | `d=\frac{2S-2an}{n(n-1)}` |  |
| AS-G-35 | N3 | `resolver` | `A=P\left(1+\frac{r}{n}\right)^{nt}\ \text{despejar }P` | `P=A\left(1+\frac{r}{n}\right)^{-nt}` |  |

---

## AS-H. Desigualdades de una variable

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-H-01 | N1 | `desigualdad` | `2x-3<7` | `x\in \left(-\infty, 5\right)` |  |
| AS-H-02 | N1 | `desigualdad` | `-3x\ge12` | `x\in \left(-\infty, -4\right]` | Al dividir entre un negativo se invierte el sentido. |
| AS-H-03 | N1 | `desigualdad` | `x^{2}-x-6>0` | `x\in \left(-\infty, -2\right) \cup \left(3, \infty\right)` |  |
| AS-H-04 | N2 | `desigualdad` | `x^{2}-4x+4\le0` | `x=2` | Un solo punto. |
| AS-H-05 | N1 | `desigualdad` | `x^{2}+1>0` | `x\in \mathbb{R}` |  |
| AS-H-06 | N1 | `desigualdad` | `x^{2}+1<0` | sin solución |  |
| AS-H-07 | N2 | `desigualdad` | `\frac{x-1}{x+2}\le0` | `x\in \left(-2, 1\right]` | `x=-2` no pertenece (denominador). |
| AS-H-08 | N2 | `desigualdad` | `\frac{x}{x^{2}-1}>0` | `x\in \left(-1, 0\right) \cup \left(1, \infty\right)` |  |
| AS-H-09 | N3 | `desigualdad` | `\frac{x+1}{x-1}>2` | `x\in \left(1, 3\right)` | No multiplicar en cruz sin considerar el signo del denominador. |
| AS-H-10 | N2 | `desigualdad` | `\frac{1}{x}<2` | `x\in \left(-\infty, 0\right) \cup \left(\frac{1}{2}, \infty\right)` |  |
| AS-H-11 | N2 | `desigualdad` | `\lvert x-2\rvert<3` | `x\in \left(-1, 5\right)` |  |
| AS-H-12 | N2 | `desigualdad` | `\lvert2x+1\rvert\ge3` | `x\in \left(-\infty, -2\right] \cup \left[1, \infty\right)` |  |
| AS-H-13 | N2 | `desigualdad` | `\lvert x\rvert<-1` | sin solución |  |
| AS-H-14 | N2 | `desigualdad` | `x^{3}-x>0` | `x\in \left(-1, 0\right) \cup \left(1, \infty\right)` |  |
| AS-H-15 | N3 | `desigualdad` | `(x-1)^{2}(x+2)\le0` | `x\in \left(-\infty, -2\right] \cup \left\{1\right\}` | Incluye el punto aislado `x=1`. |
| AS-H-16 | N3 | `desigualdad` | `x^{4}-5x^{2}+4<0` | `x\in \left(-2, -1\right) \cup \left(1, 2\right)` |  |
| AS-H-17 | N2 | `desigualdad` | `\sqrt{x-1}<2` | `x\in \left[1, 5\right)` | Dominio `x\ge1`. |
| AS-H-18 | N3 | `desigualdad` | `\sqrt{x}>x` | `x\in \left(0, 1\right)` |  |
| AS-H-19 | N2 | `desigualdad` | `2^{x}<8` | `x\in \left(-\infty, 3\right)` |  |
| AS-H-20 | N2 | `desigualdad` | `\ln(x-1)>0` | `x\in \left(2, \infty\right)` |  |
| AS-H-21 | N2 | `desigualdad` | `e^{x}\ge1` | `x\in \left[0, \infty\right)` |  |
| AS-H-22 | N2 | `desigualdad` | `\begin{cases}2x+1>3\\ x-4<0\end{cases}` | `x\in \left(1, 4\right)` | Intersección de las soluciones. |
| AS-H-23 | N2 | `desigualdad` | `-1<2x+3\le7` | `x\in \left(-2, 2\right]` |  |

---

## AS-I. Sucesiones, sumatorias, productos y binomio

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-I-01 | N1 | `suma_serie` | `\sum_{k=1}^{n}k` | `\frac{n \left(n + 1\right)}{2}` |  |
| AS-I-02 | N2 | `suma_serie` | `\sum_{k=1}^{n}k^{2}` | `\frac{n \left(n + 1\right) \left(2 n + 1\right)}{6}` |  |
| AS-I-03 | N2 | `suma_serie` | `\sum_{k=1}^{n}k^{3}` | `\frac{n^{2} \left(n + 1\right)^{2}}{4}` |  |
| AS-I-04 | N2 | `suma_serie` | `\sum_{k=1}^{n}(2k-1)` | `n^{2}` |  |
| AS-I-05 | N3 | `suma_serie` | `\sum_{k=1}^{n}\frac{1}{k(k+1)}` | `\frac{n}{n + 1}` |  |
| AS-I-06 | N2 | `suma_serie` | `\sum_{k=0}^{n}2^{k}` | `2^{n + 1} - 1` |  |
| AS-I-07 | N2 | `suma_serie` | `\sum_{k=0}^{n}\binom{n}{k}` | `2^{n}` |  |
| AS-I-08 | N1 | `valor` | `\sum_{k=1}^{100}k` | `5050` |  |
| AS-I-09 | N1 | `valor` | `\sum_{k=1}^{10}k^{2}` | `385` |  |
| AS-I-10 | N1 | `suma_serie` | `\sum_{k=1}^{\infty}\frac{1}{2^{k}}` | `1` |  |
| AS-I-11 | N2 | `suma_serie` | `\sum_{k=0}^{\infty}x^{k},\ \lvert x\rvert<1` | `\frac{1}{1-x}` |  |
| AS-I-12 | N2 | `suma_serie` | `\prod_{k=1}^{n}k` | `n!` |  |
| AS-I-13 | N3 | `suma_serie` | `\prod_{k=2}^{n}\left(1-\frac{1}{k}\right)` | `\frac{1}{n}` |  |
| AS-I-14 | N1 | `valor` | `\binom{8}{3}` | `56` |  |
| AS-I-15 | N1 | `valor` | `\binom{10}{5}` | `252` |  |
| AS-I-16 | N2 | `valor` | `\text{coeficiente de }x^{3}\text{ en }(1+x)^{8}` | `56` |  |
| AS-I-17 | N2 | `valor` | `\text{primeros 20 términos de }3,7,11,\dots\ \text{(suma)}` | `820` | Aritmética con `a_{1}=3`, `d=4`: `\frac{20}{2}(2\cdot3+19\cdot4)`. |
| AS-I-18 | N2 | `valor` | `\text{primeros 6 términos de }2,6,18,\dots\ \text{(suma)}` | `728` | Geométrica con `a_{1}=2`, `r=3`. |

---

## AS-J. Funciones: cociente de diferencias, composición, dominio y polinomios

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-J-01 | N1 | `simplificar` | `\frac{(x+h)^{2}-x^{2}}{h}` | `h + 2 x` |  |
| AS-J-02 | N2 | `simplificar` | `\frac{\frac{1}{x+h}-\frac{1}{x}}{h}` | `- \frac{1}{h x + x^{2}}` |  |
| AS-J-03 | N3 | `simplificar` | `\frac{\sqrt{x+h}-\sqrt{x}}{h}` | `\frac{1}{\sqrt{x+h}+\sqrt{x}}` | Racionalizando el numerador. |
| AS-J-04 | N2 | `simplificar` | `f(g(x))\ \text{con}\ f(x)=x^{2}+1,\ g(x)=\sqrt{x}-1` | `\left(\sqrt{x}-1\right)^{2}+1` | Dominio `x\ge0`. |
| AS-J-05 | N2 | `valor` | `\text{dominio de }\ln\left(x^{2}-1\right)` | `(-\infty,-1)\cup(1,\infty)` |  |
| AS-J-06 | N2 | `valor` | `\text{dominio de }\frac{1}{\sqrt{x-2}}` | `(2,\infty)` |  |
| AS-J-07 | N2 | `valor` | `\text{dominio de }\frac{x+1}{x^{2}-4}` | `\mathbb{R}\setminus\{-2,2\}` |  |
| AS-J-08 | N3 | `valor` | `\text{dominio de }\sqrt{\frac{x-1}{x+3}}` | `(-\infty,-3)\cup[1,\infty)` |  |
| AS-J-09 | N2 | `valor` | `\text{discriminante de }ax^{2}+bx+c` | `b^{2}-4ac` |  |
| AS-J-10 | N2 | `valor` | `\text{suma y producto de raíces de }2x^{2}-7x+3=0` | `\frac{7}{2}\ \text{y}\ \frac{3}{2}` | Relaciones de Vieta. |
| AS-J-11 | N2 | `simplificar` | `x^{2}+6x+2\ \text{completando cuadrados}` | `(x+3)^{2}-7` |  |
| AS-J-12 | N3 | `valor` | `\text{raíces racionales de }2x^{3}-x^{2}-13x-6` | `-2,\ -\frac{1}{2},\ 3` |  |

---

## AS-K. Identidades y expresiones que valen cero

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-K-01 | N2 | `simplificar` | `(x+1)^{2}-\left(x^{2}+2x+1\right)` | `0` |  |
| AS-K-02 | N2 | `simplificar` | `(a+b)^{3}-a^{3}-b^{3}-3ab(a+b)` | `0` |  |
| AS-K-03 | N2 | `simplificar` | `(a+b)^{2}-(a-b)^{2}` | `4ab` |  |
| AS-K-04 | N3 | `simplificar` | `\sin^{2}x+\cos^{2}x-1` | `0` |  |
| AS-K-05 | N3 | `simplificar` | `e^{ix}-(\cos x+i\sin x)` | `0` | Fórmula de Euler. |
| AS-K-06 | N3 | `simplificar` | `\frac{\left(x^{2}-1\right)^{2}-\left(x^{2}+1\right)^{2}}{x^{2}}` | `-4` |  |
| AS-K-07 | N3 | `simplificar` | `\cosh^{2}x-\sinh^{2}x` | `1` |  |

---

## AS-L. Trampas: dominio, ramas y cancelaciones

Casos en los que una simplificación "obvia" cambia el dominio o la rama. El motor debe devolver el resultado correcto o avisar; no la respuesta ingenua.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| AS-L-01 | N2 | `simplificar` | `\frac{x}{x}` | `1` para `x\neq0`; en `x=0` no está definida |  |
| AS-L-02 | N2 | `valor` | `\left.\frac{x^{2}-1}{x-1}\right\rvert_{x=1}` | indeterminado (`0/0`); no debe devolver `2` por cancelar antes de evaluar | El límite sí vale `2`, pero el valor de la expresión en `x=1` no existe. |
| AS-L-03 | N2 | `valor` | `\left.\frac{0}{x}\right\rvert_{x=0}` | indeterminado |  |
| AS-L-04 | N2 | `valor` | `x^{0}\ \text{con}\ x=0` | indeterminado (o `1` por convención declarada) |  |
| AS-L-05 | N3 | `simplificar` | `\left(\sqrt{x}\right)^{2}` | `x` para `x\ge0`; fuera del dominio real no está definida |  |
| AS-L-06 | N3 | `simplificar` | `\sqrt{x^{2}}` | `\lvert x\rvert` | Repetido a propósito: es la trampa más frecuente. |
| AS-L-07 | N3 | `resolver` | `a^{2}=b^{2}` | `a=b\ \text{o}\ a=-b` | No `a=b`. |
| AS-L-08 | N3 | `valor` | `\ln(-1)` | en ℝ: error claro; en ℂ: `i\pi` |  |
| AS-L-09 | N3 | `valor` | `(-1)^{2/2}\ \text{frente a}\ \left((-1)^{2}\right)^{1/2}` | `(-1)^{1}=-1` frente a `1^{1/2}=1`: los exponentes fraccionarios no se simplifican sin cuidado |  |
| AS-L-10 | N3 | `valor` | `\frac{1}{0}` | error claro: división entre cero |  |
| AS-L-11 | N3 | `simplificar` | `x^{\frac{1}{x}}\ \text{con}\ x<0` | no definida en ℝ de forma general (declarar) |  |

---

## Resumen de cobertura

| Sección | Ejercicios |
|---|:-:|
| AS-A · Expansión y productos notables | 17 |
| AS-B · Factorización | 30 |
| AS-C · Expresiones racionales, división de polinomios, MCD y MCM | 23 |
| AS-D · Fracciones parciales | 9 |
| AS-E · Radicales y exponentes | 26 |
| AS-F · Logaritmos y exponenciales (leyes) | 18 |
| AS-G · Ecuaciones de una variable | 35 |
| AS-H · Desigualdades de una variable | 23 |
| AS-I · Sucesiones, sumatorias, productos y binomio | 18 |
| AS-J · Funciones: cociente de diferencias, composición, dominio y polinomios | 12 |
| AS-K · Identidades y expresiones que valen cero | 7 |
| AS-L · Trampas: dominio, ramas y cancelaciones | 11 |
| **Total** | **229** |
