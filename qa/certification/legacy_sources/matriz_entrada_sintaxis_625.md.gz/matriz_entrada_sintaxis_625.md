# Matriz de estrés — Entrada y sintaxis

Batería para evaluar **cómo la calculadora (Precision Lab Lite y Precision Lab Plus) lee lo que se le escribe**, antes de calcular nada. Cubre LaTeX equivalente (`\frac`, `\dfrac`, `\left(\right)`, `\cdot`, `\times`), multiplicación implícita, potencia de función frente a función inversa (`\sin^{2}x` vs `\sin^{-1}x`), exponentes de varios dígitos, alias en español (`sen`, `tg`, `arcsen`, `senh`), decimal con coma o con punto, texto pegado (LaTeX, Unicode, ASCII, Excel, SymPy, Wolfram), teclado, entradas inválidas, **reingreso de la salida como entrada**, seguridad y límites.

La batería tiene **625 filas** repartidas en 26 secciones. Una entrada mal leída produce un resultado "correcto" para otra pregunta: es el fallo más difícil de notar. Por eso esta matriz evalúa primero la **interpretación** (el eco renderizado de lo que el motor entendió) y solo después el valor.

## Convenciones

- Cada entrada va en código, **lista para pegar tal cual**. La columna "Interpretación esperada" dice qué debe entender el motor; cuando hay valor numérico se indica con `=` o `\approx` (9 decimales).
- **En las tablas la barra vertical se escribe `\|`** (para no romper la tabla); al probar se pega una barra simple `|`. Lo mismo vale para `\left\|` y `\right\|`.
- **Nivel:** `N1` básico · `N2` intermedio (requiere regla de precedencia o normalización) · `N3` desafío (ambigüedad real, convención, caso frontera, seguridad o rendimiento).
- **Pasa** = el motor (a) interpreta como se espera, o (b) rechaza con un **error claro**. **Peor resultado** = interpretar distinto **en silencio**.
- **Eco:** la app debe mostrar cómo entendió la entrada (fórmula renderizada). Lo que se evalúa es exactamente lo que se muestra.
- "Error claro" = mensaje en español que dice **qué** falla y **dónde** (resalta el fragmento), sin texto técnico (`SyntaxError`, `Traceback`, `TokenError`, `undefined`, `NaN`, `[object Object]`, `500`).
- Las referencias cruzadas (por ejemplo, NM-12) omiten el prefijo `EN-`.
- Soluciones equivalentes se aceptan. Si una fila depende de una convención (ver tabla siguiente), se aprueba la alternativa **siempre que esté documentada, se muestre en el eco y sea igual en Lite y Plus**; se anota como *observación de convención* (OC), no como fallo.
- Los valores esperados se calcularon a mano y se verificaron por sustitución. Ante una discrepancia, revisar primero el valor esperado.

### Canales de entrada

| Canal | Significado |
|---|---|
| `L` | LaTeX pegado en el campo (por defecto en todas las filas) |
| `T` | Texto plano pegado (`x^2`, `sqrt(x)`, Unicode, Excel, etc.) |
| `⌨` | Tecleado carácter por carácter (teclado físico, teclado virtual de la app, atajos del campo) |
| `R` | Reingreso: se copia una **salida** de la app y se pega como entrada |

La Parte G.2 ejecuta las mismas expresiones por `L`, `T` y `⌨` y exige un único resultado.

### Modos que cambian el resultado

- **Modo decimal:** `.` (punto decimal; coma = separador de miles o de argumentos) o `,` (coma decimal; punto = miles; `;` = separador de argumentos). Las filas dependientes indican "Modo `.`" y "Modo `,`". Ejecutar ambos.
- **Ángulos:** RAD o DEG, solo donde se indica.
- **Dominio:** ℝ o ℂ, solo donde se indica.

### Decisiones de convención que esta matriz asume

Cada una es una decisión de producto. Si decides otra, cambia el esperado de las filas indicadas y deja la decisión escrita en la ayuda de la app.

| ID | Decisión | Valor asumido aquí | Alternativa frecuente | Filas |
|---|---|---|---|---|
| C1 | `/` e implícita (`1/2x`, `6/2(1+2)`) | Misma precedencia, de izquierda a derecha: `1/2x=\frac{x}{2}`, `6/2(1+2)=9` | Implícita más fuerte (Casio, TI-82): `1/(2x)`, `1` | MI-27…MI-32 |
| C2 | `\log x` sin base | Base 10 (`\log 1000=3`); `\ln` es natural | `\log` natural (SymPy, Wolfram, ciencia) | AL-26, FP-20, RE-06 |
| C3 | `f^{-1}` en funciones trigonométricas | Función inversa (`\sin^{-1}x=\arcsin x`) | Recíproco `1/\sin x` | FP-04…FP-06, FP-17 |
| C4 | Exponente sin llaves | Dígitos voraces: `x^{23}` para `x^23`, `2^{10}` para `2^10` | TeX estricto: un solo token (`x^{2}3`) | EX-02, EX-10, TC-01 |
| C5 | Función con paréntesis explícitos | Es completa: `\sin(x)^{2}=(\sin x)^{2}` | Exponente dentro del argumento | FP-11, FA-23 |
| C6 | `2e3` | Notación científica: `2000` | Producto `2\cdot e\cdot3` | CI-05, CI-06 |
| C7 | `\%` | Posfijo `/100`: `100+15\%=100.15` | Comercial: `100+15\%=115` | PC-05 |
| C8 | `2\frac{1}{2}` | Producto: `1` | Número mixto `\frac{5}{2}` | MI-33 |
| C9 | `(-8)^{1/3}` | Declarar: raíz real `-2` en ℝ, principal compleja `1+\sqrt{3}i` en ℂ | Una sola para ambos | EX-27 |
| C10 | Letras juntas (`xy`, `ex`, `abc`) | Producto de variables; funciones y constantes tienen prioridad (`sen`, `abs`, `ln`, `pi`) | Identificador de varias letras | MI-09, MI-10, MI-18, AL-30 |
| C11 | `0^{0}` | Declarar (`1` o indefinido) | — | ER-24 |
| C12 | `E`, `I`, `N`, `S`, `Q` mayúsculas | Variables simples (la constante de Euler es `e`, la unidad imaginaria es `i`) | Constantes/clases del motor | CV-24 |
| C13 | `x!=3` | Ambiguo: avisar o `x\neq3`; **nunca** `(x!)=3` en silencio | — | AS-21 |

### Criterios transversales (aplican a todas las filas)

1. **Fidelidad al eco:** el valor corresponde a lo que se ve renderizado, no a otra lectura.
2. **Invariancia al canal:** `L`, `T` y `⌨` dan el mismo resultado (S5).
3. **Paridad Lite/Plus:** misma entrada, misma interpretación y mismo valor (a 9 decimales) o ambos con error claro.
4. **Locale:** el resultado no cambia por la configuración regional del navegador o del teclado, solo por el modo decimal elegido.
5. **Idempotencia:** `entrada → salida → entrada → salida` llega a un punto fijo (Parte H.1).
6. **Errores comprensibles** (ver convención).
7. **Tiempo:** analizar una entrada típica en menos de ~100 ms; las pesadas se cancelan sin congelar la interfaz.

## Categorías de fallo sugeridas para el registro

| Código | Significado | Gravedad |
|---|---|---|
| S1 | Interpreta distinto a lo esperado **en silencio** (mal-parseo) | Crítica |
| S2 | Rechaza una entrada válida ("no soportado", error falso) | Alta |
| S3 | Acepta una entrada inválida sin avisar (descarta caracteres, autocompleta, adivina) | Alta |
| S4 | Error críptico, técnico, en inglés o sin ubicación; traza, `NaN` o `500` | Media |
| S5 | Inconsistencia entre canales (`L`/`T`/`⌨`) o entre Lite y Plus | Alta |
| S6 | Reingreso: la salida no vuelve a entrar o cambia al reingresarla | Alta |
| S7 | Normalización: Unicode, espacios o contenedores LaTeX no limpiados | Media |
| S8 | Precisión de la entrada (decimal binario, entero grande, notación científica) | Alta |
| S9 | Seguridad o robustez: ejecución de código, XSS, bloqueo, memoria sin límite | Crítica |
| S10 | Convención no documentada ni mostrada en el eco | Baja |
| S11 | Teclado/UI: atajo, cursor o autoformato que altera lo escrito | Media |

---

# PARTE A — LaTeX EQUIVALENTE Y ESTRUCTURA

## A1. Fracciones

Canal `L`. Todas las formas de fracción deben producir el mismo árbol.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-FR-01 | N1 | `\frac{1}{2}` | `\frac{1}{2}=0.5` |
| EN-FR-02 | N1 | `\dfrac{1}{2}` | Igual que EN-FR-01 |
| EN-FR-03 | N1 | `\tfrac{1}{2}` | Igual que EN-FR-01 |
| EN-FR-04 | N2 | `\cfrac{1}{2}` | Igual que EN-FR-01 |
| EN-FR-05 | N2 | `{1\over 2}` | Igual que EN-FR-01 |
| EN-FR-06 | N1 | `1/2` | Igual que EN-FR-01 |
| EN-FR-07 | N1 | `\frac{x+1}{x-1}` | `(x+1)/(x-1)`: numerador y denominador completos |
| EN-FR-08 | N2 | `(x+1)/(x-1)` | Igual que EN-FR-07 |
| EN-FR-09 | N3 | `x+1\over x-1` | Igual que EN-FR-07 (`\over` actúa sobre todo el grupo) |
| EN-FR-10 | N2 | `\frac12` | `\frac{1}{2}` (un dígito por argumento, sin llaves) |
| EN-FR-11 | N2 | `\frac1x` | `\frac{1}{x}` |
| EN-FR-12 | N2 | `\frac{12}3` | `\frac{12}{3}=4` |
| EN-FR-13 | N3 | `\frac123` | `\frac{1}{2}\cdot3=1.5` (o aviso de ambigüedad); nunca `\frac{1}{23}` ni `123` |
| EN-FR-14 | N2 | `\frac{\frac{1}{2}}{3}` | `\frac{1}{6}` |
| EN-FR-15 | N2 | `\frac{1}{\frac{1}{2}}` | `2` |
| EN-FR-16 | N3 | `\frac{1}{\frac{1}{x}+\frac{1}{y}}` | `\frac{xy}{x+y}` |
| EN-FR-17 | N2 | `\frac{1}{2}x` | `\frac{x}{2}`: la `x` **no** entra al denominador |
| EN-FR-18 | N2 | `\frac{1}{2x}` | `\frac{1}{2x}` |
| EN-FR-19 | N2 | `\frac{a}{b}\frac{c}{d}` | `\frac{ac}{bd}` (producto de fracciones) |
| EN-FR-20 | N2 | `x+1/x-1` | `x+\frac{1}{x}-1`: la barra liga solo `1` y `x` |
| EN-FR-21 | N2 | `\frac{2}{3}+\frac{3}{4}` | `\frac{17}{12}\approx1.416666667` (exacto, no decimal) |
| EN-FR-22 | N2 | `\frac{1.5}{2}` | `0.75` |
| EN-FR-23 | N2 | `\frac{\pi}{2}` | `\approx1.570796327` |
| EN-FR-24 | N2 | `\frac{\sqrt{2}}{2}` | `\approx0.707106781` |

## A2. Delimitadores y valor absoluto

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-DL-01 | N1 | `\left(x+1\right)^{2}` | Igual que `(x+1)^{2}` |
| EN-DL-02 | N1 | `\left[x+1\right]^{2}` | Corchetes como agrupación: igual que EN-DL-01 |
| EN-DL-03 | N2 | `2\left\{3+4\right\}` | `14` (llaves como agrupación) o error claro si se reservan para conjuntos |
| EN-DL-04 | N2 | `\bigl(x+1\bigr)^{2}` | Igual que EN-DL-01 (`\big`, `\Big`, `\bigg`, `\Bigg` solo cambian el tamaño) |
| EN-DL-05 | N2 | `\Bigl(\frac{1}{2}\Bigr)^{3}` | `\frac{1}{8}` |
| EN-DL-06 | N3 | `\mleft(x+1\mright)^{2}` | Igual que EN-DL-01 (macros que emite MathLive) |
| EN-DL-07 | N1 | `((x))` | `x` (paréntesis redundantes) |
| EN-DL-08 | N2 | `\left(2+3\right)\left(4-1\right)` | `15` |
| EN-DL-09 | N2 | `\left(\frac{1}{2}\right)^{-2}` | `4` |
| EN-DL-10 | N1 | `\lvert x-1\rvert` | `\lvert x-1\rvert`; en `x=-2` vale `3` |
| EN-DL-11 | N1 | `\|x-1\|` | Igual que EN-DL-10 (barra simple) |
| EN-DL-12 | N2 | `\left\| x-1 \right\|` | Igual que EN-DL-10 |
| EN-DL-13 | N3 | `\|\|x\|-1\|` | `\lvert\lvert x\rvert-1\rvert`: en `x=-3` vale `2`; en `x=0` vale `1` (la `\|\|` no se lee como "o" ni como vacío) |
| EN-DL-14 | N3 | `\lvert\lvert x\rvert-1\rvert` | Igual que EN-DL-13 |
| EN-DL-15 | N2 | `\lvert x\rvert\lvert y\rvert` | Producto `\lvert x\rvert\cdot\lvert y\rvert` |
| EN-DL-16 | N2 | `\lfloor 2.7\rfloor` y `\lfloor -2.5\rfloor` | `2` y `-3` |
| EN-DL-17 | N2 | `\lceil 2.1\rceil` | `3` |
| EN-DL-18 | N3 | `\left(1,3\right]` | Intervalo semiabierto; delimitadores distintos **no** son error de balance cuando se leen como intervalo |
| EN-DL-19 | N3 | `[1,3)` | Igual que EN-DL-18 |
| EN-DL-20 | N3 | `\lVert\begin{pmatrix}3\\4\end{pmatrix}\rVert` | Norma `=5`; si no se soporta, error claro |

## A3. Operadores, factorial y relaciones

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-OP-01 | N1 | `2\cdot3` | `6` |
| EN-OP-02 | N1 | `2\times3` | `6` |
| EN-OP-03 | N1 | `2*3` | `6` |
| EN-OP-04 | N1 | `2\ast3` | `6` |
| EN-OP-05 | N1 | `6\div3` | `2` |
| EN-OP-06 | N1 | `6/3` | `2` |
| EN-OP-07 | N2 | `6:3` | `2` o error claro; nunca rango ni asignación en silencio |
| EN-OP-08 | N2 | `2\cdot x\cdot y` | `2xy` |
| EN-OP-09 | N2 | `x\times y` | Producto `xy` (no producto vectorial) |
| EN-OP-10 | N3 | `\begin{pmatrix}1\\0\\0\end{pmatrix}\times\begin{pmatrix}0\\1\\0\end{pmatrix}` | Producto vectorial `(0,0,1)` (si el motor soporta vectores) |
| EN-OP-11 | N2 | `5\pm2` | Los dos valores `7` y `3` |
| EN-OP-12 | N2 | `x\leq3`, `x\le3`, `x\leqslant3` | La misma desigualdad `x\le3` |
| EN-OP-13 | N2 | `x\geq3`, `x\ge3`, `x\geqslant3` | La misma desigualdad `x\ge3` |
| EN-OP-14 | N2 | `x\neq3`, `x\ne3` | La misma relación `x\ne3` |
| EN-OP-15 | N2 | `x\lt3`, `x\gt3`, `x<3`, `x>3` | `x<3` y `x>3` según el caso |
| EN-OP-16 | N2 | `5!` y `0!` | `120` y `1` |
| EN-OP-17 | N3 | `5!!` | `15` (doble factorial) |
| EN-OP-18 | N3 | `3!^{2}` | `(3!)^{2}=36` |
| EN-OP-19 | N3 | `-3!` | `-(3!)=-6` |
| EN-OP-20 | N3 | `2^{3!}` | `2^{6}=64` |
| EN-OP-21 | N2 | `\binom{5}{2}` | `10` |
| EN-OP-22 | N3 | `{5\choose2}` | `10` |
| EN-OP-23 | N3 | `17\bmod5` | `2` |
| EN-OP-24 | N2 | `\gcd(12,18)` | `6` |

## A4. Raíces

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-RD-01 | N1 | `\sqrt{4}` | `2` |
| EN-RD-02 | N1 | `\sqrt4` | `2` (sin llaves) |
| EN-RD-03 | N2 | `\sqrt2` | `\approx1.414213562` |
| EN-RD-04 | N2 | `\sqrt x` | `\sqrt{x}` |
| EN-RD-05 | N2 | `\sqrt{x}y` | `\sqrt{x}\cdot y`: la `y` queda **fuera** del radical |
| EN-RD-06 | N2 | `\sqrt[3]{8}` | `2` |
| EN-RD-07 | N2 | `\sqrt[3]{-8}` | `-2` (raíz real de índice impar) |
| EN-RD-08 | N2 | `\sqrt[3]4` | `\approx1.587401052` |
| EN-RD-09 | N2 | `\sqrt[10]{1024}` | `2` (índice de dos dígitos, no `\sqrt[1]` seguido de `0`) |
| EN-RD-10 | N2 | `\sqrt[n]{x}` | `x^{1/n}` |
| EN-RD-11 | N2 | `\sqrt{\sqrt{\sqrt{256}}}` | `2` |
| EN-RD-12 | N2 | `2\sqrt{3}` | `\approx3.464101615` |
| EN-RD-13 | N2 | `\sqrt{2}\sqrt{3}` | `\sqrt{6}\approx2.449489743` |
| EN-RD-14 | N2 | `x^{\frac{1}{2}}` | Igual que `\sqrt{x}` |
| EN-RD-15 | N2 | `\sqrt{-4}` | ℝ: error claro · ℂ: `2i` |

---

# PARTE B — EXPONENTES, ÍNDICES Y MULTIPLICACIÓN IMPLÍCITA

## B1. Exponentes

Esta sección ataca el origen del bug de `2^{10}`: el exponente de varios dígitos leído como `2^{1}\cdot0`, `20`, `0` o error.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-EX-01 | N1 | `2^{10}` | `1024` |
| EN-EX-02 | N1 | `2^10` | `1024` (C4); nunca `2^{1}\cdot0` |
| EN-EX-03 | N1 | `2^{12}` | `4096` |
| EN-EX-04 | N2 | `2^{100}` | `1267650600228229401496703205376` (entero exacto) |
| EN-EX-05 | N2 | `10^{-12}` | `0.000000000001` |
| EN-EX-06 | N2 | `10^{100}` | Un `1` seguido de 100 ceros, exacto |
| EN-EX-07 | N2 | `x^{10}` | `x^{10}` (no `x^{1}\cdot0`) |
| EN-EX-08 | N2 | `x^{-10}` | `\frac{1}{x^{10}}` |
| EN-EX-09 | N2 | `x^{100}` | `x^{100}` |
| EN-EX-10 | N3 | `x^23` | `x^{23}` (C4); en TeX estricto sería `x^{2}\cdot3`: lo que se haga debe verse en el eco |
| EN-EX-11 | N3 | `x^{2}3` | `3x^{2}` (el `3` fuera del exponente) |
| EN-EX-12 | N1 | `x^2` | `x^{2}` |
| EN-EX-13 | N1 | `x^{-1}` | `\frac{1}{x}` |
| EN-EX-14 | N2 | `x^-1` | `x^{-1}` (signo sin llaves, texto plano) |
| EN-EX-15 | N2 | `2^-x` | `2^{-x}` |
| EN-EX-16 | N2 | `x^{1/2}` | `\sqrt{x}` |
| EN-EX-17 | N2 | `x^{0.5}` | `\sqrt{x}` |
| EN-EX-18 | N2 | `x^{2n}` | `x^{2\cdot n}` |
| EN-EX-19 | N2 | `x^{a+b}` | `x^{a+b}` |
| EN-EX-20 | N2 | `2^{3^{2}}` | `2^{9}=512` |
| EN-EX-21 | N2 | `2^3^2` | `512` (asociatividad por la derecha) |
| EN-EX-22 | N2 | `(2^3)^2` | `64` |
| EN-EX-23 | N3 | `x^{2}^{3}` | Error claro (doble exponente); si se acepta, `(x^{2})^{3}=x^{6}` mostrado en el eco |
| EN-EX-24 | N2 | `-2^2` | `-(2^{2})=-4` |
| EN-EX-25 | N2 | `(-2)^2` | `4` |
| EN-EX-26 | N2 | `-x^2` | `-(x^{2})` |
| EN-EX-27 | N3 | `(-8)^{1/3}` | C9: ℝ `-2` · ℂ `1+\sqrt{3}i\approx1+1.732050808i` |
| EN-EX-28 | N2 | `e^{-x^{2}}` | `e^{-(x^{2})}` |
| EN-EX-29 | N2 | `e^{2x+1}` | `e^{2x+1}` |
| EN-EX-30 | N2 | `e^\pi` | `\approx23.140692633` (símbolo sin llaves como exponente) |
| EN-EX-31 | N2 | `e^{i\pi}` | `-1` (ℂ) |
| EN-EX-32 | N2 | `\exp(x)` y `\exp x` | `e^{x}` |
| EN-EX-33 | N3 | `2^{-2^{2}}` | `2^{-4}=\frac{1}{16}` |
| EN-EX-34 | N2 | `x_1^2` | `(x_{1})^{2}` |
| EN-EX-35 | N2 | `x^{2}_{1}` | `(x_{1})^{2}` (orden inverso, válido en TeX) |

## B2. Subíndices y bases de logaritmo

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-SB-01 | N2 | `x_{10}` | Variable `x_{10}` (no `x_{1}\cdot0`) |
| EN-SB-02 | N2 | `x_1+x_2` | Suma de dos símbolos distintos |
| EN-SB-03 | N3 | `a_{i,j}` | Un solo símbolo con subíndice `i,j` (la coma no separa argumentos) |
| EN-SB-04 | N3 | `x_{\text{max}}` | Un solo símbolo |
| EN-SB-05 | N1 | `\log_{2}8` | `3` |
| EN-SB-06 | N2 | `\log_28` | `3` (sin llaves) |
| EN-SB-07 | N2 | `\log_{10}1000` | `3` (base de dos dígitos) |
| EN-SB-08 | N2 | `\log_{16}256` | `2` |
| EN-SB-09 | N3 | `\log_{2}8^{2}` | `\log_{2}\left(8^{2}\right)=6`: el exponente pertenece al argumento |
| EN-SB-10 | N2 | `\log_{b}x` | `\frac{\ln x}{\ln b}` (base simbólica) |

## B3. Multiplicación implícita

Incluye las ambigüedades C1, C8 y C10. En el canal `⌨` repetir MI-27…MI-30 (la fracción automática cambia la lectura).

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-MI-01 | N1 | `2x` | `2\cdot x` |
| EN-MI-02 | N1 | `2(3)` | `6` |
| EN-MI-03 | N1 | `(2)(3)` | `6` |
| EN-MI-04 | N1 | `(x+1)(x-1)` | `x^{2}-1` al expandir |
| EN-MI-05 | N1 | `x(x+1)` | `x\cdot(x+1)` (producto, no llamada a función) |
| EN-MI-06 | N2 | `2x^2` | `2\cdot(x^{2})`, no `(2x)^{2}` |
| EN-MI-07 | N2 | `-2x^2` | `-(2x^{2})` |
| EN-MI-08 | N2 | `3x^2y` | `3\cdot x^{2}\cdot y` |
| EN-MI-09 | N2 | `xy` | `x\cdot y` (C10) |
| EN-MI-10 | N2 | `xyz` | `x\cdot y\cdot z` |
| EN-MI-11 | N2 | `2\pi` | `\approx6.283185307` |
| EN-MI-12 | N2 | `2\pi x` | `2\pi\cdot x` |
| EN-MI-13 | N2 | `\pi r^{2}` | `\pi\cdot r^{2}` |
| EN-MI-14 | N2 | `3\sqrt{2}` | `\approx4.242640687` |
| EN-MI-15 | N2 | `2e` | `\approx5.436563657` |
| EN-MI-16 | N2 | `2e^{x}` | `2\cdot e^{x}` |
| EN-MI-17 | N2 | `xe^{x}` | `x\cdot e^{x}` |
| EN-MI-18 | N2 | `ex` | `e\cdot x` (C10) |
| EN-MI-19 | N2 | `2\sin x` | `2\cdot\sin x` |
| EN-MI-20 | N2 | `x\sin x` | `x\cdot\sin x` |
| EN-MI-21 | N2 | `\sin x\cos x` | `(\sin x)(\cos x)` |
| EN-MI-22 | N2 | `(a+b)c` | `(a+b)\cdot c` |
| EN-MI-23 | N2 | `2(3)(4)` | `24` |
| EN-MI-24 | N2 | `2(3)^{2}` | `2\cdot(3^{2})=18` |
| EN-MI-25 | N2 | `3(x+1)^{2}` | `3\cdot\left((x+1)^{2}\right)` |
| EN-MI-26 | N3 | `x2` | `2x`: letra seguida de dígito es producto, no subíndice |
| EN-MI-27 | N3 | `1/2x` | C1: `\frac{x}{2}` (alternativa: `\frac{1}{2x}`); el eco debe mostrar cuál |
| EN-MI-28 | N3 | `1/2\pi` | C1: `\frac{\pi}{2}\approx1.570796327` (alternativa `\frac{1}{2\pi}\approx0.159154943`) |
| EN-MI-29 | N3 | `2/3x` | C1: `\frac{2}{3}x` |
| EN-MI-30 | N3 | `a/bc` | C1: `\frac{a}{b}\cdot c` |
| EN-MI-31 | N3 | `6/2(1+2)` | C1: `9` (alternativa `1`) |
| EN-MI-32 | N3 | `6\div2(1+2)` | C1: `9` (alternativa `1`) |
| EN-MI-33 | N3 | `2\frac{1}{2}` | C8: producto `2\cdot\frac{1}{2}=1` (alternativa número mixto `\frac{5}{2}`) |
| EN-MI-34 | N2 | `2\left(3+4\right)` | `14` |
| EN-MI-35 | N2 | `\left(3+4\right)2` | `14` |
| EN-MI-36 | N2 | `3\,x` | `3x` (espacio fino) |

## B4. Precedencia y signos

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-PR-01 | N1 | `2+3\cdot4` | `14` |
| EN-PR-02 | N1 | `(2+3)\cdot4` | `20` |
| EN-PR-03 | N1 | `8/2/2` | `2` (izquierda a derecha) |
| EN-PR-04 | N1 | `8/2*4` | `16` |
| EN-PR-05 | N1 | `2-3-4` | `-5` |
| EN-PR-06 | N2 | `2*3^2` | `18` |
| EN-PR-07 | N2 | `2-(-3)` | `5` |
| EN-PR-08 | N2 | `2--3` | `5` con eco `2-(-3)`, o error claro; nunca `2-3` |
| EN-PR-09 | N2 | `2+-3` | `-1` |
| EN-PR-10 | N2 | `2*-3` | `-6` |
| EN-PR-11 | N2 | `2++3` | `5` |
| EN-PR-12 | N2 | `--x` | `x` |
| EN-PR-13 | N3 | `-2^{-2}` | `-\frac{1}{4}` |
| EN-PR-14 | N2 | `1-1+1` | `1` |

---

# PARTE C — FUNCIONES Y NOMBRES

## C1. Potencia de una función frente a función inversa

Regla (C3): `\sin^{2}x=(\sin x)^{2}`, pero `\sin^{-1}x=\arcsin x` (inversa), y `\sin^{-2}x=\frac{1}{\sin^{2}x}`.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-FP-01 | N1 | `\sin^{2}x` | `(\sin x)^{2}`; en `x=\frac{\pi}{6}` vale `\frac{1}{4}` |
| EN-FP-02 | N1 | `\sin^{2}(x)` | Igual que EN-FP-01 |
| EN-FP-03 | N1 | `\sin^2 x` | Igual que EN-FP-01 (sin llaves) |
| EN-FP-04 | N1 | `\sin^{-1}x` | `\arcsin x`; `\sin^{-1}\left(\frac{1}{2}\right)=\frac{\pi}{6}` |
| EN-FP-05 | N1 | `\cos^{-1}x` | `\arccos x`; `\cos^{-1}\left(\frac{1}{2}\right)=\frac{\pi}{3}` |
| EN-FP-06 | N1 | `\tan^{-1}x` | `\arctan x`; `\tan^{-1}(1)=\frac{\pi}{4}` |
| EN-FP-07 | N2 | `\sin^{-2}x` | `\frac{1}{\sin^{2}x}` |
| EN-FP-08 | N2 | `\left(\sin x\right)^{-1}` | `\frac{1}{\sin x}=\csc x` (**no** `\arcsin x`) |
| EN-FP-09 | N2 | `\frac{1}{\sin x}` | `\csc x` |
| EN-FP-10 | N2 | `\left(\sin x\right)^{2}` | Igual que EN-FP-01 |
| EN-FP-11 | N2 | `\sin(x)^{2}` | C5: `(\sin x)^{2}` |
| EN-FP-12 | N2 | `\sin(x^{2})` | `\sin\left(x^{2}\right)` |
| EN-FP-13 | N2 | `\sin x^{2}` | `\sin\left(x^{2}\right)`: el exponente pertenece al argumento |
| EN-FP-14 | N3 | `\sin^{2}x^{2}` | `\left(\sin\left(x^{2}\right)\right)^{2}` |
| EN-FP-15 | N2 | `\sin^{3}x` | `(\sin x)^{3}` |
| EN-FP-16 | N2 | `\sin^{2}3x` | `(\sin 3x)^{2}` |
| EN-FP-17 | N2 | `\sinh^{-1}(1)` y `\cosh^{-1}(1)` | `\operatorname{arsinh}(1)\approx0.881373587` y `\operatorname{arcosh}(1)=0` |
| EN-FP-18 | N2 | `\csc^{-1}2`, `\sec^{-1}2`, `\cot^{-1}1` | `\frac{\pi}{6}`, `\frac{\pi}{3}`, `\frac{\pi}{4}` |
| EN-FP-19 | N2 | `\ln^{2}\left(e^{3}\right)` | `\left(\ln e^{3}\right)^{2}=9` |
| EN-FP-20 | N2 | `\log^{2}1000` | C2: `(\log 1000)^{2}=9` |
| EN-FP-21 | N3 | `\ln^{-1}x` | Ambigua (`\frac{1}{\ln x}` o `e^{x}`): aviso o error claro; si interpreta, el eco lo muestra |
| EN-FP-22 | N3 | `\sin x^{-1}` | `\sin\left(x^{-1}\right)` (no arcsin ni recíproco) |
| EN-FP-23 | N2 | `\sin^{2}x+\cos^{2}x` | Vale `1` para cualquier `x` (probar `x=1.23`) |
| EN-FP-24 | N3 | `\sin^{1}x` y `\sin^{0}x` | `\sin x` y `1` |
| EN-FP-25 | N3 | `f^{2}(x)` | Ambigua (`(f(x))^{2}` o `f(f(x))`): aviso o eco explícito |

## C2. Argumento sin paréntesis

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-FA-01 | N1 | `\sin x` | `\sin(x)` |
| EN-FA-02 | N2 | `\sin 2x` | `\sin(2x)` |
| EN-FA-03 | N2 | `\sin2x` | `\sin(2x)` (sin espacio) |
| EN-FA-04 | N2 | `\sin x+1` | `(\sin x)+1` |
| EN-FA-05 | N2 | `\sin x\cos x` | `(\sin x)(\cos x)` |
| EN-FA-06 | N2 | `\sin 2x\cos 3x` | `\sin(2x)\cdot\cos(3x)` |
| EN-FA-07 | N2 | `\sin\frac{\pi}{6}` | `\frac{1}{2}` |
| EN-FA-08 | N2 | `\sin\pi x` | `\sin(\pi x)` |
| EN-FA-09 | N2 | `\sin 2\pi x` | `\sin(2\pi x)` |
| EN-FA-10 | N2 | `\sin x/2` | `\frac{\sin x}{2}` |
| EN-FA-11 | N3 | `\sin\cos x` | `\sin(\cos x)` (composición sin paréntesis) |
| EN-FA-12 | N3 | `\sin\sin x` | `\sin(\sin x)` |
| EN-FA-13 | N2 | `\ln x^{2}` | `\ln\left(x^{2}\right)` |
| EN-FA-14 | N2 | `\ln 2x` | `\ln(2x)` |
| EN-FA-15 | N2 | `\ln x+1` | `(\ln x)+1` |
| EN-FA-16 | N3 | `\sin x\cdot2` | `(\sin x)\cdot2` (el `\cdot` termina el argumento) |
| EN-FA-17 | N3 | `\cos 2x^{2}` | `\cos\left(2x^{2}\right)` |
| EN-FA-18 | N2 | `\sin(\pi/6)` | `\frac{1}{2}` |
| EN-FA-19 | N2 | `\operatorname{sin}x` | `\sin x` |
| EN-FA-20 | N2 | `\sin 30^{\circ}` | `\frac{1}{2}`, **igual en RAD y en DEG** (el grado es explícito) |
| EN-FA-21 | N2 | `\cos\left(60^{\circ}\right)` | `\frac{1}{2}` en RAD y en DEG |
| EN-FA-22 | N2 | `\sin 30` | RAD: `\approx-0.988031624` · DEG: `\frac{1}{2}` |
| EN-FA-23 | N3 | `\sin(x+1)^{2}` | C5: `\left(\sin(x+1)\right)^{2}` |

## C3. Alias en español y otros nombres de función

Canales `L` y `T`. Cada alias debe reconocerse como **función** (nunca como producto `s·e·n·x`) y mostrarse en el eco con letra recta. Si la interfaz está en español, la salida puede usar `sen`/`tg`, pero debe poder reingresarse (Parte H.1).

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-AL-01 | N1 | `\operatorname{sen}\left(\frac{\pi}{6}\right)` | `\sin\frac{\pi}{6}=\frac{1}{2}` |
| EN-AL-02 | N1 | `\mathrm{sen}\,x` | `\sin x` |
| EN-AL-03 | N2 | `\text{sen}(x)` | `\sin x` |
| EN-AL-04 | N1 | `sen(x)` | `\sin x` |
| EN-AL-05 | N1 | `sen x` | `\sin x` |
| EN-AL-06 | N2 | `\sen x` | `\sin x` (macro común en documentos en español) |
| EN-AL-07 | N2 | `sen^{2}x` y `sen^2(x)` | `(\sin x)^{2}` |
| EN-AL-08 | N2 | `sen^{-1}x` | `\arcsin x` |
| EN-AL-09 | N2 | `Sen x` y `SEN(x)` | `\sin x`, o error claro; nunca `S\cdot e\cdot n\cdot x` |
| EN-AL-10 | N1 | `tg x`, `\operatorname{tg}x`, `\tg x` | `\tan x` |
| EN-AL-11 | N1 | `ctg x`, `cotg x`, `\operatorname{cotg}x` | `\cot x` |
| EN-AL-12 | N1 | `cosec x`, `\operatorname{cosec}x` | `\csc x` |
| EN-AL-13 | N1 | `arcsen(1/2)` y `\operatorname{arcsen}\frac{1}{2}` | `\frac{\pi}{6}` |
| EN-AL-14 | N1 | `arccos(1/2)` | `\frac{\pi}{3}` |
| EN-AL-15 | N1 | `arctg(1)` y `\operatorname{arctg}1` | `\frac{\pi}{4}` |
| EN-AL-16 | N2 | `arcctg(0)` y `arccotg(0)` | `\frac{\pi}{2}` (rango de `\operatorname{arccot}` es `(0,\pi)`) |
| EN-AL-17 | N2 | `arccosec(2)` y `arccsc(2)` | `\frac{\pi}{6}` |
| EN-AL-18 | N2 | `arcsec(2)` | `\frac{\pi}{3}` |
| EN-AL-19 | N1 | `senh(1)` y `\operatorname{senh}1` | `\sinh 1\approx1.175201194` |
| EN-AL-20 | N1 | `tgh(1)` y `\operatorname{tgh}1` | `\tanh 1\approx0.761594156` |
| EN-AL-21 | N2 | `ctgh(1)` y `cotgh(1)` | `\coth 1\approx1.313035285` |
| EN-AL-22 | N2 | `sech(0)` y `cosech(1)` | `\operatorname{sech}0=1` y `\operatorname{csch}1\approx0.850918128` |
| EN-AL-23 | N2 | `argsenh(1)`, `arcsenh(1)` | `\operatorname{arsinh}1\approx0.881373587` |
| EN-AL-24 | N2 | `argcosh(1)` | `0` |
| EN-AL-25 | N2 | `argtgh(1/2)`, `arctgh(1/2)` | `\operatorname{artanh}\frac{1}{2}\approx0.549306144` |
| EN-AL-26 | N2 | `\log 1000`, `log(1000)`, `lg 1000` | C2: `3` (base 10) |
| EN-AL-27 | N1 | `ln(e)` | `1` |
| EN-AL-28 | N2 | `raiz(16)`, `raíz(16)`, `\operatorname{raiz}(16)` | `4` |
| EN-AL-29 | N2 | `abs(-3)` y `\operatorname{abs}(-3)` | `3` |
| EN-AL-30 | N2 | `abs(x)` | `\lvert x\rvert`; **no** `a\cdot b\cdot s\cdot x` (C10: la función gana) |
| EN-AL-31 | N2 | `exp(1)` | `\approx2.718281828` |
| EN-AL-32 | N2 | `\operatorname{mcd}(12,18)` y `\operatorname{mcm}(4,6)` | `6` y `12` |
| EN-AL-33 | N2 | `\max(2,5)` y `\operatorname{máx}(2,5)` | `5` (en ambos modos decimales) |
| EN-AL-34 | N3 | `\operatorname{mín}(2;5,5)` | Modo `,`: `2` (el `;` separa argumentos, `5,5` es decimal) |
| EN-AL-35 | N3 | `\max(2;5,5)` | Modo `,`: `5.5` |
| EN-AL-36 | N2 | `pi`, `PI`, `Pi`, `\pi`, `π` | `\approx3.141592654` |

## C4. Constantes, variables y funciones definidas

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-CV-01 | N1 | `e^{x}` | `e` es la constante de Euler, no una variable |
| EN-CV-02 | N2 | `\mathrm{e}^{x}`, `\exponentialE^{x}` | Igual que EN-CV-01 |
| EN-CV-03 | N2 | `i^{2}` | ℂ: `-1` |
| EN-CV-04 | N2 | `\imaginaryI^{2}`, `\mathrm{i}^{2}` | Igual que EN-CV-03 |
| EN-CV-05 | N3 | `\sum_{i=1}^{3}i^{2}` | `14`: el índice `i` **no** es la unidad imaginaria |
| EN-CV-06 | N2 | `\theta^{2}`, `2\theta`, `\sin\theta` | `\theta^{2}`, `2\cdot\theta`, `\sin\theta` (símbolos griegos como variables) |
| EN-CV-07 | N2 | `\lambda x` | `\lambda\cdot x` (sin error de palabra reservada) |
| EN-CV-08 | N2 | `\alpha\beta` | `\alpha\cdot\beta` (dos símbolos, no el identificador `alphabeta`) |
| EN-CV-09 | N3 | `\Delta x` | `\Delta\cdot x` |
| EN-CV-10 | N3 | `dx` fuera de una integral | `d\cdot x`: variables comunes |
| EN-CV-11 | N3 | `\mathrm{x}+1` | `x+1` |
| EN-CV-12 | N3 | `\overline{3+4i}` | ℂ: conjugado `3-4i` |
| EN-CV-13 | N2 | `f(x)=x^{2}+1` | Definición de la función `f` (no una ecuación para resolver) |
| EN-CV-14 | N2 | `f(2)` (tras CV-13) | `5` |
| EN-CV-15 | N2 | `g(x)=f(x)+1` y luego `g(2)` | `6` |
| EN-CV-16 | N2 | `h(t)=3t` y luego `h(2)` | `6` (variable `t`, nombre `h`) |
| EN-CV-17 | N3 | `f(2)` sin definir `f` | Símbolo `f(2)` o producto `2f` con eco; nunca un valor numérico inventado |
| EN-CV-18 | N2 | `f'(x)` (tras CV-13) | `2x` |
| EN-CV-19 | N3 | `\gamma+1` | Símbolo `\gamma` más 1 (no la función Gamma) |
| EN-CV-20 | N3 | `\Gamma(5)` | `24` |
| EN-CV-21 | N3 | `\beta+\zeta` | Dos símbolos (no funciones especiales sin argumento) |
| EN-CV-22 | N3 | `\Lambda+1` | Símbolo más 1 |
| EN-CV-23 | N3 | `\infty` | `\infty` (símbolo; operaciones con él, ver Partes de límites) |
| EN-CV-24 | N3 | `E+1`, `I+1`, `N+1`, `S+1`, `Q+1` | C12: variables simples (`N` y `S` no son funciones del motor) |

---

# PARTE D — NÚMEROS

## D1. Decimales y separadores

Ejecutar cada fila en **Modo `.`** y en **Modo `,`**. Regla de oro: una coma jamás se pierde en silencio (`3,5` nunca puede volverse `35`).

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-NM-01 | N1 | `3.5` | `3.5` |
| EN-NM-02 | N1 | `3,5` | Modo `.`: aviso o error claro con propuesta `3.5` (nunca `35`) · Modo `,`: `3.5` |
| EN-NM-03 | N1 | `.5` | `0.5` |
| EN-NM-04 | N2 | `,5` | Modo `,`: `0.5` · Modo `.`: aviso o error claro |
| EN-NM-05 | N2 | `5.` | `5` |
| EN-NM-06 | N2 | `-.5` | `-0.5` |
| EN-NM-07 | N2 | `0.50` | `0.5` |
| EN-NM-08 | N2 | `007` | `7` (sin octal) |
| EN-NM-09 | N2 | `3{,}5` | `3.5` en **ambos** modos (coma decimal explícita de LaTeX; es lo que emite MathLive) |
| EN-NM-10 | N2 | `1,234.56` | Modo `.`: `1234.56` (coma = miles) |
| EN-NM-11 | N2 | `1.234,56` | Modo `,`: `1234.56` (punto = miles) |
| EN-NM-12 | N2 | `1 234.56` y `1\,234.56` | `1234.56` (espacio o espacio fino de miles) |
| EN-NM-13 | N3 | `1,234` | Modo `.`: `1234` (miles) con eco · Modo `,`: `1.234` |
| EN-NM-14 | N3 | `1,23` | Modo `.`: aviso (no es agrupación de miles) · Modo `,`: `1.23` |
| EN-NM-15 | N3 | `1.234` | Modo `.`: `1.234` · Modo `,`: `1234` o aviso, con eco obligatorio |
| EN-NM-16 | N3 | `1,000,000` | Modo `.`: `1000000` |
| EN-NM-17 | N2 | `0,1+0,2` | Modo `,`: `0.3` exacto |
| EN-NM-18 | N2 | `\frac{1,5}{2}` | Modo `,`: `0.75` |
| EN-NM-19 | N2 | `2^{1,5}` | Modo `,`: `2^{1.5}\approx2.828427125` |
| EN-NM-20 | N2 | `x^{1,5}` | Modo `,`: `x^{1.5}` · Modo `.`: aviso o error claro |
| EN-NM-21 | N2 | `x=2,5` | Modo `,`: ecuación `x=2.5` |
| EN-NM-22 | N3 | `(1,5)` | Modo `.`: par ordenado o intervalo abierto `(1,5)` · Modo `,`: `1.5` entre paréntesis |
| EN-NM-23 | N2 | `1.2.3` | Error claro (dos puntos decimales) |
| EN-NM-24 | N2 | `3..5` | Error claro |
| EN-NM-25 | N2 | `1 000` | `1000` (grupo de tres dígitos tras espacio) |
| EN-NM-26 | N3 | `3 4` | Error claro ("¿falta un operador?"); nunca `34` |

## D2. Notación científica y porcentaje

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-CI-01 | N1 | `1.5\times10^{3}` | `1500` |
| EN-CI-02 | N1 | `1.5\cdot10^{3}` | `1500` |
| EN-CI-03 | N2 | `1.5\times10^{-3}` | `0.0015` |
| EN-CI-04 | N2 | `6.022\times10^{23}` | `602200000000000000000000` (exacto) |
| EN-CI-05 | N3 | `1.5e3` y `1.5E3` | C6: `1500` (no `1.5\cdot e\cdot3\approx12.2`) |
| EN-CI-06 | N3 | `2e3` | C6: `2000` |
| EN-CI-07 | N2 | `1e-3` y `1E+3` | `0.001` y `1000` |
| EN-CI-08 | N3 | `2\times10^{-3}\times3\times10^{2}` | `0.6` |
| EN-CI-09 | N3 | `1\times10^{400}` | `10^{400}` exacto (nunca `Infinity`) |
| EN-CI-10 | N3 | `1\times10^{-400}` | `10^{-400}` exacto (nunca `0`) |
| EN-PC-01 | N1 | `50\%` | `\frac{1}{2}` |
| EN-PC-02 | N1 | `15\%` | `0.15` |
| EN-PC-03 | N2 | `15%` (texto plano) | `0.15` |
| EN-PC-04 | N2 | `200\cdot15\%` | `30` |
| EN-PC-05 | N3 | `100+15\%` | C7: `100.15` (alternativa comercial `115`); el eco lo aclara |
| EN-PC-06 | N2 | `100\cdot\left(1+15\%\right)` | `115` |
| EN-PC-07 | N2 | `0.5\%` y `100\%` | `0.005` y `1` |
| EN-PC-08 | N2 | `x\%` | `\frac{x}{100}` |
| EN-PC-09 | N3 | `7%3` | Porcentaje por 3 (`0.21`) con aviso, o error claro; no módulo en silencio |

## D3. Precisión de la entrada numérica

El decimal tecleado debe entrar como **racional exacto**, no como `double`. Una calculadora de precisión no puede perder cifras al leer.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-PN-01 | N1 | `0.1+0.2` | `0.3` exacto (no `0.30000000000000004`) |
| EN-PN-02 | N1 | `0.1\cdot3` | `0.3` |
| EN-PN-03 | N2 | `4.35\cdot100` | `435` (en `double` da `434.99999999999994`) |
| EN-PN-04 | N2 | `1.005\cdot1000` | `1005` (en `double` da `1004.9999999999999`) |
| EN-PN-05 | N2 | `1.1^{2}` | `1.21` |
| EN-PN-06 | N2 | `0.3-0.1-0.2` | `0` exacto |
| EN-PN-07 | N2 | `1/3+1/3+1/3` | `1` exacto |
| EN-PN-08 | N2 | `9007199254740993` | `9007199254740993` (2⁵³+1; en `double` se redondea a `…992`) |
| EN-PN-09 | N2 | `9007199254740993+1` | `9007199254740994` |
| EN-PN-10 | N3 | `99999999999999999999+1` | `100000000000000000000` |
| EN-PN-11 | N3 | `123456789012345678901234567890` | El mismo entero, todas las cifras |
| EN-PN-12 | N3 | `0.1234567890123456789012345\cdot10^{25}` | `1234567890123456789012345` (no trunca a 17 cifras) |
| EN-PN-13 | N3 | `0.1+0.2=0.3` | Verdadero (igualdad exacta) |
| EN-PN-14 | N3 | `\sqrt{2}^{2}=2` | Verdadero |
| EN-PN-15 | N3 | `0.\overline{3}` | `\frac{1}{3}` (decimal periódico); si no se soporta, error claro |
| EN-PN-16 | N3 | `0.\overline{142857}` | `\frac{1}{7}` |
| EN-PN-17 | N3 | `0.1\overline{6}` | `\frac{1}{6}` |
| EN-PN-18 | N3 | `10^{400}\cdot10^{-400}` | `1` |
| EN-PN-19 | N3 | `2^{-1074}` | `\frac{1}{2^{1074}}` exacto (sin subdesbordamiento a `0`) |
| EN-PN-20 | N3 | `2^{1024}` | Entero exacto de 309 dígitos que empieza por `17976931348623159` (nunca `Infinity`) |

---

# PARTE E — NOTACIÓN DE CÁLCULO, ESTRUCTURAS E INTENCIÓN

Aquí se evalúa solo el **reconocimiento de la notación** (que `dx` sea un diferencial, que `i` sea un índice, que `\begin{cases}` sea un sistema). La corrección de los resultados la miden las otras matrices.

## E1. Integrales, derivadas, límites, sumatorias

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-CA-01 | N1 | `\int x^{2}\,dx` | `\frac{x^{3}}{3}+C` |
| EN-CA-02 | N1 | `\int x^{2}dx` | Igual (el `dx` es diferencial, no `d\cdot x`) |
| EN-CA-03 | N2 | `\int x^2 dx` | Igual (sin llaves ni espacio fino) |
| EN-CA-04 | N2 | `\int_{0}^{1}x^{2}\,dx` | `\frac{1}{3}` |
| EN-CA-05 | N2 | `\int_0^1 x^2\,dx` | `\frac{1}{3}` (límites sin llaves) |
| EN-CA-06 | N2 | `\int_{0}^{\pi}\sin x\,dx` | `2` |
| EN-CA-07 | N2 | `\int_0^\infty e^{-x}\,dx` | `1` |
| EN-CA-08 | N2 | `\int\frac{1}{x}\mathrm{d}x` | `\ln\lvert x\rvert+C` |
| EN-CA-09 | N2 | `\int\frac{1}{x}\differentialD x` | Igual (macro de MathLive) |
| EN-CA-10 | N2 | `\int t\,dt` | `\frac{t^{2}}{2}+C` (variable de integración `t`, detectada por `dt`) |
| EN-CA-11 | N3 | `\int_{0}^{1}\int_{0}^{1}xy\,dx\,dy` | `\frac{1}{4}` |
| EN-CA-12 | N2 | `\frac{d}{dx}x^{2}` | `2x` |
| EN-CA-13 | N2 | `\frac{d}{dx}\left(x^{2}\right)` | `2x` |
| EN-CA-14 | N2 | `\frac{d}{dx}\sin x` | `\cos x` |
| EN-CA-15 | N3 | `\frac{dy}{dx}` aislada | Notación de derivada de `y`; **no** se simplifica a `\frac{y}{x}` |
| EN-CA-16 | N3 | `\frac{d^{2}y}{dx^{2}}` | Segunda derivada de `y` respecto de `x` |
| EN-CA-17 | N2 | `y'`, `y''`, `y'''`, `y^{(4)}` | Derivadas de orden 1, 2, 3 y 4 |
| EN-CA-18 | N2 | `y^{\prime}` y `y^{\prime\prime}` | Orden 1 y 2 |
| EN-CA-19 | N2 | `\frac{\partial f}{\partial x}` y `\partial_{x}f` | Derivada parcial respecto de `x` |
| EN-CA-20 | N2 | `\lim_{x\to0}\frac{\sin x}{x}` | `1` |
| EN-CA-21 | N2 | `\lim_{x\rightarrow0}\frac{\sin x}{x}` | `1` |
| EN-CA-22 | N2 | `\lim_{x\to0^{+}}\frac{1}{x}` | `\infty` |
| EN-CA-23 | N2 | `\lim_{x\to0^-}\frac{1}{x}` | `-\infty` (signo sin llaves) |
| EN-CA-24 | N2 | `\lim_{x\to\infty}\frac{1}{x}` | `0` |
| EN-CA-25 | N2 | `\displaystyle\lim_{x\to0}\frac{\sin x}{x}` | `1` |
| EN-CA-26 | N2 | `\sum_{k=1}^{10}k` | `55` |
| EN-CA-27 | N2 | `\sum_{k=1}^{n}k` | `\frac{n(n+1)}{2}` |
| EN-CA-28 | N2 | `\sum_{k=1}^{10}k^{2}` | `385` |
| EN-CA-29 | N2 | `\sum_{k=0}^{\infty}\frac{1}{2^{k}}` | `2` |
| EN-CA-30 | N2 | `\prod_{k=1}^{5}k` | `120` |
| EN-CA-31 | N3 | `\left.\frac{x^{3}}{3}\right\|_{0}^{2}` | `\frac{8}{3}` (evaluación entre límites) |
| EN-CA-32 | N3 | `\sum_{k=1}^{10^{9}}k` | `500000000500000000` en forma cerrada (no itera mil millones de veces) |

## E2. Matrices, vectores, sistemas y trozos

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-MT-01 | N2 | `\begin{pmatrix}1&2\\3&4\end{pmatrix}` | Matriz `2\times2` |
| EN-MT-02 | N2 | `\begin{bmatrix}1&2\\3&4\end{bmatrix}` | Igual que EN-MT-01 |
| EN-MT-03 | N2 | `\begin{vmatrix}1&2\\3&4\end{vmatrix}` | Determinante `=-2` |
| EN-MT-04 | N2 | `\det\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `-2` |
| EN-MT-05 | N2 | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{-1}` | Matriz inversa `\begin{pmatrix}-2&1\\\frac{3}{2}&-\frac{1}{2}\end{pmatrix}` |
| EN-MT-06 | N2 | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{2}` | Producto matricial `\begin{pmatrix}7&10\\15&22\end{pmatrix}` (no elevar elemento a elemento) |
| EN-MT-07 | N2 | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{T}` | Transpuesta `\begin{pmatrix}1&3\\2&4\end{pmatrix}` (`T` no es un exponente variable) |
| EN-MT-08 | N2 | `\begin{pmatrix}1&2\\3&4\end{pmatrix}\begin{pmatrix}1\\1\end{pmatrix}` | `\begin{pmatrix}3\\7\end{pmatrix}` |
| EN-MT-09 | N2 | `\begin{pmatrix}1\\2\\3\end{pmatrix}` | Vector columna `3\times1` |
| EN-MT-10 | N3 | `\begin{pmatrix}1&2\\3\end{pmatrix}` | Error claro (filas de distinta longitud) |
| EN-MT-11 | N2 | `\begin{cases}x+y=3\\x-y=1\end{cases}` | Sistema de 2 ecuaciones; solución `(x,y)=(2,1)` |
| EN-MT-12 | N2 | `\begin{aligned}x+y&=3\\x-y&=1\end{aligned}` | El mismo sistema (el `&` de alineación se ignora) |
| EN-MT-13 | N2 | `\begin{array}{l}x+y=3\\x-y=1\end{array}` | El mismo sistema |
| EN-MT-14 | N3 | `\begin{cases}x^{2}&x<0\\x&x\geq0\end{cases}` | Función a trozos; vale `4` en `x=-2` y `3` en `x=3` |

## E3. Detección de intención por sintaxis

La app enruta cada entrada a un motor (expresión, ecuación, sistema, inecuación, cálculo, EDO). Un error de enrutamiento es un error de sintaxis disfrazado: la respuesta puede ser perfecta y de otra pregunta.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-DI-01 | N1 | `x^{2}-4` | Expresión (simplificar/factorizar), no ecuación |
| EN-DI-02 | N1 | `x^{2}-4=0` | Ecuación; `x=\pm2` |
| EN-DI-03 | N1 | `x^{2}=4` | Ecuación; `x=\pm2` |
| EN-DI-04 | N2 | `x^{2}>4` | Inecuación; `(-\infty,-2)\cup(2,\infty)` |
| EN-DI-05 | N2 | `\lvert x-1\rvert\leq2` | Inecuación; `[-1,3]` |
| EN-DI-06 | N3 | `3<x<7` y `3\le x\le7` | Inecuación doble; `(3,7)` y `[3,7]` |
| EN-DI-07 | N2 | `x+y=3\\x-y=1` | Sistema; `(2,1)` |
| EN-DI-08 | N2 | `x+y=3,\ x-y=1` | Sistema; `(2,1)` |
| EN-DI-09 | N2 | `x+y=3;\ x-y=1` | Sistema; `(2,1)` |
| EN-DI-10 | N3 | `x+y=3\text{ y }x-y=1` | Sistema; `(2,1)` (la palabra "y" separa) |
| EN-DI-11 | N2 | Dos líneas pegadas: `x+y=3` ⏎ `x-y=1` | Sistema; `(2,1)` (cada línea es una ecuación) |
| EN-DI-12 | N2 | `y'=y` | EDO de primer orden; `y=Ce^{x}` |
| EN-DI-13 | N2 | `y''+y=0` | EDO de segundo orden; `y=C_{1}\cos x+C_{2}\sin x` |
| EN-DI-14 | N2 | `\frac{dy}{dx}=y` | EDO; igual que EN-DI-12 |
| EN-DI-15 | N2 | `f(x)=x^{2}-4` | Definición de función (no se resuelve para `x`) |
| EN-DI-16 | N2 | `y=x^{2}-4` | Relación `y=f(x)`: ofrecer graficar o despejar; no "resolver" en silencio |
| EN-DI-17 | N3 | `x^{2}+y^{2}=1` | Ecuación implícita (graficable); no se resuelve para ambas variables |
| EN-DI-18 | N2 | `x=3` | Ecuación trivial con solución `\{3\}`; no asigna un valor global (ver EN-SG-17) |
| EN-DI-19 | N2 | `1=1` y `2=3` | Verdadero y falso |
| EN-DI-20 | N2 | `x=x` y `x+1=x` | Identidad (todo ℝ) y sin solución |
| EN-DI-21 | N3 | `\sin^{2}x+\cos^{2}x=1` | Identidad verdadera para todo `x`; no "soluciones" numéricas arbitrarias |
| EN-DI-22 | N3 | `x^{2}-4=0,\ x>0` | Ecuación con restricción; `x=2` |
| EN-DI-23 | N2 | `\left(x+1\right)^{2}=x^{2}+2x+1` | Identidad verdadera |

---

# PARTE F — TEXTO PEGADO

## F1. Contenedores, espacios y ruido de LaTeX (canal `L`/`T`)

Lo que llega al copiar de un PDF, de Wikipedia, de un chat o de un documento.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-PG-01 | N1 | `$x^{2}+1$` | `x^{2}+1` (se descartan los `$`) |
| EN-PG-02 | N1 | `$$x^{2}+1$$` | Igual |
| EN-PG-03 | N1 | `\(x^{2}+1\)` | Igual |
| EN-PG-04 | N1 | `\[x^{2}+1\]` | Igual |
| EN-PG-05 | N2 | `\begin{equation}x^{2}+1\end{equation}` | Igual (también `equation*`, `align`, `align*`) |
| EN-PG-06 | N2 | `{\displaystyle x^{2}+1}` | Igual (formato de Wikipedia) |
| EN-PG-07 | N2 | `\displaystyle\frac{1}{2}` | `\frac{1}{2}` (también `\textstyle`, `\scriptstyle`) |
| EN-PG-08 | N2 | `x^{2}\,+\,1` | `x^{2}+1` (también `\;`, `\:`, `\!`, `\ `, `~`, `\quad`, `\qquad`) |
| EN-PG-09 | N2 | `x^{2}+1 \,` | `x^{2}+1` (espacio fino sobrante al final) |
| EN-PG-10 | N2 | `x^{2}+1.` | `x^{2}+1` (punto de oración al final, con aviso) o error claro |
| EN-PG-11 | N2 | `x^{2}+1,` | `x^{2}+1` (coma final, con aviso) o error claro |
| EN-PG-12 | N2 | `x^{2}+1` seguido de salto de línea | `x^{2}+1` (salto final ignorado) |
| EN-PG-13 | N3 | `x+1\\` | `x+1` (`\\` final ignorado) |
| EN-PG-14 | N3 | `x^{2}+1\tag{1}` y `x^{2}+1\label{eq:1}` | `x^{2}+1` (se ignoran el número y la etiqueta de la ecuación) |
| EN-PG-15 | N3 | `x^{2}+1\quad\text{(ver ejercicio 3)}` | `x^{2}+1` con aviso, o error claro; nunca incluir el texto como variables |

## F2. Unicode

Canal `T`. Los caracteres Unicode deben **normalizarse** a su equivalente matemático o rechazarse nombrando el carácter y su posición.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-UC-01 | N1 | `x²`, `x³` | `x^{2}`, `x^{3}` |
| EN-UC-02 | N2 | `x¹⁰` | `x^{10}` (superíndices Unicode de varios dígitos) |
| EN-UC-03 | N2 | `10⁻³` y `x⁻¹` | `0.001` y `\frac{1}{x}` |
| EN-UC-04 | N2 | `x₁` y `x₁₀` | `x_{1}` y `x_{10}` |
| EN-UC-05 | N1 | `√4` y `√(x+1)` | `2` y `\sqrt{x+1}` |
| EN-UC-06 | N2 | `√x+1` | `\left(\sqrt{x}\right)+1` |
| EN-UC-07 | N2 | `∛8` y `∜16` | `2` y `2` |
| EN-UC-08 | N1 | `2×3` y `6÷3` | `6` y `2` |
| EN-UC-09 | N1 | `2·3`, `2⋅3`, `2∙3`, `2∗3` | `6` (punto medio, operador punto, bullet, asterisco) |
| EN-UC-10 | N1 | `5−3` (U+2212) | `2` |
| EN-UC-11 | N2 | `5–3` (U+2013), `5—3` (U+2014), `5‐3` (U+2010), `5‑3` (U+2011) | `2` (guiones y rayas tratados como resta) |
| EN-UC-12 | N1 | `−5` (U+2212 unario) | `-5` |
| EN-UC-13 | N2 | `½`, `¼`, `¾` | `0.5`, `0.25`, `0.75` |
| EN-UC-14 | N1 | `π`, `θ`, `∞` | `\pi`, `\theta`, `\infty` |
| EN-UC-15 | N2 | `x≤3`, `x≥3`, `x≠3` | `x\le3`, `x\ge3`, `x\ne3` |
| EN-UC-16 | N2 | `5±2` | `7` y `3` |
| EN-UC-17 | N2 | `30°` y `sin 30°` | `\frac{\pi}{6}` y `\frac{1}{2}` (en RAD y en DEG) |
| EN-UC-18 | N2 | `f’(x)` (U+2019) y `f′(x)` (U+2032) | `f'(x)` |
| EN-UC-19 | N2 | `2 + 3` con espacios de no separación (U+00A0, U+2009, U+202F) | `5` |
| EN-UC-20 | N3 | `x^{2}` con U+200B, U+FEFF o U+00AD intercalados | `x^{2}` (invisibles ignorados) o error claro que los nombre |
| EN-UC-21 | N3 | `х+1` con la `х` cirílica (U+0445) | Aviso de carácter cirílico o normalización a `x`; nunca una variable distinta sin avisar |
| EN-UC-22 | N3 | `𝑓(𝑥)=𝑥²` (letras matemáticas U+1D453, U+1D465) | `f(x)=x^{2}` (formato de PDF/Word/MathML) |
| EN-UC-23 | N3 | `（x＋1）²` y `１２３` (ancho completo) | `(x+1)^{2}` y `123` |
| EN-UC-24 | N3 | `ⅇ^x` (U+2147) y `ⅈ` (U+2148) | `e^{x}` e `i` (ecuaciones de Word) |
| EN-UC-25 | N3 | `∫₀¹x²dx` | `\frac{1}{3}` |
| EN-UC-26 | N2 | `x+1😀` o `x+漢` | Error claro que nombre el carácter inesperado |

## F3. Otras sintaxis (ASCII, Excel, SymPy, Wolfram, Python)

Canal `T`. Para la entrada "de otro programa" se acepta el valor esperado **o** un error claro; lo inaceptable es leerla distinto.

| ID | Nivel | Entrada | Interpretación esperada |
|---|---|---|---|
| EN-AS-01 | N1 | `x^2+1` | `x^{2}+1` |
| EN-AS-02 | N1 | `x**2+1` | `x^{2}+1` (estilo Python) |
| EN-AS-03 | N1 | `sqrt(16)` | `4` |
| EN-AS-04 | N1 | `2^(10)` y `2^(-1)` | `1024` y `\frac{1}{2}` |
| EN-AS-05 | N2 | `x^(1/2)` | `\sqrt{x}` |
| EN-AS-06 | N2 | `e^(-x^2)` | `e^{-(x^{2})}` |
| EN-AS-07 | N2 | `pi`, `inf`, `oo`, `infinity` | `\pi`, `\infty`, `\infty`, `\infty` |
| EN-AS-08 | N2 | `ln(1)` y `log(100)` | `0` y `2` (C2) |
| EN-AS-09 | N2 | `log(100,10)`, `log(8,2)` | `2` y `3` (base como segundo argumento) |
| EN-AS-10 | N2 | `log10(1000)` y `log2(8)` | `3` y `3` |
| EN-AS-11 | N3 | `Sin[x]^2` y `Sqrt[16]` (Wolfram) | `(\sin x)^{2}` y `4`, o error claro |
| EN-AS-12 | N3 | `Log[E]` (Wolfram) | `1` (en Wolfram `Log` es natural), o error claro |
| EN-AS-13 | N3 | `math.sqrt(16)` y `math.pi` | `4` y `\pi`, o error claro; **sin ejecutar nada** |
| EN-AS-14 | N3 | `np.sin(x)` | `\sin x`, o error claro |
| EN-AS-15 | N2 | `=2^10` (Excel) | `1024` (el `=` inicial se ignora) |
| EN-AS-16 | N3 | `RAIZ(16)+SENO(PI()/6)` (Excel en español) | `4.5`, o error claro |
| EN-AS-17 | N3 | `POTENCIA(2,10)` y `LN(EXP(1))` | `1024` y `1`, o error claro |
| EN-AS-18 | N2 | `x^{2} + 2 x + 1` (salida de `sympy.latex`) | `x^{2}+2x+1` (el espacio entre `2` y `x` es producto) |
| EN-AS-19 | N2 | `\sin{\left(x \right)}` | `\sin x` |
| EN-AS-20 | N2 | `\operatorname{asin}{\left(x \right)}`, `\operatorname{atan}`, `\operatorname{acos}` | `\arcsin x`, `\arctan x`, `\arccos x` |
| EN-AS-21 | N3 | `x!=3` | C13: aviso o `x\ne3`; **no** `(x!)=3` en silencio |
| EN-AS-22 | N2 | `x<=3`, `x>=3` | `x\le3`, `x\ge3` |
| EN-AS-23 | N2 | `x<>3` | `x\ne3` |
| EN-AS-24 | N2 | `x==3` | `x=3` |
| EN-AS-25 | N3 | `lim(x->0, sin(x)/x)` | `1`, o error claro |
| EN-AS-26 | N3 | `\log{\left(x \right)}` (salida de SymPy, donde `log` es natural) | C2: `\log_{10}x`, **con aviso** de que SymPy usa `\log` como natural; el eco debe mostrar la lectura |

---

# PARTE G — TECLADO, CANALES E ENTRADAS INVÁLIDAS

## G1. Teclado y campo de entrada (canal `⌨`)

Las filas describen **teclas pulsadas en orden** (cada símbolo entre comillas invertidas es una pulsación) y lo que debe quedar en el campo. Si el campo es un `<math-field>` de MathLive, revisar en especial sus opciones de autoformato (`smartSuperscript`, `smartFence`, `inlineShortcuts`, `decimalSeparator`, `removeExtraneousParentheses`): `smartSuperscript` hace que el cursor salga del exponente tras el primer dígito, lo que favorece `x^2+1` pero rompe `2^10`. La regla ideal es "permanecer en el exponente mientras se escriben dígitos y salir al primer operador".

| ID | Nivel | Pulsaciones | Resultado esperado |
|---|---|---|---|
| EN-TC-01 | N1 | `2` `^` `1` `0` | `2^{10}=1024`: los dos dígitos quedan en el exponente |
| EN-TC-02 | N1 | `x` `^` `2` `+` `1` | `x^{2}+1`: el `+` sale del exponente |
| EN-TC-03 | N2 | `x` `^` `1` `0` `+` `1` | `x^{10}+1` |
| EN-TC-04 | N2 | `2` `^` `-` `3` `+` `1` | `2^{-3}+1=1.125` |
| EN-TC-05 | N2 | `x` `^` `2` `y` | `x^{2}y` (la `y` fuera del exponente) |
| EN-TC-06 | N2 | `e` `^` `x` `+` `1` | Regla documentada; el cursor o la caja del exponente muestra dónde se escribe; el valor coincide con el eco (`e^{x}+1` o `e^{x+1}`) |
| EN-TC-07 | N2 | `x` `/` `2` | `\frac{x}{2}` |
| EN-TC-08 | N2 | `x` `+` `1` `/` `2` | `x+\frac{1}{2}` o `\frac{x+1}{2}`; regla documentada; el valor coincide con el eco |
| EN-TC-09 | N3 | `1` `/` `2` `x` | El eco muestra `\frac{1}{2x}` (la `x` entra al denominador); el valor coincide con el eco (ver C1) |
| EN-TC-10 | N2 | `1` `/` `2` `→` `x` | `\frac{1}{2}x=\frac{x}{2}` |
| EN-TC-11 | N2 | `sin`, `sen`, `tg`, `arcsen`, `senh` (una por vez) | Letra recta; función reconocida; `sen(pi/6)=\frac{1}{2}` |
| EN-TC-12 | N2 | `pi`, `theta`, `->`, `<=`, `>=`, `!=`, `*` (una por vez) | `\pi`, `\theta`, `\to`, `\le`, `\ge`, `\ne`, `\cdot` |
| EN-TC-13 | N2 | `sqrt` `x` `+` `1` | `\sqrt{x+1}`: el cursor entra al radicando |
| EN-TC-14 | N2 | `(` `x` `+` `1` `)` `^` `2` | `(x+1)^{2}` con **un** solo par de paréntesis, sin `()` vacíos sobrantes |
| EN-TC-15 | N2 | `\|` `x` `-` `1` `\|` | `\lvert x-1\rvert`; anidado `\|\|x\|-1\|` conserva la estructura |
| EN-TC-16 | N2 | Teclas `.` y `,` en cada modo | Modo `.`: `.` es decimal, `,` avisa · Modo `,`: `,` produce `3{,}5` y `.` avisa o separa miles |
| EN-TC-17 | N2 | Teclado numérico del teléfono (tecla decimal) | La app acepta la tecla que envía el sistema (`,` o `.`) sin pedir cambiar nada, o indica qué modo está activo |
| EN-TC-18 | N2 | Botones virtuales `x²`, `xʸ`, `√`, fracción | `^{2}`, `^{□}` con el cursor en el exponente, raíz, fracción; con `x+1` seleccionado, fracción da `\frac{x+1}{□}` |
| EN-TC-19 | N2 | Botones `sin⁻¹`, `log`, `ln`, `10^x`, `e^x` | `\arcsin` (o `\sin^{-1}`), `\log` base 10, `\ln`, `10^{□}`, `e^{□}` (C2, C3) |
| EN-TC-20 | N2 | En `2^{10}` pulsar retroceso dos veces | `2^{□}` → al evaluar, error claro "exponente vacío"; sin `NaN` |
| EN-TC-21 | N2 | Deshacer/rehacer, seleccionar todo y borrar, copiar y pegar dentro del campo | Se restaura la fórmula exacta |
| EN-TC-22 | N2 | Flechas y Tab entre numerador, denominador, exponente y subíndice; Enter | La navegación recorre todas las posiciones; Enter evalúa sin insertar saltos de línea |
| EN-TC-23 | N3 | Teclado español físico: `x` `^` `2` | `x^{2}` (la `^` es tecla muerta: sin `^` duplicada ni `â`); `\`, `{`, `}`, `\|`, `~` tienen botón o atajo alternativo |
| EN-TC-24 | N3 | Teclado del teléfono con autocorrección | `sin` no pasa a `Sin`, `x` no pasa a `X`, `pi` no pasa a `Pi` (`autocapitalize="off"`, `autocorrect="off"`, `spellcheck="false"`) |
| EN-TC-25 | N3 | Pegar con Ctrl+V un LaTeX en texto plano, y contenido HTML/MathML de Word o Wikipedia | El LaTeX entra como fórmula; el HTML se convierte o cae a texto plano; nunca se inserta HTML |
| EN-TC-26 | N2 | Evaluar `\frac{□}{2}` y `\sqrt{□}` con marcadores vacíos | Error claro que resalta el marcador; sin `NaN` |
| EN-TC-27 | N3 | Escribir `raíz(x)` con tilde (tecla muerta o composición) | `raíz` reconocida como función |

## G2. Invariancia entre canales

Cada fila debe producir **el mismo resultado** por `L`, `T` y `⌨`. Cualquier diferencia es S5.

| ID | Nivel | `L` (LaTeX) | `T` (texto) | `⌨` (pulsaciones) | Interpretación única esperada |
|---|---|---|---|---|---|
| EN-CH-01 | N1 | `2^{10}` | `2^10` | `2` `^` `1` `0` | `1024` |
| EN-CH-02 | N1 | `x^{2}+1` | `x^2+1` | `x` `^` `2` `+` `1` | `x^{2}+1` |
| EN-CH-03 | N3 | `x^{10}+1` | `x^10+1` | `x` `^` `1` `0` `+` `1` | `x^{10}+1` |
| EN-CH-04 | N2 | `\frac{x+1}{x-1}` | `(x+1)/(x-1)` | `(x+1)` `/` `(x-1)` | `\frac{x+1}{x-1}` |
| EN-CH-05 | N2 | `\sqrt{x+1}` | `sqrt(x+1)` | `sqrt` `x+1` | `\sqrt{x+1}` |
| EN-CH-06 | N2 | `\sin^{2}x` | `sin^2(x)` | `sin` `^` `2` `x` | `(\sin x)^{2}` |
| EN-CH-07 | N2 | `\sin^{-1}x` | `sin^-1(x)` | `sin` `^` `-` `1` `x` | `\arcsin x` |
| EN-CH-08 | N1 | `2x` | `2x` | `2` `x` | `2\cdot x` |
| EN-CH-09 | N2 | `\frac{1}{2}x` | `(1/2)x` | `1` `/` `2` `→` `x` | `\frac{x}{2}` |
| EN-CH-10 | N1 | `3.5+1` | `3.5+1` | `3` `.` `5` `+` `1` | `4.5` (Modo `.`) |
| EN-CH-11 | N2 | `3{,}5+1` | `3,5+1` | `3` `,` `5` `+` `1` | `4.5` (Modo `,`) |
| EN-CH-12 | N2 | `\lvert x-1\rvert` | `abs(x-1)` | `\|` `x-1` `\|` | `\lvert x-1\rvert` |
| EN-CH-13 | N2 | `\pi r^{2}` | `pi r^2` | `pi` `r` `^` `2` | `\pi r^{2}` |
| EN-CH-14 | N3 | `e^{-x^{2}}` | `e^(-x^2)` | `e` `^` `-` `x` `^` `2` | `e^{-(x^{2})}` |
| EN-CH-15 | N2 | `\operatorname{sen}\left(\frac{\pi}{6}\right)` | `sen(pi/6)` | `sen` `(` `pi` `/` `6` `)` | `\frac{1}{2}` |

## G3. Entradas inválidas y mensajes de error

Todas deben terminar en **error claro** (convención del encabezado), nunca en resultado, `NaN`, pantalla en blanco, ni `500`. Verificar además que el mensaje señale la posición.

| ID | Nivel | Entrada | Error esperado |
|---|---|---|---|
| EN-ER-01 | N1 | `(2+3` | Paréntesis sin cerrar |
| EN-ER-02 | N1 | `2+3)` | Paréntesis de cierre sobrante |
| EN-ER-03 | N1 | `\frac{1}{` | Fracción incompleta |
| EN-ER-04 | N1 | `\frac{1}` | Falta el denominador |
| EN-ER-05 | N1 | `2^` | Exponente vacío |
| EN-ER-06 | N1 | `^2` | Exponente sin base |
| EN-ER-07 | N1 | `2+` | Operador sin segundo operando |
| EN-ER-08 | N1 | `*3` | Operador sin primer operando |
| EN-ER-09 | N1 | `2*/3` | Dos operadores seguidos |
| EN-ER-10 | N1 | Campo vacío | Indicación "escriba una expresión"; no se evalúa |
| EN-ER-11 | N1 | Solo espacios | Igual que EN-ER-10 |
| EN-ER-12 | N1 | `()` | Paréntesis vacíos |
| EN-ER-13 | N2 | `\sin` | Falta el argumento de `\sin` |
| EN-ER-14 | N2 | `\sin()` | Falta el argumento de `\sin` |
| EN-ER-15 | N2 | `\foo{x}` | Comando desconocido `\foo` (lo nombra) |
| EN-ER-16 | N2 | `\left(x+1\right]` | Delimitadores distintos en una expresión (válidos solo como intervalo) |
| EN-ER-17 | N2 | `\left(x+1` | Falta `\right` |
| EN-ER-18 | N2 | `x+1\right)` | `\right` sin `\left` |
| EN-ER-19 | N2 | `{x+1` | Llave sin cerrar |
| EN-ER-20 | N2 | `x+1}` | Llave de cierre sobrante |
| EN-ER-21 | N1 | `1/0` | División entre cero |
| EN-ER-22 | N1 | `0/0` | Forma indeterminada |
| EN-ER-23 | N2 | `\frac{1}{0}` | División entre cero |
| EN-ER-24 | N3 | `0^{0}` | C11: `1` o indefinida, **declarado** en el mensaje o en la ayuda |
| EN-ER-25 | N2 | `x=` | Ecuación incompleta |
| EN-ER-26 | N2 | `=3` | Ecuación incompleta |
| EN-ER-27 | N2 | `x^{}` | Exponente vacío |
| EN-ER-28 | N2 | `\frac{}{2}` | Numerador vacío |
| EN-ER-29 | N2 | `\sqrt{}` | Radicando vacío |
| EN-ER-30 | N2 | `\placeholder{}` | Entrada incompleta (marcador sin llenar) |
| EN-ER-31 | N2 | `\text{hola}` | Texto no matemático |
| EN-ER-32 | N3 | `hola mundo` | Error claro, o producto simbólico de variables mostrado en el eco con aviso; nunca `500` |
| EN-ER-33 | N2 | `x++` | Operador sin segundo operando (no es incremento) |
| EN-ER-34 | N3 | Párrafo pegado: `Resolver $x^2=4$ en los reales` | Error claro, o extracción de `x^{2}=4` con aviso; nunca variables inventadas a partir de las palabras |

---

# PARTE H — REINGRESO, SEGURIDAD Y LÍMITES

## H.1 La salida como entrada (canal `R`)

**Procedimiento por fila:** (1) evaluar la entrada → salida `S1`; (2) copiar `S1` (botón de copiar LaTeX o selección + Ctrl+C); (3) pegarla en el campo y evaluar → `S2`. **Pasa** si `S2` entra sin error, equivale matemáticamente a `S1` y es igual a `S1` (punto fijo). Una salida que no puede volver a entrar es un bug de entrada.

| ID | Nivel | Entrada inicial | Salida esperada y condición de reingreso |
|---|---|---|---|
| EN-RE-01 | N1 | `\frac{1}{2}+\frac{1}{3}` | `\frac{5}{6}`; reingresa y devuelve `\frac{5}{6}` |
| EN-RE-02 | N1 | `2^{10}` | `1024`; reingresa y devuelve `1024` |
| EN-RE-03 | N2 | `\sqrt{8}` | `2\sqrt{2}`; reingresa (producto implícito con radical) y devuelve igual |
| EN-RE-04 | N2 | `\sin^{2}x+\cos^{2}x` | `1` |
| EN-RE-05 | N2 | `\arcsin\left(\frac{1}{2}\right)` | `\frac{\pi}{6}`; reingresa y devuelve igual |
| EN-RE-06 | N2 | `\frac{d}{dx}\left(x\ln x-x\right)` | `\ln x`: la salida usa `\ln`, **no** `\log` (con C2, `\log` reingresado cambiaría el valor) |
| EN-RE-07 | N2 | `e^{x}` (resultado o parte de él) | `e^{x}`; al reingresar, `e` sigue siendo la constante, no una variable |
| EN-RE-08 | N2 | `\sqrt{-4}` en ℂ | `2i`; reingresa y devuelve `2i` (`i` es la unidad imaginaria) |
| EN-RE-09 | N2 | `\int\frac{1}{x}\,dx` | `\ln\lvert x\rvert+C`; reingresa (el `\lvert\rvert` y la `C` entran) y su derivada devuelve `\frac{1}{x}` |
| EN-RE-10 | N2 | `x^{2}=4` | Solución `x=-2` y `x=2` (o `x\in\{-2,2\}`); la solución, pegada como entrada, entra sin error |
| EN-RE-11 | N2 | `x+y=3,\ x-y=1` | Solución `x=2,\ y=1`; pegada como entrada, entra como sistema |
| EN-RE-12 | N2 | `x^{2}>4` | `\left(-\infty,-2\right)\cup\left(2,\infty\right)`; el intervalo con `\cup` e `\infty` reingresa |
| EN-RE-13 | N2 | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{-1}` | `\begin{pmatrix}-2&1\\\frac{3}{2}&-\frac{1}{2}\end{pmatrix}`; reingresa y devuelve igual |
| EN-RE-14 | N2 | `\frac{1}{3}` con aproximación | Pegar `\approx0.333333333` (con el `\approx`): se ignora el símbolo o error claro; el decimal entra como decimal exacto, no como `\frac{1}{3}` |
| EN-RE-15 | N2 | `2^{100}` aproximado | `1.267650600\times10^{30}`; reingresa (CI-01) |
| EN-RE-16 | N2 | Número grande formateado con espacio fino | `1\,234\,567`; reingresa como `1234567` (NM-12) |
| EN-RE-17 | N2 | `0.5` en Modo `,` | `0{,}5`; reingresa en Modo `,` **y** en Modo `.` como `0.5` (NM-09) |
| EN-RE-18 | N2 | `\sin\frac{\pi}{6}` con interfaz en español | Si la salida usa `\operatorname{sen}` o `\operatorname{tg}`, reingresa (AL-01, AL-10) |
| EN-RE-19 | N2 | `(x+1)^{3}` expandido | `x^{3}+3x^{2}+3x+1`; reingresa y devuelve igual |
| EN-RE-20 | N2 | Copiar como texto plano `x^2+2*x+1` y `sqrt(2)/2` | Reingresan (ASCII, sin Unicode raro) |
| EN-RE-21 | N2 | `2+3` y luego `Ans\cdot2` | `10`, si existe `Ans`; sin resultado previo, error claro |
| EN-RE-22 | N2 | Clic en una entrada del historial | El campo recupera el LaTeX **idéntico** (sin `\left(` ni espacios añadidos) |
| EN-RE-23 | N2 | Salida con constantes `C` o `C_{1}` | Al reingresar, `C` es una variable común, no una constante especial |
| EN-RE-24 | N3 | 20 entradas de Partes A–E | Idempotencia triple: `S1=S2=S3`; sin acumular `\left(\left(`, `1\cdot`, `+0` |
| EN-RE-25 | N3 | Las mismas 20 | Equivalencia: `S1-\text{entrada}` simplifica a `0`, o `\lvert\Delta\rvert<10^{-9}` en 5 puntos de prueba |
| EN-RE-26 | N3 | Salida de Lite pegada en Plus, y de Plus pegada en Lite | Misma interpretación y mismo valor en ambos |
| EN-RE-27 | N3 | Salida de Plus con `\operatorname{asin}`, `\operatorname{atan}` | Reingresa (AS-20) |
| EN-RE-28 | N3 | Función a trozos `\begin{cases}x^{2}&x<0\\x&x\geq0\end{cases}` | Salida con `\begin{cases}`; reingresa y vale `4` en `x=-2` |
| EN-RE-29 | N3 | Enlace para compartir con `x^{2}+1\ \&\ 5\%` en la URL | Sobreviven `+`, `%`, `&`, `#`, `\`, `{`, `}` al codificar y decodificar (si existe la función) |
| EN-RE-30 | N3 | Recargar la página con `√2+π` en el campo | Se conserva la entrada, incluido Unicode (si existe persistencia) |

## H.2 Seguridad y límites

Nada de lo siguiente debe ejecutar código, abrir archivos, insertar HTML, bloquear la interfaz ni dejar el servidor sin responder. Este bloque es el que se prueba **antes de publicar** un cambio de entrada.

| ID | Nivel | Entrada | Resultado esperado |
|---|---|---|---|
| EN-SG-01 | N1 | `<script>alert(1)</script>` | Entrada inválida; el mensaje de error muestra el texto **escapado**; no se ejecuta |
| EN-SG-02 | N1 | `<img src=x onerror=alert(1)>` | Igual |
| EN-SG-03 | N2 | `x^{2}\text{<b>hola</b>}` | Se muestra como texto literal, sin negrita ni etiquetas |
| EN-SG-04 | N2 | `\href{javascript:alert(1)}{x}` | Sin enlace ejecutable; error claro o texto plano (renderizador con `trust` desactivado) |
| EN-SG-05 | N2 | `\url{http://example.com}`, `\includegraphics{x.png}`, `\htmlClass{a}{x}`, `\htmlStyle{color:red}{x}` | Bloqueados con error claro |
| EN-SG-06 | N2 | `\def\a{\a}\a` | Recursión de macros cortada con error claro; el navegador no se congela |
| EN-SG-07 | N2 | `\newcommand{\a}{\a}\a`, `\let\a\b`, `\catcode` | Bloqueados con error claro |
| EN-SG-08 | N2 | `\input{/etc/passwd}`, `\include{x}`, `\write18{ls}`, `\openin1=x` | No soportados; no se lee ningún archivo; error claro |
| EN-SG-09 | N3 | `__import__('os').system('ls')` | Rechazado **sin evaluar**; el servidor de Plus no pasa texto crudo a `sympify`/`eval` |
| EN-SG-10 | N3 | `open('/etc/passwd').read()` | Rechazado sin evaluar |
| EN-SG-11 | N3 | `().__class__.__bases__[0].__subclasses__()` | Rechazado sin evaluar |
| EN-SG-12 | N3 | `(lambda x: x)(1)` | Rechazado sin evaluar |
| EN-SG-13 | N3 | `exec("print(1)")` y `eval("1+1")` | Rechazados sin evaluar |
| EN-SG-14 | N3 | `import os` y `os.system("ls")` | Rechazados sin evaluar |
| EN-SG-15 | N3 | `x.__class__` y `x.__dict__` | Rechazados (atributos con guion bajo doble) |
| EN-SG-16 | N3 | `Symbol('x')`, `Integer(2)`, `Function('f')` | Rechazados o tratados como texto; no se exponen los constructores del motor |
| EN-SG-17 | N2 | `a=7` y luego `a+1` | `a+1` simbólico: la asignación **no** persiste entre cálculos (estado compartido entre llamadas) |
| EN-SG-18 | N3 | Palabras reservadas del motor, una por vez: `clearall`, `draw`, `run`, `last`, `lambda`, `S`, `N` | Tratadas como variables o error claro; nunca ejecutan una orden del motor ni alteran su estado |
| EN-SG-19 | N2 | 50 paréntesis anidados alrededor de `1` | `1` |
| EN-SG-20 | N3 | 1000 paréntesis anidados alrededor de `1` | Error claro de profundidad; sin `RangeError`, `RecursionError` ni `500` |
| EN-SG-21 | N3 | `1+1+…+1` con 10 000 términos | `10000` en tiempo razonable (< 2 s) |
| EN-SG-22 | N3 | Expresión de ~100 000 caracteres | Procesa sin congelar la interfaz, o rechazo claro por longitud |
| EN-SG-23 | N3 | `10^{10^{10}}` | Se mantiene simbólico o error claro de tamaño; nunca bloqueo |
| EN-SG-24 | N3 | `9^{9^{9}}` | Igual (≈ 370 millones de dígitos) |
| EN-SG-25 | N3 | `1000000!` | Límite o tiempo agotado con mensaje claro y opción de cancelar |
| EN-SG-26 | N3 | `(x+1)^{10000}` expandido | Límite o tiempo agotado con mensaje claro |
| EN-SG-27 | N3 | `2^{2^{2^{2^{2}}}}` | `2^{65536}` (19 729 dígitos) o límite claro |
| EN-SG-28 | N3 | Botón Detener durante un cálculo largo | La interfaz responde; el cálculo se cancela; el siguiente cálculo funciona (worker o proceso reiniciado) |
| EN-SG-29 | N3 | 20 evaluaciones seguidas, o pegar mientras se calcula | El resultado mostrado corresponde a la **última** entrada (sin condiciones de carrera) |
| EN-SG-30 | N3 | Entrada con `"`, `'`, `\`, NUL (U+0000), CR/LF | La API de Plus recibe JSON válido; sin `400` ni `500` |
| EN-SG-31 | N3 | Cuerpo de 5 MB | Rechazo limpio (`413`) con mensaje claro |
| EN-SG-32 | N3 | Ráfaga de solicitudes (si hay límite de frecuencia) | Mensaje claro; no se pierde la entrada |

---

## Apéndice — Generadores de entradas de estrés (Python 3)

```python
depth = 50
print("(" * depth + "1" + ")" * depth)          # EN-SG-19
print("(" * 1000 + "1" + ")" * 1000)             # EN-SG-20
print("+".join(["1"] * 10000))                   # EN-SG-21
print("x+" * 50000 + "x")                         # EN-SG-22 (~100 000 caracteres)
```

## Plantilla de registro de resultados (copiar y completar)

| ID | Canal | Lite | Plus | Código de fallo | Observaciones |
|---|:-:|:-:|:-:|---|---|
| EN-EX-01 | L |  ☐ | ☐ |  |  |
| EN-TC-01 | ⌨ | ☐ | ☐ |  |  |
| EN-RE-01 | R | ☐ | ☐ |  |  |

Marcar con ✓ si cumple, ✗ si falla y – si no aplica o no está soportado. Anotar **OC** en observaciones cuando se apruebe por una convención alternativa documentada. Una fila solo se considera aprobada si Lite y Plus coinciden (S5).

---

## Resumen de cobertura

| Sección | Filas | N1 | N2 | N3 |
|---|:-:|:-:|:-:|:-:|
| A1 Fracciones | 24 | 5 | 16 | 3 |
| A2 Delimitadores y valor absoluto | 20 | 5 | 9 | 6 |
| A3 Operadores, factorial, relaciones | 24 | 6 | 11 | 7 |
| A4 Raíces | 15 | 2 | 13 | 0 |
| B1 Exponentes | 35 | 5 | 25 | 5 |
| B2 Subíndices y bases | 10 | 1 | 6 | 3 |
| B3 Multiplicación implícita | 36 | 5 | 23 | 8 |
| B4 Precedencia y signos | 14 | 5 | 8 | 1 |
| C1 Potencia vs. inversa de función | 25 | 6 | 14 | 5 |
| C2 Argumento sin paréntesis | 23 | 1 | 17 | 5 |
| C3 Alias en español y otros nombres | 36 | 13 | 21 | 2 |
| C4 Constantes, variables, funciones definidas | 24 | 1 | 11 | 12 |
| D1 Decimales y separadores | 26 | 3 | 17 | 6 |
| D2 Notación científica y porcentaje | 19 | 4 | 8 | 7 |
| D3 Precisión de la entrada | 20 | 2 | 7 | 11 |
| E1 Integrales, derivadas, límites, sumas | 32 | 2 | 25 | 5 |
| E2 Matrices, sistemas, trozos | 14 | 0 | 12 | 2 |
| E3 Detección de intención | 23 | 3 | 15 | 5 |
| F1 Contenedores y ruido LaTeX | 15 | 4 | 8 | 3 |
| F2 Unicode | 26 | 7 | 13 | 6 |
| F3 Otras sintaxis | 26 | 4 | 13 | 9 |
| G1 Teclado | 27 | 2 | 20 | 5 |
| G2 Invariancia entre canales | 15 | 4 | 9 | 2 |
| G3 Entradas inválidas | 34 | 14 | 17 | 3 |
| H.1 Reingreso de la salida | 30 | 2 | 21 | 7 |
| H.2 Seguridad y límites | 32 | 2 | 8 | 22 |
| **Total** | **625** | **108** | **367** | **150** |
