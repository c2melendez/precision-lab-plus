# Matriz de estrés — Motores gráficos (Lite y Plus)

Batería para evaluar la graficación de la calculadora (Precision Lab Lite y Precision Lab Plus): análisis de funciones, funciones a trozos, sistemas, cónicas e implícitas, límites, derivadas y rectas tangentes, integrales como área y longitud de arco, sumas de Riemann, curvas paramétricas y polares, y todo el bloque 3D (superficies, curvas de nivel, sólidos y superficies de revolución, superficies paramétricas, integrales múltiples y sólidos de Riemann).

## Convenciones

- Cada ejercicio y cada resultado esperado está en código LaTeX, listo para pegar. La columna "Verificación" describe **lo que debe verse y medirse** en la gráfica.
- **Nivel:** `N1` básico · `N2` intermedio · `N3` desafío (muestreo adaptativo, ramas, dominios con huecos, rendimiento, funciones especiales).
- Radianes por defecto. Ventana "sugerida" entre corchetes: `[x_{\min},x_{\max}]\times[y_{\min},y_{\max}]`.
- Los valores numéricos se dan con 4 a 9 decimales (`\approx`). Los resultados se calcularon a mano y se verificaron por sustitución o derivación; ante una discrepancia, revisar primero el valor esperado.

**Abreviaturas de la columna "Verificación"**

| Abreviatura | Significado |
|---|---|
| Dom, Rg | Dominio, rango |
| Ix, Iy | Interceptos con el eje `x` y con el eje `y` |
| Máx, Mín | Extremos (locales salvo que se diga "abs.") |
| ↑, ↓ | Intervalos de crecimiento y de decrecimiento |
| ∪, ∩ | Cóncava hacia arriba, cóncava hacia abajo |
| PI | Punto de inflexión |
| AV, AH, AO | Asíntota vertical, horizontal, oblicua |
| ○, ● | Punto **hueco** (excluido) y punto **sólido** (incluido) |

## Criterios visuales comunes (aplican a todos los ejercicios 2D)

1. Ejes con marcas y números legibles; origen visible cuando corresponda; relación de aspecto `1:1` en circunferencias, cónicas, tangentes y normales (una circunferencia no debe verse como elipse).
2. Puntos huecos (○) y sólidos (●) correctos en extremos de intervalo y en discontinuidades.
3. Asíntotas verticales **sin** segmento falso que una las ramas.
4. Interceptos, extremos e intersecciones ubicados con la precisión indicada y, de ser posible, etiquetados.
5. Muestreo adaptativo en oscilaciones y en cambios bruscos de pendiente.
6. Orientación y orden correctos en curvas paramétricas y polares.

## Criterios visuales comunes (aplican a todos los ejercicios 3D)

1. Ejes `x`, `y`, `z` con sistema de mano derecha, rotulados, con marcas, y con relación de aspecto `1:1:1` (una esfera se ve redonda).
2. Oclusión correcta (superficies delanteras tapan las traseras), sin "z-fighting" en intersecciones.
3. Normales bien orientadas y sombreado coherente; sin agujeros en los polos ni en las costuras.
4. Recorte (clipping) de valores no acotados sin picos falsos; dominios restringidos respetados.
5. Rotación, zoom y desplazamiento fluidos.

## Categorías de fallo gráfico sugeridas

| Código | Significado | Gravedad |
|---|---|---|
| GF1 | Curva o superficie incorrecta | Crítica |
| GF2 | Artefactos: línea falsa a través de asíntotas o discontinuidades | Alta |
| GF3 | Dominio, huecos o extremos ○/● no respetados | Alta |
| GF4 | Muestreo insuficiente (aliasing, picos o ceros perdidos) | Alta |
| GF5 | Ventana o autoescala inadecuada; relación de aspecto distorsionada | Media |
| GF6 | Interceptos, extremos o intersecciones mal ubicados o sin etiqueta | Media |
| GF7 | Fallo 3D: orientación, normales, oclusión o recorte | Alta |
| GF8 | Rendimiento: tiempo excesivo o bloqueo | Media |
| GF9 | Tipo de gráfica no soportado (paramétrica, polar, implícita, a trozos, 3D) | Media |
| GF10 | Cálculo asociado incorrecto (área, longitud, volumen, pendiente) | Crítica |

---

# PARTE G — GRAFICACIÓN 2D

## G1. Análisis de funciones algebraicas

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GA-01 | N1 | `f(x)=x^{2}-4x+3` | Dom `\mathbb{R}` · Rg `[-1,\infty)` · Ix `1,\ 3` · Iy `3` · Mín `(2,-1)` · ↓ `(-\infty,2)` · ↑ `(2,\infty)` · ∪ en todo `\mathbb{R}` |
| GA-02 | N1 | `f(x)=-x^{2}+2x+8` | Dom `\mathbb{R}` · Rg `(-\infty,9]` · Ix `-2,\ 4` · Iy `8` · Máx `(1,9)` · ↑ `(-\infty,1)` · ↓ `(1,\infty)` |
| GA-03 | N1 | `f(x)=x^{3}` | Dom y Rg `\mathbb{R}` · Ix=Iy `(0,0)` · creciente · PI `(0,0)` con tangente horizontal |
| GA-04 | N2 | `f(x)=x^{3}-3x` | Rg `\mathbb{R}` · Ix `0,\ \pm\sqrt{3}` · Iy `0` · Máx `(-1,2)` · Mín `(1,-2)` · ↑ `(-\infty,-1)\cup(1,\infty)` · ↓ `(-1,1)` · PI `(0,0)` · ∩ si `x<0`, ∪ si `x>0` |
| GA-05 | N2 | `f(x)=x^{4}-4x^{2}` | Rg `[-4,\infty)` · Ix `0,\ \pm2` · Iy `0` · Mín abs. `(\pm\sqrt{2},-4)` · Máx local `(0,0)` · ↓ `(-\infty,-\sqrt{2})` ↑ `(-\sqrt{2},0)` ↓ `(0,\sqrt{2})` ↑ `(\sqrt{2},\infty)` · PI `\left(\pm\frac{\sqrt{6}}{3},-\frac{20}{9}\right)` |
| GA-06 | N2 | `f(x)=x^{3}-6x^{2}+9x` | Ix `0` y `3` (tangente al eje en `x=3`) · Iy `0` · Máx `(1,4)` · Mín `(3,0)` · ↑ `(-\infty,1)` ↓ `(1,3)` ↑ `(3,\infty)` · PI `(2,2)` |
| GA-07 | N2 | `f(x)=\left(x^{2}-1\right)^{2}` | Rg `[0,\infty)` · Ix `\pm1` (tangente) · Iy `1` · Mín `(\pm1,0)` · Máx local `(0,1)` · forma de "W" |
| GA-08 | N3 | `f(x)=x^{5}-5x^{3}+4x` | Ix `0,\ \pm1,\ \pm2` · Iy `0` · impar · Máx `\approx(-1.644,\,3.631)` y `\approx(0.544,\,1.419)` · Mín `\approx(-0.544,\,-1.419)` y `\approx(1.644,\,-3.631)` |
| GA-09 | N1 | `f(x)=\frac{1}{x}` | Dom y Rg `\mathbb{R}\setminus\{0\}` · sin Ix ni Iy · AV `x=0` · AH `y=0` · decreciente en cada rama · impar |
| GA-10 | N1 | `f(x)=\frac{1}{x^{2}}` | Dom `\mathbb{R}\setminus\{0\}` · Rg `(0,\infty)` · AV `x=0` · AH `y=0` · ↑ `(-\infty,0)` ↓ `(0,\infty)` |
| GA-11 | N2 | `f(x)=\frac{x^{2}-1}{x-1}` | Recta `y=x+1` con **hueco** ○ en `(1,2)` · Dom `\mathbb{R}\setminus\{1\}` · Rg `\mathbb{R}\setminus\{2\}` · Ix `-1` · Iy `1` |
| GA-12 | N2 | `f(x)=\frac{x+1}{x-2}` | Dom `\mathbb{R}\setminus\{2\}` · Rg `\mathbb{R}\setminus\{1\}` · Ix `-1` · Iy `-\frac{1}{2}` · AV `x=2` · AH `y=1` · decreciente en cada rama |
| GA-13 | N2 | `f(x)=\frac{x}{x^{2}+1}` | Rg `\left[-\frac12,\frac12\right]` · I `(0,0)` · Máx `\left(1,\frac12\right)` · Mín `\left(-1,-\frac12\right)` · AH `y=0` · PI en `x=0,\ \pm\sqrt{3}` |
| GA-14 | N2 | `f(x)=\frac{1}{x^{2}+1}` | Rg `(0,1]` · Iy `1` · sin Ix · Máx `(0,1)` · AH `y=0` · PI `\left(\pm\frac{\sqrt{3}}{3},\frac34\right)` |
| GA-15 | N3 | `f(x)=\frac{x^{2}-4}{x^{2}-x-2}` | Hueco ○ `\left(2,\frac43\right)` · AV `x=-1` · AH `y=1` · Ix `-2` · Iy `2` · Dom `\mathbb{R}\setminus\{-1,2\}` · Rg `\mathbb{R}\setminus\left\{1,\frac43\right\}` |
| GA-16 | N2 | `f(x)=\frac{x^{2}+1}{x}` | AV `x=0` · AO `y=x` · Rg `(-\infty,-2]\cup[2,\infty)` · Mín local `(1,2)` · Máx local `(-1,-2)` · sin Ix ni Iy |
| GA-17 | N3 | `f(x)=\frac{x^{3}}{x^{2}-1}` | AV `x=\pm1` · AO `y=x` · I `(0,0)` · Máx local `\left(-\sqrt{3},-\frac{3\sqrt{3}}{2}\right)` · Mín local `\left(\sqrt{3},\frac{3\sqrt{3}}{2}\right)` · tangente horizontal sin extremo en `x=0` |
| GA-18 | N1 | `f(x)=\sqrt{x}` | Dom y Rg `[0,\infty)` · I `(0,0)` ● · creciente · ∩ · tangente vertical en el origen |
| GA-19 | N1 | `f(x)=\sqrt{4-x^{2}}` | Semicircunferencia · Dom `[-2,2]` · Rg `[0,2]` · Ix `\pm2` · Iy `2` · Máx `(0,2)` |
| GA-20 | N2 | `f(x)=\sqrt{x^{2}-1}` | Dom `(-\infty,-1]\cup[1,\infty)` · Rg `[0,\infty)` · Ix `\pm1` · sin Iy · AO `y=\pm x` en los extremos |
| GA-21 | N3 | `f(x)=x\sqrt{4-x^{2}}` | Dom `[-2,2]` · Rg `[-2,2]` · Ix `0,\ \pm2` · Máx `(\sqrt{2},2)` · Mín `(-\sqrt{2},-2)` |
| GA-22 | N1 | `f(x)=\sqrt[3]{x}` | Dom y Rg `\mathbb{R}` (raíz real también para `x<0`) · I `(0,0)` · creciente · tangente vertical · PI `(0,0)` |
| GA-23 | N2 | `f(x)=x^{2/3}` | Dom `\mathbb{R}` · Rg `[0,\infty)` · Mín `(0,0)` con **cúspide** · ↓ `(-\infty,0)` ↑ `(0,\infty)` · simétrica |
| GA-24 | N1 | `f(x)=\lvert x\rvert` | Rg `[0,\infty)` · vértice `(0,0)` sin recta tangente · ↓ `(-\infty,0)` ↑ `(0,\infty)` |
| GA-25 | N2 | `f(x)=\left\lvert x^{2}-4\right\rvert` | Rg `[0,\infty)` · Ix `\pm2` (picos) · Iy `4` · Mín `(\pm2,0)` · Máx local `(0,4)` |
| GA-26 | N2 | `f(x)=\lvert x-1\rvert+\lvert x+2\rvert` | Rg `[3,\infty)` · Iy `3` · tramo constante `y=3` en `[-2,1]` · ↓ `(-\infty,-2)` ↑ `(1,\infty)` · sin Ix |
| GA-27 | N1 | `f(x)=e^{x}` | Dom `\mathbb{R}` · Rg `(0,\infty)` · Iy `1` · AH `y=0` (izquierda) · creciente · ∪ |
| GA-28 | N2 | `f(x)=e^{-x^{2}}` | Rg `(0,1]` · Iy `1` · Máx `(0,1)` · AH `y=0` · PI `\left(\pm\frac{\sqrt{2}}{2},e^{-1/2}\right)`, `e^{-1/2}\approx0.6065` |
| GA-29 | N1 | `f(x)=\ln x` | Dom `(0,\infty)` · Rg `\mathbb{R}` · Ix `1` · AV `x=0` · creciente · ∩ |
| GA-30 | N2 | `f(x)=\ln\left(x^{2}+1\right)` | Rg `[0,\infty)` · Mín `(0,0)` · PI `(\pm1,\ln2)`, `\ln2\approx0.6931` |
| GA-31 | N2 | `f(x)=xe^{x}` | Rg `\left[-\frac1e,\infty\right)` · I `(0,0)` · Mín `\left(-1,-\frac1e\right)` · AH `y=0` (izquierda) · PI `(-2,-2e^{-2})` |
| GA-32 | N2 | `f(x)=x\ln x` | Dom `(0,\infty)` · Rg `\left[-\frac1e,\infty\right)` · Ix `1` · Mín `\left(\frac1e,-\frac1e\right)` · extremo izquierdo ○ en `(0,0)` |
| GA-33 | N2 | `f(x)=x^{2}e^{-x}` | Rg `[0,\infty)` · I `(0,0)` · Mín `(0,0)` · Máx `(2,4e^{-2})\approx(2,0.5413)` · AH `y=0` (derecha) · PI en `x=2\pm\sqrt{2}` |
| GA-34 | N2 | `f(x)=\frac{\ln x}{x}` | Dom `(0,\infty)` · Ix `1` · Máx `\left(e,\frac1e\right)` · AV `x=0` (hacia `-\infty`) · AH `y=0` |
| GA-35 | N2 | `f(x)=\frac{1}{1+e^{-x}}` | Rg `(0,1)` · Iy `\frac12` · AH `y=0` y `y=1` · creciente · PI `\left(0,\frac12\right)` |
| GA-36 | N3 | `f(x)=x^{x},\ x>0` | Rg `\left[e^{-1/e},\infty\right)`, `e^{-1/e}\approx0.6922` · Mín `\left(\frac1e,e^{-1/e}\right)` · límite 1 en `0^{+}` (extremo ○ en `(0,1)`) |

---

## G2. Funciones trigonométricas, inversas e hiperbólicas

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GT-01 | N1 | `y=\sin x` | Dom `\mathbb{R}` · Rg `[-1,1]` · periodo `2\pi` · Ix `k\pi` · Iy `0` · Máx `\left(\frac\pi2+2k\pi,1\right)` · Mín `\left(\frac{3\pi}{2}+2k\pi,-1\right)` |
| GT-02 | N1 | `y=\cos x` | Ix `\frac\pi2+k\pi` · Iy `1` · Máx en `x=2k\pi` · Mín en `x=(2k+1)\pi` |
| GT-03 | N1 | `y=\tan x` | Dom `x\neq\frac\pi2+k\pi` · Rg `\mathbb{R}` · periodo `\pi` · Ix `k\pi` · AV `x=\frac\pi2+k\pi` (sin segmentos falsos) · siempre creciente |
| GT-04 | N1 | `y=\cot x` | Dom `x\neq k\pi` · Ix `\frac\pi2+k\pi` · AV `x=k\pi` · siempre decreciente |
| GT-05 | N2 | `y=\sec x` | Dom `x\neq\frac\pi2+k\pi` · Rg `(-\infty,-1]\cup[1,\infty)` · Iy `1` · sin Ix · Mín local `(2k\pi,1)` · Máx local `((2k+1)\pi,-1)` |
| GT-06 | N2 | `y=\csc x` | Dom `x\neq k\pi` · Rg `(-\infty,-1]\cup[1,\infty)` · sin intercepto · AV `x=k\pi` |
| GT-07 | N2 | `y=2\sin(3x-\pi)` | Amplitud `2` · periodo `\frac{2\pi}{3}` · desfase `\frac\pi3` a la derecha · Iy `0` · Ix `\frac{k\pi}{3}` · Máx `\left(\frac\pi2,2\right)` · Mín `\left(\frac{5\pi}{6},-2\right)` |
| GT-08 | N2 | `y=-3\cos\frac{x}{2}+1` | Rg `[-2,4]` · periodo `4\pi` · Iy `-2` · Mín `(0,-2)` · Máx `(2\pi,4)` · Ix `x=\pm2\arccos\frac13+4k\pi`, `\approx\pm2.462` |
| GT-09 | N2 | `y=\sin x+\cos x` | Igual a `\sqrt{2}\sin\left(x+\frac\pi4\right)` · Rg `[-\sqrt{2},\sqrt{2}]` · Iy `1` · Ix `\frac{3\pi}{4}+k\pi` · Máx `\left(\frac\pi4,\sqrt{2}\right)` |
| GT-10 | N2 | `y=\sin^{2}x` | Rg `[0,1]` · periodo `\pi` · Ix `k\pi` (tangentes) · Máx `\left(\frac\pi2+k\pi,1\right)` |
| GT-11 | N2 | `y=\sin x\cos x` | Igual a `\frac12\sin2x` · amplitud `\frac12` · periodo `\pi` |
| GT-12 | N2 | `y=x\sin x` | Envolventes `y=\pm x` (tangentes en los máximos) · Ix `k\pi` · Iy `0` · par · no periódica |
| GT-13 | N3 | `y=\sin\frac{1}{x}` | Dom `x\neq0` · Rg `[-1,1]` · oscilación infinita cerca de `0` (muestreo adaptativo) · Ix `\frac{1}{k\pi}` · AH `y=0` en `\pm\infty` · sin Iy |
| GT-14 | N3 | `y=x\sin\frac{1}{x}` | Dom `x\neq0` · envolventes `y=\pm\lvert x\rvert` · límite `0` en `x=0` (hueco ○ en el origen) · AH `y=1` en `\pm\infty` (por debajo) |
| GT-15 | N2 | `y=\frac{\sin x}{x}` | Hueco ○ `(0,1)` · Rg `\approx[-0.2172,1)` · Ix `k\pi,\ k\neq0` · AH `y=0` · par · Mín `\approx(\pm4.4934,-0.2172)` |
| GT-16 | N2 | `y=e^{-x/10}\sin x` | Envolventes `y=\pm e^{-x/10}` · Ix `k\pi` · AH `y=0` (derecha) |
| GT-17 | N3 | `y=\sin\left(x^{2}\right)` | Chirp: oscilación cada vez más rápida · Ix `\pm\sqrt{k\pi}` · Iy `0` · par |
| GT-18 | N2 | `y=\tan\frac{x}{2}` | Periodo `2\pi` · AV `x=\pi+2k\pi` · Ix `2k\pi` |
| GT-19 | N2 | `y=\arcsin x` | Dom `[-1,1]` · Rg `\left[-\frac\pi2,\frac\pi2\right]` · I `(0,0)` · extremos ● en `\left(\pm1,\pm\frac\pi2\right)` · tangentes verticales en los extremos |
| GT-20 | N2 | `y=\arccos x` | Dom `[-1,1]` · Rg `[0,\pi]` · Ix `1` · Iy `\frac\pi2` · decreciente |
| GT-21 | N2 | `y=\arctan x` | Dom `\mathbb{R}` · Rg `\left(-\frac\pi2,\frac\pi2\right)` · AH `y=\pm\frac\pi2` · I `(0,0)` · PI `(0,0)` |
| GT-22 | N2 | `y=\operatorname{arccot}x` | Rg `(0,\pi)` · AH `y=0` y `y=\pi` · Iy `\frac\pi2` · decreciente |
| GT-23 | N2 | `y=\operatorname{arcsec}x` | Dom `(-\infty,-1]\cup[1,\infty)` · Rg `\left[0,\frac\pi2\right)\cup\left(\frac\pi2,\pi\right]` · AH `y=\frac\pi2` |
| GT-24 | N2 | `y=\cosh x` | Rg `[1,\infty)` · Iy `1` · Mín `(0,1)` · par (catenaria) |
| GT-25 | N2 | `y=\tanh x` | Rg `(-1,1)` · AH `y=\pm1` · I `(0,0)` · creciente · PI `(0,0)` |
| GT-26 | N2 | `y=\sinh x` | Dom y Rg `\mathbb{R}` · impar · creciente · PI `(0,0)` |
| GT-27 | N2 | `y=\operatorname{arcosh}x` | Dom `[1,\infty)` · Rg `[0,\infty)` · Ix `1` ● · tangente vertical en `x=1` |
| GT-28 | N2 | `y=\operatorname{artanh}x` | Dom `(-1,1)` · Rg `\mathbb{R}` · AV `x=\pm1` · I `(0,0)` |
| GT-29 | N2 | `y=\arcsin(\sin x)` | Onda triangular de amplitud `\frac\pi2` y periodo `2\pi` · igual a `x` en `\left[-\frac\pi2,\frac\pi2\right]` |
| GT-30 | N3 | `y=\arctan(\tan x)` | Dientes de sierra de periodo `\pi` · igual a `x-k\pi` · huecos ○ en `x=\frac\pi2+k\pi` |
| GT-31 | N2 | `y=\sin x+\sin2x` | Periodo `2\pi` · Rg `\approx[-1.7601,1.7601]` · Máx `\approx(0.9359,1.7601)` |
| GT-32 | N3 | `y=\sin x\,\sin10x` | Portadora `\sin10x` con envolvente `\pm\lvert\sin x\rvert` |
| GT-33 | N3 | `y=\sin10x+\sin11x` | Pulsaciones: envolvente `\pm2\left\lvert\cos\frac{x}{2}\right\rvert`, periodo de la envolvente `2\pi` |

---

## G3. Funciones definidas a trozos

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GP-01 | N2 | `f(x)=\begin{cases}-x-3&\text{si }-4\le x<-1\\ x^{2}-1&\text{si }-1\le x\le2\\ 2&\text{si }2<x\le5\end{cases}` | Dom `[-4,5]` · Rg `(-2,3]` · tramo 1: ● `(-4,1)` → ○ `(-1,-2)` · tramo 2: ● `(-1,0)`, Mín `(0,-1)`, ● `(2,3)` · tramo 3: ○ `(2,2)` → ● `(5,2)` · Ix `-3,\ -1,\ 1` · Iy `-1` · saltos en `x=-1` (de `-2` a `0`) y en `x=2` (de `3` a `2`) · Máx abs. `(2,3)` · **sin** mínimo absoluto (ínfimo `-2` no alcanzado) · ↓ `(-4,0)` ↑ `(0,2)` constante en `(2,5]` |
| GP-02 | N1 | `f(x)=\begin{cases}-x+2&\text{si }x<2\\ x-2&\text{si }x\ge2\end{cases}` | Es `\lvert x-2\rvert` · vértice `(2,0)` · Rg `[0,\infty)` · Iy `2` |
| GP-03 | N2 | `f(x)=\begin{cases}x+1&\text{si }x<0\\ x^{2}&\text{si }x\ge0\end{cases}` | Salto en `x=0`: ○ `(0,1)` y ● `(0,0)` · Dom `\mathbb{R}` · Rg `\mathbb{R}` · Ix `-1,\ 0` · Iy `0` |
| GP-04 | N2 | `f(x)=\begin{cases}\frac{x^{2}-1}{x-1}&\text{si }x\neq1\\ 3&\text{si }x=1\end{cases}` | Recta `y=x+1` con hueco ○ `(1,2)` y punto aislado ● `(1,3)` · discontinuidad evitable · Rg `\mathbb{R}\setminus\{2\}` |
| GP-05 | N3 | `f(x)=\begin{cases}x\sin\frac1x&\text{si }x\neq0\\ 0&\text{si }x=0\end{cases}` | Continua en `0`: la curva pasa por el origen ● · envolventes `\pm\lvert x\rvert` |
| GP-06 | N3 | `f(x)=\begin{cases}\sin\frac1x&\text{si }x\neq0\\ 0&\text{si }x=0\end{cases}` | Discontinuidad esencial en `0` · oscilación infinita · punto ● `(0,0)` aislado |
| GP-07 | N1 | `f(x)=\begin{cases}-1&\text{si }x<0\\ 0&\text{si }x=0\\ 1&\text{si }x>0\end{cases}` | Función signo · dos semirrectas con ○ en `x=0` y punto ● `(0,0)` |
| GP-08 | N2 | `f(x)=\lfloor x\rfloor,\ x\in[-2,3)` | Escalones: `-2` en `[-2,-1)`, `-1` en `[-1,0)`, `0`, `1`, `2` en `[2,3)` · ● a la izquierda y ○ a la derecha de cada escalón · **sin** segmentos verticales |
| GP-09 | N2 | `f(x)=\lceil x\rceil,\ x\in(-2,3]` | Escalones con ○ a la izquierda y ● a la derecha |
| GP-10 | N2 | `f(x)=x-\lfloor x\rfloor,\ x\in[-2,3)` | Diente de sierra: `0\le y<1`, periodo `1`, ● en `y=0` y ○ en `y=1` |
| GP-11 | N2 | `f(x)=\begin{cases}0&\text{si }x<2\\ 1&\text{si }x\ge2\end{cases}` | Escalón de Heaviside `u(x-2)` · ○ `(2,0)`, ● `(2,1)` |
| GP-12 | N3 | `f(x)=\begin{cases}x^{2}&\text{si }x\le1\\ 2x-1&\text{si }1<x\le3\\ 8-x&\text{si }x>3\end{cases}` | Continua en `x=1` y `x=3` · derivable en `x=1` (pendientes `2` y `2`) · pico en `x=3` (pendientes `2` y `-1`) · Ix `0,\ 8` · Iy `0` · Mín `(0,0)` · Máx `(3,5)` · ↓ `(-\infty,0)` ↑ `(0,3)` ↓ `(3,\infty)` · Rg `\mathbb{R}` |
| GP-13 | N2 | `f(x)=\left\lvert\lvert x\rvert-2\right\rvert` | Rg `[0,\infty)` · Ix `\pm2` · Iy `2` · Mín `(\pm2,0)` · Máx local `(0,2)` |
| GP-14 | N3 | `f(x)=\begin{cases}\frac1x&\text{si }x<-1\\ x^{2}&\text{si }-1<x<1\\ 3-x&\text{si }x>1\end{cases}` | Dom `\mathbb{R}\setminus\{-1,1\}` · huecos ○ en `(-1,-1)`, `(-1,1)`, `(1,1)`, `(1,2)` · Ix `0,\ 3` · Iy `0` · Rg `(-\infty,2)` |
| GP-15 | N2 | `f(x)=\begin{cases}e^{x}&\text{si }x\le0\\ 1+\ln(1+x)&\text{si }x>0\end{cases}` | Continua y derivable en `0` (pendiente `1`) · Iy `1` · sin Ix · AH `y=0` (izquierda) · Rg `(0,\infty)` |
| GP-16 | N2 | `f(x)=\max(\sin x,0),\ x\in[0,4\pi]` | Media onda rectificada: `\sin x` cuando es positivo y `0` en el resto |
| GP-17 | N2 | `f(x)=\lvert x\rvert,\ x\in[-1,1],\ \text{periodo }2` | Onda triangular · Rg `[0,1]` · Ix `2k` · Iy `0` |
| GP-18 | N2 | `f(x)=\begin{cases}1&\text{si }0\le x<1\\ -1&\text{si }1\le x<2\end{cases},\ \text{periodo }2` | Onda cuadrada con ● y ○ alternados |
| GP-19 | N3 | `f(x)=\begin{cases}kx+1&\text{si }x<2\\ x^{2}&\text{si }x\ge2\end{cases}` con control deslizante `k` | Continua si y solo si `2k+1=4`, es decir `k=\frac32`; para otro `k` se ve el salto |
| GP-20 | N1 | `f(x)=x^{2},\ x\in[0,3)` | Parábola solo en el intervalo: ● `(0,0)`, ○ `(3,9)` |

---

## G4. Sistemas de ecuaciones y desigualdades

### G4.S Sistemas de ecuaciones

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GS-01 | N1 | `\begin{cases}x+y=3\\ x-y=1\end{cases}` | Dos rectas que se cortan en `(2,1)` |
| GS-02 | N1 | `\begin{cases}y=2x+1\\ y=-x+4\end{cases}` | Intersección `(1,3)` |
| GS-03 | N1 | `\begin{cases}3x+2y=12\\ x-y=-1\end{cases}` | Intersección `(2,3)` |
| GS-04 | N1 | `\begin{cases}x+y=1\\ x+y=3\end{cases}` | Rectas paralelas: sin solución |
| GS-05 | N1 | `\begin{cases}2x-y=1\\ 4x-2y=2\end{cases}` | Rectas coincidentes: infinitas soluciones (`y=2x-1`) |
| GS-06 | N2 | `\begin{cases}x^{2}+y^{2}=25\\ y=x+1\end{cases}` | Circunferencia y recta: `(3,4)` y `(-4,-3)` |
| GS-07 | N2 | `\begin{cases}y=x^{2}\\ y=x+2\end{cases}` | `(-1,1)` y `(2,4)` |
| GS-08 | N2 | `\begin{cases}y=x^{2}\\ y=-x^{2}+8\end{cases}` | `(-2,4)` y `(2,4)` |
| GS-09 | N3 | `\begin{cases}x^{2}+y^{2}=4\\ \frac{x^{2}}{9}+\frac{y^{2}}{4}=1\end{cases}` | Tangentes en `(0,2)` y `(0,-2)`; la circunferencia queda dentro de la elipse |
| GS-10 | N3 | `\begin{cases}x^{2}+y^{2}=1\\ y=x^{2}\end{cases}` | `\left(\pm\sqrt{\frac{\sqrt5-1}{2}},\ \frac{\sqrt5-1}{2}\right)\approx(\pm0.7862,\,0.6180)` |
| GS-11 | N2 | `\begin{cases}xy=1\\ x+y=\frac52\end{cases}` | `(2,\frac12)` y `(\frac12,2)` |
| GS-12 | N3 | `\begin{cases}y=e^{x}\\ y=x+2\end{cases}` | `\approx(-1.8414,\,0.1586)` y `\approx(1.1462,\,3.1462)` |
| GS-13 | N3 | `\begin{cases}y=\ln x\\ y=x-2\end{cases}` | `\approx(0.1586,\,-1.8414)` y `\approx(3.1462,\,1.1462)` |
| GS-14 | N3 | `\begin{cases}y=\sin x\\ y=\frac{x}{2}\end{cases}` | `(0,0)` y `\approx(\pm1.8955,\,\pm0.9477)` |
| GS-15 | N3 | `\begin{cases}y=\cos x\\ y=x\end{cases}` | Una sola intersección `\approx(0.7391,\,0.7391)` |
| GS-16 | N2 | `\begin{cases}y=x^{3}-x\\ y=x\end{cases}` | `(0,0)` y `(\pm\sqrt{2},\pm\sqrt{2})` |
| GS-17 | N2 | `\begin{cases}y=\lvert x\rvert\\ y=2-x^{2}\end{cases}` | `(\pm1,1)` |
| GS-18 | N2 | `\begin{cases}y=\frac1x\\ y=x^{2}\end{cases}` | Una sola intersección `(1,1)` |
| GS-19 | N2 | `\begin{cases}y=\sqrt{x}\\ y=x^{2}\end{cases}` | `(0,0)` y `(1,1)` |
| GS-20 | N2 | `\begin{cases}y=x\\ y=-x+4\\ y=0\end{cases}` | Triángulo de vértices `(0,0)`, `(4,0)`, `(2,2)`; área `4` |

### G4.D Desigualdades y regiones

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GS-21 | N1 | `y>x^{2}-1` | Región por encima de la parábola; frontera **discontinua** (no incluida) |
| GS-22 | N2 | `\begin{cases}y\le x+2\\ y\ge x^{2}\end{cases}` | Región entre la parábola y la recta; vértices `(-1,1)` y `(2,4)`; área `\frac92` |
| GS-23 | N2 | `\begin{cases}x\ge0\\ y\ge0\\ x+y\le4\\ 2x+y\le6\end{cases}` | Polígono de vértices `(0,0)`, `(3,0)`, `(2,2)`, `(0,4)`; máximo de `z=3x+2y` igual a `10` en `(2,2)` |
| GS-24 | N2 | `\begin{cases}x^{2}+y^{2}\le9\\ y\ge\lvert x\rvert\end{cases}` | Sector de `90^{\circ}` entre `\frac\pi4` y `\frac{3\pi}{4}`; área `\frac{9\pi}{4}` |
| GS-25 | N2 | `\lvert x\rvert+\lvert y\rvert\le2` | Rombo de vértices `(\pm2,0)`, `(0,\pm2)`; área `8` |
| GS-26 | N1 | `x^{2}-x-6>0` | Recta numérica con ○ en `-2` y `3`; solución `(-\infty,-2)\cup(3,\infty)` |
| GS-27 | N2 | `\frac{x-1}{x+2}\le0` | Solución `(-2,1]` (○ en `-2`, ● en `1`) |
| GS-28 | N1 | `\lvert x-1\rvert<3` | Solución `(-2,4)` |
| GS-29 | N3 | `\begin{cases}x^{2}+y^{2}<4\\ y>x^{2}-2\end{cases}` | Región dentro del disco y sobre la parábola; fronteras discontinuas; la parábola corta la circunferencia en `y=1` y `y=-2`, es decir `\left(\pm\sqrt{3},1\right)` y `(0,-2)` |

---

## G5. Cónicas y curvas implícitas

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GC-01 | N1 | `x^{2}+y^{2}=9` | Circunferencia, centro `(0,0)`, radio `3`; Ix `\pm3`, Iy `\pm3` |
| GC-02 | N1 | `(x-2)^{2}+(y+1)^{2}=4` | Centro `(2,-1)`, radio `2` |
| GC-03 | N2 | `x^{2}+y^{2}-6x+4y-3=0` | Centro `(3,-2)`, radio `4` |
| GC-04 | N1 | `\frac{x^{2}}{16}+\frac{y^{2}}{9}=1` | Elipse, vértices `(\pm4,0)`, `(0,\pm3)`, focos `(\pm\sqrt{7},0)`, `e=\frac{\sqrt7}{4}` |
| GC-05 | N2 | `\frac{x^{2}}{9}+\frac{y^{2}}{25}=1` | Elipse vertical, focos `(0,\pm4)`, `e=\frac45` |
| GC-06 | N2 | `4x^{2}+9y^{2}-16x+18y-11=0` | `\frac{(x-2)^{2}}{9}+\frac{(y+1)^{2}}{4}=1`: centro `(2,-1)`, focos `(2\pm\sqrt{5},-1)` |
| GC-07 | N2 | `\frac{x^{2}}{9}-\frac{y^{2}}{16}=1` | Hipérbola, vértices `(\pm3,0)`, asíntotas `y=\pm\frac43x`, focos `(\pm5,0)` |
| GC-08 | N2 | `\frac{y^{2}}{4}-\frac{x^{2}}{9}=1` | Vértices `(0,\pm2)`, asíntotas `y=\pm\frac23x`, focos `(0,\pm\sqrt{13})` |
| GC-09 | N2 | `xy=1` | Hipérbola equilátera, asíntotas los ejes |
| GC-10 | N2 | `y^{2}=8x` | Parábola, vértice `(0,0)`, foco `(2,0)`, directriz `x=-2` |
| GC-11 | N2 | `x^{2}=-12y` | Foco `(0,-3)`, directriz `y=3`, abre hacia abajo |
| GC-12 | N2 | `(y-1)^{2}=4(x+2)` | Vértice `(-2,1)`, foco `(-1,1)`, directriz `x=-3` |
| GC-13 | N3 | `x^{2}-y^{2}=0` | Cónica degenerada: dos rectas `y=\pm x` |
| GC-14 | N3 | `x^{2}+y^{2}=0` | Un solo punto `(0,0)` |
| GC-15 | N3 | `x^{2}+y^{2}=-1` | Sin gráfica real (aviso claro, no un lienzo vacío sin explicación) |
| GC-16 | N3 | `x^{2}+xy+y^{2}=3` | Elipse girada `45^{\circ}`: semiejes `\sqrt{2}` (dirección `(1,1)`) y `\sqrt{6}` (dirección `(-1,1)`) |
| GC-17 | N3 | `x^{3}+y^{3}=3xy` | Folium de Descartes: nodo en el origen, lazo en el primer cuadrante que pasa por `\left(\frac32,\frac32\right)`, asíntota `x+y+1=0` |
| GC-18 | N3 | `\left(x^{2}+y^{2}\right)^{2}=2\left(x^{2}-y^{2}\right)` | Lemniscata: Ix `0,\ \pm\sqrt{2}`, sin Iy distinto de `0`, forma de "∞" |
| GC-19 | N3 | `\left(x^{2}+y^{2}-x\right)^{2}=x^{2}+y^{2}` | Cardioide con cúspide en el origen; Ix `0,\ 2` |
| GC-20 | N3 | `y^{2}=x^{3}-x` | Curva elíptica con **dos componentes**: un óvalo en `[-1,0]` y una rama en `x\ge1` |
| GC-21 | N3 | `y^{2}=x^{2}(x+1)` | Cúbica nodal: nodo en el origen, Ix `-1,\ 0`, lazo en `[-1,0]` |
| GC-22 | N3 | `y^{2}=x^{3}` | Parábola semicúbica con cúspide en el origen |
| GC-23 | N3 | `x^{4}+y^{4}=1` | Superelipse: Ix `\pm1`, Iy `\pm1`, esquinas redondeadas |
| GC-24 | N3 | `\lvert x\rvert^{2/3}+\lvert y\rvert^{2/3}=1` | Astroide con 4 cúspides en `(\pm1,0)` y `(0,\pm1)` |
| GC-25 | N3 | `\sin x=\sin y` | Familia de rectas `y=x+2k\pi` y `y=\pi-x+2k\pi` |
| GC-26 | N2 | `x^{2}+y^{2}<4` | Disco abierto con frontera discontinua |

---

## G6. Graficación de límites

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GL-01 | N1 | `\lim_{x\to2}\frac{x^{2}-4}{x-2}` | Recta `y=x+2` con hueco ○ en `(2,4)`; límite `4` |
| GL-02 | N1 | `\lim_{x\to0}\frac{\sin x}{x}` | Hueco ○ en `(0,1)`; límite `1` |
| GL-03 | N1 | `\lim_{x\to0^{+}}\frac1x` y `\lim_{x\to0^{-}}\frac1x` | `+\infty` y `-\infty`; AV `x=0` |
| GL-04 | N1 | `\lim_{x\to\infty}\frac{2x+1}{x-3}` | AH `y=2` (la curva se acerca por arriba) |
| GL-05 | N2 | `\lim_{x\to0}\frac{1-\cos x}{x^{2}}` | Hueco ○ en `\left(0,\frac12\right)` |
| GL-06 | N2 | `\lim_{x\to1}\frac{\lvert x-1\rvert}{x-1}` | Laterales `-1` y `1`: el límite no existe; salto con ○ en ambos |
| GL-07 | N3 | `\lim_{x\to0}\sin\frac1x` | No existe: oscilación entre `-1` y `1` |
| GL-08 | N3 | `\lim_{x\to0}x\sin\frac1x` | `0` (teorema del sándwich con `y=\pm\lvert x\rvert`) |
| GL-09 | N3 | `\lim_{x\to0}x^{2}\sin\frac1x` | `0` (envolventes `y=\pm x^{2}`) |
| GL-10 | N2 | `\lim_{x\to\infty}\left(1+\frac1x\right)^{x}` | AH `y=e\approx2.71828`, la curva crece hacia ella por debajo |
| GL-11 | N2 | `\lim_{x\to0}(1+x)^{1/x}` | Hueco ○ en `(0,e)` |
| GL-12 | N2 | `\lim_{x\to\infty}e^{-x}\sin x` | `0` con envolventes `\pm e^{-x}` |
| GL-13 | N2 | `\lim_{x\to\frac\pi2^{-}}\tan x` y `\lim_{x\to\frac\pi2^{+}}\tan x` | `+\infty` y `-\infty` |
| GL-14 | N2 | `\lim_{x\to1}\frac{\sqrt{x}-1}{x-1}` | Hueco ○ en `\left(1,\frac12\right)` |
| GL-15 | N3 | `\lim_{x\to\infty}\left(\sqrt{x^{2}+x}-x\right)` | AH `y=\frac12` |
| GL-16 | N2 | `\lim_{x\to2}(3x-1)=5` con `\varepsilon=0.3` | Banda horizontal `y\in(4.7,5.3)` y banda vertical `x\in(1.9,2.1)`, es decir `\delta=0.1` |
| GL-17 | N3 | `\lim_{x\to1}x^{2}=1` con `\varepsilon=0.1` | `x\in(\sqrt{0.9},\sqrt{1.1})\approx(0.9487,1.0488)`, así `\delta\approx0.0513` |
| GL-18 | N2 | `f(x)=\begin{cases}\frac{x^{2}-9}{x-3}&x\neq3\\ k&x=3\end{cases}` | Continua si y solo si `k=6` (el punto ● cierra el hueco ○ en `(3,6)`) |
| GL-19 | N2 | Teorema del valor intermedio para `f(x)=x^{3}-x-1` en `[1,2]` | `f(1)=-1`, `f(2)=5`; raíz `\approx1.3247` marcada sobre el eje |
| GL-20 | N2 | `\lim_{x\to\pm\infty}\frac{x^{2}+1}{x}` | AO `y=x` (no AH) |
| GL-21 | N2 | Sucesión `a_{n}=\left(1+\frac1n\right)^{n}` | Puntos discretos: `a_{1}=2`, `a_{2}=2.25`, `a_{10}\approx2.5937`, `a_{100}\approx2.7048`, convergen a `e` |
| GL-22 | N2 | Sucesión `a_{n}=\frac{n}{n+1}` | Puntos por debajo de `y=1`, tienden a `1` |
| GL-23 | N3 | Sumas parciales `s_{n}=\sum_{k=1}^{n}\frac{1}{k}` | Puntos que crecen sin cota (divergen lentamente, como `\ln n`) |
| GL-24 | N3 | Sumas parciales `s_{n}=\sum_{k=1}^{n}\frac{1}{2^{k}}` | Puntos que se acercan a `y=1` por debajo |

---

## G7. Derivada: recta tangente, normal y aplicaciones

La gráfica debe mostrar la curva, el punto de tangencia, la recta tangente (y la normal cuando se pida) y, en lo posible, la ecuación.

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GD-01 | N1 | `f(x)=x^{2},\ a=1` | Tangente `y=2x-1`; normal `y=-\frac12x+\frac32` |
| GD-02 | N1 | `f(x)=x^{3}-3x,\ a=2` | `f(2)=2`, `f'(2)=9`; tangente `y=9x-16` |
| GD-03 | N1 | `f(x)=\sqrt{x},\ a=4` | Tangente `y=\frac{x}{4}+1` |
| GD-04 | N1 | `f(x)=\frac1x,\ a=2` | Tangente `y=-\frac{x}{4}+1` |
| GD-05 | N2 | `f(x)=\sin x,\ a=\frac\pi6` | Tangente `y=\frac12+\frac{\sqrt3}{2}\left(x-\frac\pi6\right)` |
| GD-06 | N2 | `f(x)=\cos x,\ a=\frac\pi3` | Tangente `y=\frac12-\frac{\sqrt3}{2}\left(x-\frac\pi3\right)` |
| GD-07 | N1 | `f(x)=e^{x},\ a=0` y `a=1` | Tangentes `y=x+1` y `y=ex` |
| GD-08 | N1 | `f(x)=\ln x,\ a=1` y `a=e` | Tangentes `y=x-1` y `y=\frac{x}{e}` |
| GD-09 | N2 | `f(x)=\tan x,\ a=\frac\pi4` | Tangente `y=1+2\left(x-\frac\pi4\right)` |
| GD-10 | N2 | `f(x)=xe^{-x},\ a=1` | Tangente horizontal `y=\frac1e` (máximo) |
| GD-11 | N2 | Tangente a `f(x)=x^{2}-4x+5` paralela a `y=2x` | Punto `(3,2)`; tangente `y=2x-4` |
| GD-12 | N2 | Tangentes horizontales de `f(x)=x^{3}-3x` | `y=2` en `x=-1` y `y=-2` en `x=1` |
| GD-13 | N2 | Tangente vertical de `f(x)=\sqrt[3]{x}` en `a=0` | Recta `x=0` |
| GD-14 | N3 | Tangentes a `y=x^{2}` desde el punto `(1,-3)` | Dos tangentes: `y=6x-9` (tangente en `x=3`) y `y=-2x-1` (tangente en `x=-1`) |
| GD-15 | N2 | `x^{2}+y^{2}=25` en `(3,4)` | Tangente `3x+4y=25`; normal `y=\frac43x` |
| GD-16 | N3 | `x^{2}+xy+y^{2}=3` en `(1,1)` | `y'=-1`; tangente `y=-x+2` |
| GD-17 | N3 | `x^{3}+y^{3}=3xy` en `\left(\frac32,\frac32\right)` | `y'=-1`; tangente `y=-x+3` |
| GD-18 | N2 | `x=t^{2},\ y=t^{3}` en `t=1` | Punto `(1,1)`; `\frac{dy}{dx}=\frac32`; tangente `y=\frac32x-\frac12` |
| GD-19 | N2 | `x=\cos t,\ y=\sin t` en `t=\frac\pi4` | Tangente `y=-x+\sqrt{2}` |
| GD-20 | N3 | `r=1+\cos\theta` en `\theta=\frac\pi2` | Punto `(0,1)`; pendiente `1`; tangente `y=x+1` |
| GD-21 | N2 | Secantes que tienden a la tangente: `f(x)=x^{2}`, `a=1`, `h=1,\ 0.5,\ 0.1,\ 0.01` | Pendientes de las secantes `3,\ 2.5,\ 2.1,\ 2.01` (`=2+h`) hacia la de la tangente `2` |
| GD-22 | N2 | Gráfica de `f` y `f'` juntas: `f(x)=x^{3}-3x` | `f'(x)=3x^{2}-3` con ceros en `\pm1` alineados con los extremos de `f`; `f''=6x` con cero en el PI |
| GD-23 | N2 | `f(x)=\lvert x\rvert` en `a=0` | No hay tangente: pendientes laterales `-1` y `1` |
| GD-24 | N2 | `f(x)=x^{2/3}` en `a=0` | Cúspide: sin recta tangente |
| GD-25 | N2 | Linealización de `f(x)=\sqrt{x}` en `a=4` | `L(x)=2+\frac{x-4}{4}`; `L(4.1)=2.025` frente a `\sqrt{4.1}\approx2.02485` |
| GD-26 | N3 | Método de Newton para `f(x)=x^{2}-2`, `x_{0}=1` | Tangentes sucesivas cortan el eje en `1.5`, `1.41667`, `1.414216` hacia `\sqrt{2}` |
| GD-27 | N3 | Método de bisección para `x^{2}-2` en `[1,2]` | Puntos medios `1.5`, `1.25`, `1.375`, `1.4375`; intervalos `[1,1.5]`, `[1.25,1.5]`, `[1.375,1.5]`, `[1.375,1.4375]` |
| GD-28 | N2 | Teorema del valor medio: `f(x)=x^{2}` en `[0,2]` | Secante de pendiente `2`; tangente paralela en `c=1` |
| GD-29 | N2 | Teorema de Rolle: `f(x)=x^{2}-2x` en `[0,2]` | `f(0)=f(2)=0`; tangente horizontal en `c=1` |
| GD-30 | N2 | Optimización: `V(x)=x(12-2x)^{2},\ 0<x<6` | Máx `(2,128)`; ceros de `V'` en `x=2` y `x=6` |
| GD-31 | N1 | Optimización: `A(x)=x(10-x)` | Máx `(5,25)` |
| GD-32 | N3 | Polinomios de Taylor de `\sin x` en `0`, grados 1, 3, 5, 7, superpuestos | Mejor aproximación al crecer el grado; `T_{3}(1)=\frac56\approx0.8333` frente a `\sin1\approx0.8415` |
| GD-33 | N3 | Polinomios de Taylor de `e^{x}` en `0`, grados 1 a 4 | `T_{4}(x)=1+x+\frac{x^{2}}{2}+\frac{x^{3}}{6}+\frac{x^{4}}{24}` coincide mejor cerca de `0` |

---

## G8. Integral definida: área, sumas de Riemann, acumulación y longitud de arco

### G8.A Área bajo la curva y entre curvas

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GI-01 | N1 | `\int_{0}^{2}x^{2}\,dx` | Región sombreada; valor `\frac83\approx2.6667` |
| GI-02 | N1 | `\int_{0}^{\pi}\sin x\,dx` | Valor `2` |
| GI-03 | N1 | `\int_{-1}^{1}\left(1-x^{2}\right)dx` | Valor `\frac43` |
| GI-04 | N1 | `\int_{0}^{1}\sqrt{x}\,dx` | Valor `\frac23` |
| GI-05 | N1 | `\int_{1}^{e}\frac{dx}{x}` | Valor `1` |
| GI-06 | N2 | `\int_{0}^{2\pi}\sin x\,dx` frente al área `\int_{0}^{2\pi}\lvert\sin x\rvert\,dx` | Integral `0` (áreas con signo se cancelan) y área total `4`; sombrear distinto sobre y bajo el eje |
| GI-07 | N2 | `\int_{-2}^{2}x^{3}\,dx` frente al área | Integral `0`; área `8` |
| GI-08 | N2 | `\int_{-1}^{3}\left(x^{2}-2x-3\right)dx` | Integral `-\frac{32}{3}\approx-10.667`; área `\frac{32}{3}` (región bajo el eje) |
| GI-09 | N1 | Área entre `y=x` y `y=x^{2}` en `[0,1]` | `\frac16` |
| GI-10 | N1 | Área entre `y=\sqrt{x}` y `y=x^{2}` | `\frac13` |
| GI-11 | N2 | Área entre `y=x^{2}` y `y=2-x^{2}` | Intersecciones `x=\pm1`; área `\frac83` |
| GI-12 | N2 | Área entre `y=\sin x` y `y=\cos x` en `\left[\frac\pi4,\frac{5\pi}{4}\right]` | `2\sqrt{2}\approx2.8284` |
| GI-13 | N2 | Área entre `y=e^{x}` y `y=x` en `[0,1]` | `e-\frac32\approx1.2183` |
| GI-14 | N2 | Área entre `y=x^{3}` y `y=x` en `[-1,1]` | `\frac12` (dos regiones simétricas) |
| GI-15 | N2 | Área entre `x=y^{2}` y `x=y+2` (integrando en `y`) | Intersecciones `y=-1,\ 2`; área `\frac92` |
| GI-16 | N2 | Área limitada por `y=4-x^{2}` y el eje `x` | `\frac{32}{3}` |
| GI-17 | N2 | Valor promedio de `f(x)=x^{2}` en `[0,3]` | `3`; se dibuja el rectángulo de altura `3` y el punto `c=\sqrt{3}` |
| GI-18 | N3 | `\int_{1}^{\infty}\frac{dx}{x^{2}}` | Área infinita que converge a `1` |
| GI-19 | N3 | `\int_{1}^{\infty}\frac{dx}{x}` | Diverge (el área crece sin cota); aviso claro |
| GI-20 | N3 | `\int_{-\infty}^{\infty}e^{-x^{2}}dx` | `\sqrt{\pi}\approx1.7725` |
| GI-21 | N2 | Distribución normal estándar: área bajo `\varphi(x)=\frac{1}{\sqrt{2\pi}}e^{-x^{2}/2}` entre `-1` y `1` | `\approx0.6827` (y `\approx0.9545` entre `\pm2`, `\approx0.9973` entre `\pm3`) |

### G8.B Sumas de Riemann

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GI-22 | N2 | `f(x)=x^{2}` en `[0,2]`, `n=4`, **izquierda** | Rectángulos de ancho `0.5`; suma `1.75` |
| GI-23 | N2 | Ídem, **derecha** | `3.75` |
| GI-24 | N2 | Ídem, **punto medio** | `2.625` |
| GI-25 | N2 | Ídem, **trapecio** | `2.75` |
| GI-26 | N2 | Ídem, **Simpson** | `\frac83\approx2.6667` (exacto para este polinomio) |
| GI-27 | N2 | `f(x)=\sin x` en `[0,\pi]`, `n=4`, izquierda = derecha = trapecio | `\approx1.896119` |
| GI-28 | N2 | Ídem, punto medio | `\approx2.052344` |
| GI-29 | N2 | Ídem, Simpson | `\approx2.004560` (valor exacto `2`) |
| GI-30 | N2 | `f(x)=\frac1x` en `[1,2]`, `n=4`, izquierda | `\approx0.759524` |
| GI-31 | N2 | Ídem, derecha | `\approx0.634524` |
| GI-32 | N2 | Ídem, punto medio | `\approx0.691220` (exacto `\ln2\approx0.693147`) |
| GI-33 | N2 | Ídem, Simpson | `\approx0.693254` |
| GI-34 | N2 | Sumas de Darboux de `f(x)=x` en `[0,1]`, `n=4` | Inferior `0.375`, superior `0.625`, exacto `0.5` |
| GI-35 | N3 | Convergencia: `f(x)=x^{2}` en `[0,2]` con `n=4,\ 8,\ 16,\ 32,\ 64` (animación o control deslizante) | Las sumas izquierda y derecha tienden a `\frac83` por ambos lados; el error disminuye de forma proporcional a `\frac1n` |

### G8.C Función de acumulación y longitud de arco

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GI-36 | N2 | `F(x)=\int_{0}^{x}\sin t\,dt` junto con `f(t)=\sin t` | `F(x)=1-\cos x`; `F` crece donde `f>0`; sus máximos coinciden con los ceros de `f` |
| GI-37 | N2 | `F(x)=\int_{0}^{x}e^{-t^{2}}dt` | `F(x)=\frac{\sqrt{\pi}}{2}\operatorname{erf}(x)`; AH `y=\frac{\sqrt\pi}{2}\approx0.8862` |
| GI-38 | N2 | Longitud de arco de `y=x^{3/2}` en `[0,4]` | `\frac{8}{27}\left(10^{3/2}-1\right)\approx9.0734` |
| GI-39 | N2 | Longitud de arco de `y=x^{2}` en `[0,1]` | `\frac{\sqrt5}{2}+\frac14\ln\left(2+\sqrt5\right)\approx1.478943` |
| GI-40 | N2 | Longitud de arco de `y=\cosh x` en `[0,1]` | `\sinh1\approx1.175201` |
| GI-41 | N3 | Longitud de arco de `y=\sin x` en `[0,\pi]` | `\approx3.820198` |
| GI-42 | N2 | Longitud de arco de `y=\sqrt{1-x^{2}}` en `[-1,1]` | `\pi` |
| GI-43 | N2 | Longitud de la arcada del cicloide `x=t-\sin t,\ y=1-\cos t,\ t\in[0,2\pi]` | `8` |
| GI-44 | N3 | Longitud total del astroide `x=\cos^{3}t,\ y=\sin^{3}t` | `6` |
| GI-45 | N2 | Longitud de la cardioide `r=1+\cos\theta` | `8` |
| GI-46 | N3 | Longitud de la espiral `r=\theta,\ \theta\in[0,2\pi]` | `\frac12\left[2\pi\sqrt{1+4\pi^{2}}+\operatorname{arsinh}(2\pi)\right]\approx21.2563` |
| GI-47 | N2 | Longitud de la circunferencia `x=r\cos t,\ y=r\sin t` | `2\pi r` |
| GI-48 | N2 | Área bajo una arcada del cicloide | `3\pi\approx9.4248` |
| GI-49 | N3 | Área encerrada por el astroide | `\frac{3\pi}{8}\approx1.1781` |
| GI-50 | N2 | Área de la elipse `x=a\cos t,\ y=b\sin t` | `\pi ab` |

---

## G9. Curvas paramétricas en 2D

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GM-01 | N1 | `x=\cos t,\ y=\sin t,\ t\in[0,2\pi]` | Circunferencia unitaria antihoraria; inicio `(1,0)` |
| GM-02 | N1 | `x=2\cos t,\ y=3\sin t` | Elipse de semiejes `2` y `3` |
| GM-03 | N1 | `x=t,\ y=t^{2},\ t\in[-2,2]` | Parábola con orientación hacia la derecha |
| GM-04 | N2 | `x=t^{2},\ y=t^{3}` | Parábola semicúbica con cúspide en el origen |
| GM-05 | N1 | `x=1+2t,\ y=3-t,\ t\in[0,2]` | Segmento de `(1,3)` a `(5,1)` con flecha de dirección |
| GM-06 | N2 | `x=t-\sin t,\ y=1-\cos t,\ t\in[0,2\pi]` | Arcada del cicloide: cúspides en `(0,0)` y `(2\pi,0)`, altura `2` en `(\pi,2)` |
| GM-07 | N2 | `x=t-1.5\sin t,\ y=1-1.5\cos t` | Trocoide prolata con **lazos** |
| GM-08 | N2 | `x=\cos^{3}t,\ y=\sin^{3}t` | Astroide con 4 cúspides |
| GM-09 | N2 | `x=2\cos t-\cos2t,\ y=2\sin t-\sin2t` | Cardioide (epicicloide): cúspide en `(1,0)`; área `6\pi`; perímetro `16` |
| GM-10 | N3 | `x=2\cos t+\cos2t,\ y=2\sin t-\sin2t` | Deltoide con 3 cúspides |
| GM-11 | N2 | `x=\cos t,\ y=\sin2t` | Curva en forma de "∞" que pasa por el origen en `t=\frac\pi2` y `t=\frac{3\pi}{2}` |
| GM-12 | N3 | `x=\sin3t,\ y=\sin2t` | Lissajous `3:2`, cerrada en `[-1,1]^{2}`, simétrica respecto a ambos ejes |
| GM-13 | N2 | `x=t\cos t,\ y=t\sin t,\ t\in[0,4\pi]` | Espiral de Arquímedes |
| GM-14 | N2 | `x=e^{0.1t}\cos t,\ y=e^{0.1t}\sin t,\ t\in[0,8\pi]` | Espiral logarítmica |
| GM-15 | N2 | `x=\cos t+t\sin t,\ y=\sin t-t\cos t` | Involuta de la circunferencia |
| GM-16 | N3 | `x=\frac{3t}{1+t^{3}},\ y=\frac{3t^{2}}{1+t^{3}}` | Folium de Descartes (sin segmento falso en `t\to-1`) |
| GM-17 | N2 | Bézier cuadrática con `P_{0}=(0,0),\ P_{1}=(1,2),\ P_{2}=(2,0)` | `x=2t,\ y=4t(1-t)`, parábola `y=2x-x^{2}` con vértice `(1,1)` |
| GM-18 | N2 | Bézier cúbica con `P_{0}=(0,0),\ P_{1}=(0,1),\ P_{2}=(1,1),\ P_{3}=(1,0)` | `x=3t^{2}-2t^{3},\ y=3t(1-t)`; en `t=\frac12`: `\left(\frac12,\frac34\right)` |
| GM-19 | N2 | `x=\cos t,\ y=-\sin t` y `t\in[0,\frac\pi2]` | Circunferencia horaria; solo el primer cuarto, con dirección |
| GM-20 | N2 | `x=\cos t,\ y=\sin t,\ t\in[0,4\pi]` | Circunferencia recorrida dos veces (la orientación no cambia) |
| GM-21 | N2 | Derivada segunda paramétrica: `x=t^{2},\ y=t^{3}` | `\frac{d^{2}y}{dx^{2}}=\frac{3}{4t}`; en `t=1` vale `\frac34` |
| GM-22 | N3 | Curva mariposa: `x=\sin t\left(e^{\cos t}-2\cos4t-\sin^{5}\frac{t}{12}\right)`, `y=\cos t\left(e^{\cos t}-2\cos4t-\sin^{5}\frac{t}{12}\right)`, `t\in[0,12\pi]` | Figura de mariposa con 4 alas; prueba de rendimiento y de muestreo |
| GM-23 | N3 | Corazón: `x=16\sin^{3}t`, `y=13\cos t-5\cos2t-2\cos3t-\cos4t` | `x\in[-16,16]`; `y(\pi)=-17`; simétrico respecto al eje `y` |

---

## G10. Curvas polares

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GR-01 | N1 | `r=3` | Circunferencia de radio `3` |
| GR-02 | N1 | `r=2\cos\theta` | Circunferencia de centro `(1,0)` y radio `1`; se recorre una vez en `[0,\pi]` y dos en `[0,2\pi]` |
| GR-03 | N1 | `r=2\sin\theta` | Circunferencia de centro `(0,1)` y radio `1` |
| GR-04 | N1 | `\theta=\frac\pi4` | Recta `y=x` (con `r` de signo cualquiera) |
| GR-05 | N2 | `r=1+\cos\theta` | Cardioide: `r_{\max}=2` en `\theta=0`, cúspide en el origen; área `\frac{3\pi}{2}`; longitud `8` |
| GR-06 | N2 | `r=1-\sin\theta` | Cardioide hacia abajo: punto `(0,-2)`, cúspide en el origen |
| GR-07 | N2 | `r=2+\cos\theta` | Limaçon convexo; `r\in[1,3]` |
| GR-08 | N2 | `r=1+2\cos\theta` | Limaçon con **lazo interior**: `r=3` en `\theta=0`; el lazo aparece para `\theta\in\left(\frac{2\pi}{3},\frac{4\pi}{3}\right)` y llega a `(1,0)` |
| GR-09 | N2 | `r=\cos2\theta` | Rosa de 4 pétalos, punta en `\theta=0,\frac\pi2,\pi,\frac{3\pi}{2}`; área `\frac\pi2` |
| GR-10 | N2 | `r=\cos3\theta` | Rosa de 3 pétalos con puntas en `\theta=0,\frac{2\pi}{3},\frac{4\pi}{3}`; área `\frac\pi4` |
| GR-11 | N2 | `r=\sin2\theta` | Rosa de 4 pétalos girada `45^{\circ}` |
| GR-12 | N2 | `r=2\sin5\theta` | Rosa de 5 pétalos de longitud `2` |
| GR-13 | N3 | `r=\cos\frac{2\theta}{3},\ \theta\in[0,3\pi]` | Curva cerrada que necesita `3\pi` para completarse |
| GR-14 | N3 | `r^{2}=2\cos2\theta` | Lemniscata: válida donde `\cos2\theta\ge0`; Ix `\pm\sqrt{2}`; área `2` |
| GR-15 | N2 | `r=\theta,\ \theta\in[0,4\pi]` | Espiral de Arquímedes, separación `2\pi` entre vueltas |
| GR-16 | N2 | `r=e^{\theta/5},\ \theta\in[0,6\pi]` | Espiral logarítmica |
| GR-17 | N3 | `r=\frac1\theta,\ \theta\in(0,6\pi]` | Espiral hiperbólica con AH `y=1` cuando `\theta\to0^{+}` |
| GR-18 | N3 | `r=\frac{2}{1+\cos\theta}` | Parábola `y^{2}=4(1-x)`, foco en el origen, vértice `(1,0)`, abre hacia la izquierda |
| GR-19 | N3 | `r=\frac{6}{2+\cos\theta}` | Elipse `e=\frac12`: vértices `r=2` (en `\theta=0`) y `r=6` (en `\theta=\pi`), centro `(-2,0)`, `a=4` |
| GR-20 | N3 | `r=\frac{4}{1+2\cos\theta}` | Hipérbola `e=2` con dos ramas |
| GR-21 | N2 | `r=2\sec\theta` y `r=3\csc\theta` | Rectas `x=2` y `y=3` |
| GR-22 | N2 | Intersección de `r=1+\cos\theta` y `r=1` | Puntos `(0,1)` y `(0,-1)` (`\theta=\pm\frac\pi2`) |
| GR-23 | N2 | Intersección de `r=2\cos\theta` y `r=2\sin\theta` | El origen y `(1,1)` |
| GR-24 | N3 | Intersección de `r=3\cos\theta` y `r=1+\cos\theta` | El origen y `\left(\frac34,\pm\frac{3\sqrt3}{4}\right)\approx(0.75,\pm1.299)` |
| GR-25 | N3 | Área dentro de `r=3\cos\theta` y fuera de `r=1+\cos\theta` | `\pi` |
| GR-26 | N2 | Área de un pétalo de `r=\cos2\theta` | `\frac\pi8` |
| GR-27 | N3 | Área del lazo interior de `r=1+2\cos\theta` | `\pi-\frac{3\sqrt3}{2}\approx0.5435` |
| GR-28 | N2 | Puntos polares `\left(2,\frac\pi3\right)`, `\left(-2,\frac\pi3\right)`, `\left(3,-\frac\pi2\right)` | Cartesianos `(1,\sqrt3)`, `(-1,-\sqrt3)`, `(0,-3)` (el radio negativo se refleja) |
| GR-29 | N2 | Conversión de `r=4\cos\theta` | `(x-2)^{2}+y^{2}=4` |
| GR-30 | N2 | `r(\theta)=1+\cos\theta` graficada en ejes cartesianos `(\theta,r)` | Onda coseno desplazada, rango `[0,2]` |

---

## G11. Transformaciones, inversas, familias y otras aplicaciones

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GX-01 | N2 | `g(x)=-2(x-3)^{2}+1` a partir de `y=x^{2}` | Vértice `(3,1)`, abre hacia abajo, estiramiento `2` · Rg `(-\infty,1]` · Ix `3\pm\frac{\sqrt2}{2}` · Iy `-17` |
| GX-02 | N2 | `f(x)=\sqrt{x},\ g(x)=\sqrt{-x},\ h(x)=-\sqrt{x}` | Reflexiones: `g` en el eje `y` (Dom `(-\infty,0]`), `h` en el eje `x` (Rg `(-\infty,0]`) |
| GX-03 | N2 | `f(x)=x-1`, comparar `\lvert f(x)\rvert` y `f(\lvert x\rvert)` | `\lvert x-1\rvert` con vértice `(1,0)`; `\lvert x\rvert-1` con vértice `(0,-1)`, Ix `\pm1` |
| GX-04 | N2 | `f(x)=\sqrt{x},\ g(x)=x^{2}-4`: graficar `f\circ g` y `g\circ f` | `f\circ g=\sqrt{x^{2}-4}`, Dom `\lvert x\rvert\ge2`; `g\circ f=x-4`, Dom `[0,\infty)` (solo semirrecta) |
| GX-05 | N2 | `y=x^{3}+1` y su inversa `y=\sqrt[3]{x-1}` con la recta `y=x` | Simétricas respecto a `y=x`; intersección con `y=x` en `x\approx-1.3247` |
| GX-06 | N2 | `y=\frac{x+1}{x-2}` y su inversa | Inversa `y=\frac{2x+1}{x-1}`; AV y AH intercambiadas (`x=2,\ y=1` pasan a `x=1,\ y=2`) |
| GX-07 | N2 | Inversa de `y=x^{2}` restringida a `x\ge0`, e inversa de `y=e^{x}` | `y=\sqrt{x}` y `y=\ln x`, reflejadas en `y=x` |
| GX-08 | N2 | Paridad: `x^{4}-x^{2}` (par), `x^{3}-x` (impar), `x^{2}+x` (ni una ni otra) | Simetría respecto al eje `y`; respecto al origen; ninguna |
| GX-09 | N2 | Familia `y=x^{2}+c` con `c=-2,-1,0,1,2` | Traslaciones verticales con leyenda y colores distintos |
| GX-10 | N2 | Familia `y=\sin(kx)` con `k=1,2,3` | Periodos `2\pi,\ \pi,\ \frac{2\pi}{3}` |
| GX-11 | N3 | Control deslizante `a` en `y=ax^{2}`, `a\in[-3,3]` | Para `a=0` se ve la recta `y=0`; para `a<0` abre hacia abajo |
| GX-12 | N3 | Campo de pendientes de `y'=x-y` con la solución por `(0,1)` | Solución `y=x-1+2e^{-x}`; isoclinas `y=x-c` |
| GX-13 | N3 | Campo de pendientes de `y'=y(1-y)` | Equilibrios `y=0` (inestable) y `y=1` (estable); soluciones sigmoides con PI en `y=\frac12` |
| GX-14 | N3 | Campo de pendientes de `y'=-\frac{x}{y}` | Soluciones circulares `x^{2}+y^{2}=C` |
| GX-15 | N3 | Retrato de fase de `x'=y,\ y'=-x` | Circunferencias concéntricas (centro) |
| GX-16 | N3 | Retrato de fase de `x'=-x,\ y'=-2y` | Nodo estable (trayectorias hacia el origen) |
| GX-17 | N3 | Retrato de fase de `x'=x,\ y'=-y` | Punto silla; separatrices los ejes |
| GX-18 | N2 | Euler para `y'=y,\ y(0)=1,\ h=0.5` frente a `e^{x}` | Puntos de Euler `1,\ 1.5,\ 2.25,\ 3.375,\ 5.0625`; exactos `1,\ 1.6487,\ 2.7183,\ 4.4817,\ 7.3891` |
| GX-19 | N3 | Suma parcial de Fourier de la onda cuadrada: `\frac4\pi\sum_{k=1}^{N}\frac{\sin((2k-1)x)}{2k-1}` | Aproximación creciente; fenómeno de Gibbs: pico `\approx1.179` cerca de las discontinuidades |
| GX-20 | N2 | Recta de mínimos cuadrados por `(1,2),(2,3),(3,5),(4,4)` | `y=0.8x+1.5` |
| GX-21 | N2 | Parábola por `(0,1),(1,2),(2,5)` | `y=x^{2}+1` |
| GX-22 | N2 | Interpolación de Lagrange de `(0,0),(1,1),(2,8),(3,27)` | `y=x^{3}` |
| GX-23 | N2 | Densidad normal `N(0,1)` | Máx `\left(0,\frac{1}{\sqrt{2\pi}}\right)\approx(0,0.3989)`; PI en `\pm1` |
| GX-24 | N2 | Densidad normal `N(2,0.5^{2})` | Máx `\approx(2,\,0.7979)`; PI en `x=1.5` y `x=2.5` |
| GX-25 | N2 | Histograma de la binomial `n=10,\ p=0.5` | Barra más alta en `k=5` con `\frac{252}{1024}\approx0.2461` |
| GX-26 | N2 | Distribución de Poisson `\lambda=3` | `P(0)\approx0.0498`, `P(3)\approx0.2240` |
| GX-27 | N2 | Plano complejo: raíces de `z^{6}=1` | Hexágono regular inscrito en la circunferencia unitaria con un vértice en `(1,0)` |
| GX-28 | N3 | Conjunto de Mandelbrot: pertenencia de `c=0,\ -1,\ i,\ -2` y no pertenencia de `c=1` y `c=0.26` | `0,\ -1,\ i,\ -2` pertenecen (órbitas acotadas); `1` y `0.26` escapan |
| GX-29 | N3 | Imagen de la circunferencia `\lvert z\rvert=1` bajo `w=z^{2}` | La circunferencia unitaria recorrida **dos veces** |

---

## G12. Robustez y estrés de la graficación 2D

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| GZ-01 | N2 | `y=\tan x` en `[-2\pi,2\pi]\times[-10,10]` | Sin líneas verticales falsas en las asíntotas |
| GZ-02 | N2 | `y=\frac1x` en `[-5,5]` | Dos ramas separadas; sin segmento que cruce `x=0` |
| GZ-03 | N3 | `y=\sin\frac1x` en `[-0.1,0.1]` | Muestreo adaptativo: cada vez más ciclos hacia `0` |
| GZ-04 | N3 | `y=\sin(1000x)` en `[0,1]` | `\frac{1000}{2\pi}\approx159` ciclos completos; sin aliasing ni envolvente falsa |
| GZ-05 | N2 | `y=\frac{\sin x}{x}` | Hueco ○ en `(0,1)`; el resto de la curva continuo |
| GZ-06 | N3 | `y=x^{x}` para `x<0` | Solo existe el dominio real `x>0` (convención); no debe dibujar una curva continua inventada |
| GZ-07 | N3 | `y=x^{1/3}` para `x<0` | Debe declarar la convención: raíz real (curva en ambos lados) o solo `x\ge0` |
| GZ-08 | N2 | `y=\sqrt{x^{2}}` | Es `\lvert x\rvert` (no la recta `y=x`) |
| GZ-09 | N2 | `y=\ln\left(x^{2}\right)` frente a `y=2\ln x` | La primera: Dom `x\neq0` (par); la segunda: Dom `x>0` |
| GZ-10 | N3 | `y=\frac{x^{2}-1}{x^{2}-1}` | Recta `y=1` con dos huecos ○ en `(\pm1,1)` |
| GZ-11 | N3 | `y=\frac{\sin x}{\sin x}` | Recta `y=1` con huecos ○ en `x=k\pi` |
| GZ-12 | N2 | `y=\frac{1}{\ln x}` | Dom `x>0,\ x\neq1` · AV `x=1` · límite `0^{-}` en `0^{+}` (extremo ○ en el origen) |
| GZ-13 | N2 | `y=\sqrt{x(x-1)(x-2)}` | Dom `[0,1]\cup[2,\infty)` con hueco entre `1` y `2` |
| GZ-14 | N2 | `y=\sqrt{\sin x}` | Dom `[2k\pi,(2k+1)\pi]`; arcos separados |
| GZ-15 | N2 | `y=\ln(\sin x)` | Dom `(2k\pi,(2k+1)\pi)`; máximo `0` en `\frac\pi2`; AV en los extremos |
| GZ-16 | N2 | `y=e^{x}` en `[0,50]` | Valor hasta `\approx5.18\times10^{21}`; autoescala sin errores; con escala logarítmica en `y` es una recta de pendiente `1` |
| GZ-17 | N2 | `y=x^{2}` en ejes log-log | Recta de pendiente `2` |
| GZ-18 | N2 | `y=x^{100}` en `[-1.5,1.5]` | Plana cerca de `0` y muy empinada en `\pm1.5` |
| GZ-19 | N3 | Zoom a `y=x^{2}` en la ventana `[-10^{-6},10^{-6}]` | Parábola suave, sin escalones por precisión |
| GZ-20 | N3 | Polinomio de Wilkinson `p(x)=\prod_{k=1}^{20}(x-k)` | Ceros en `1,\dots,20`; `p(0)=20!\approx2.4329\times10^{18}`; sensibilidad numérica |
| GZ-21 | N2 | Circunferencia `x^{2}+y^{2}=4` en ventana `16:9` | Debe verse circular (aspecto `1:1`) |
| GZ-22 | N2 | 20 curvas `y=\sin\left(x+\frac{k\pi}{10}\right),\ k=0,\dots,19` | Colores distintos, leyenda legible, sin sobrecarga de render |
| GZ-23 | N2 | Etiquetas de intersección de `y=x^{2}` y `y=x+2` | Etiquetas `(-1,1)` y `(2,4)` |
| GZ-24 | N2 | Lectura de coordenadas sobre `y=\ln x` en `x=1` | `(1,0)` exacto en el cursor |
| GZ-25 | N3 | `y=\operatorname{sgn}(x)` y `y=\frac{x}{\lvert x\rvert}` | Mismos dos tramos; ○ en `x=0` para la segunda |

---

# PARTE H — GRAFICACIÓN 3D

## H1. Superficies `z=f(x,y)` y cuádricas

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| SF-01 | N1 | `2x+3y+z=6` | Plano con interceptos `(3,0,0)`, `(0,2,0)`, `(0,0,6)` |
| SF-02 | N1 | `z=x^{2}+y^{2}` | Paraboloide circular · vértice `(0,0,0)` · Rg `z\ge0` · trazas `z=k` son circunferencias de radio `\sqrt{k}` |
| SF-03 | N1 | `z=4-x^{2}-y^{2}` | Paraboloide hacia abajo · vértice `(0,0,4)` · corta `z=0` en la circunferencia `r=2` |
| SF-04 | N2 | `z=x^{2}-y^{2}` | Paraboloide hiperbólico (silla) · traza `z=0`: rectas `y=\pm x` |
| SF-05 | N2 | `z=xy` | Silla · traza `z=0`: los ejes `x` e `y` |
| SF-06 | N2 | `z=\sqrt{x^{2}+y^{2}}` | Cono con vértice en el origen · Rg `z\ge0` |
| SF-07 | N2 | `z=\sqrt{9-x^{2}-y^{2}}` | Hemisferio superior de radio `3` · Dom `x^{2}+y^{2}\le9` · Rg `[0,3]` |
| SF-08 | N2 | `x^{2}+y^{2}+z^{2}=9` | Esfera · interceptos `(\pm3,0,0)`, `(0,\pm3,0)`, `(0,0,\pm3)` |
| SF-09 | N2 | `\frac{x^{2}}{4}+\frac{y^{2}}{9}+\frac{z^{2}}{16}=1` | Elipsoide `a=2,\ b=3,\ c=4`; volumen `32\pi` |
| SF-10 | N2 | `x^{2}+y^{2}-z^{2}=1` | Hiperboloide de una hoja · garganta `r=1` en `z=0` |
| SF-11 | N2 | `z^{2}-x^{2}-y^{2}=1` | Hiperboloide de dos hojas · vértices `(0,0,\pm1)` |
| SF-12 | N2 | `x^{2}+y^{2}=z^{2}` | Cono doble con vértice en el origen |
| SF-13 | N1 | `y=x^{2}` en 3D | Cilindro parabólico extendido a lo largo de `z` |
| SF-14 | N1 | `x^{2}+y^{2}=4` en 3D | Cilindro circular de radio `2` |
| SF-15 | N2 | `z=\sin x\cos y` | Superficie periódica ("caja de huevos") · Rg `[-1,1]` |
| SF-16 | N3 | `z=\frac{\sin\sqrt{x^{2}+y^{2}}}{\sqrt{x^{2}+y^{2}}}` | Sombrero mexicano · valor `1` en el origen (sin agujero) · Rg `\approx[-0.2172,1]` |
| SF-17 | N2 | `z=e^{-(x^{2}+y^{2})}` | Campana gaussiana · Máx `(0,0,1)` · Rg `(0,1]` |
| SF-18 | N3 | `z=x^{3}-3xy^{2}` | Silla de mono (tres valles) · es `\operatorname{Re}\left((x+iy)^{3}\right)` |
| SF-19 | N2 | `z=\lvert x\rvert+\lvert y\rvert` | Pirámide invertida con aristas sobre los ejes · vértice `(0,0,0)` |
| SF-20 | N3 | `z=\frac{1}{x^{2}+y^{2}}` | Dom `(x,y)\neq(0,0)` · Rg `(0,\infty)` · recorte de valores grandes sin picos falsos |
| SF-21 | N3 | `z=\ln\left(x^{2}+y^{2}\right)` | Dom `(x,y)\neq(0,0)` · Rg `\mathbb{R}` · embudo hacia `-\infty` |
| SF-22 | N3 | `z=xe^{-x^{2}-y^{2}}` | Máx `\left(\frac{\sqrt2}{2},0,0.4289\right)` y Mín `\left(-\frac{\sqrt2}{2},0,-0.4289\right)` |
| SF-23 | N2 | `z=x^{2}+y^{2},\ x\in[0,1],\ y\in[0,2]` | Trozo rectangular del paraboloide con bordes bien recortados |
| SF-24 | N3 | `z=\begin{cases}x^{2}+y^{2}&\text{si }x^{2}+y^{2}\le1\\ 2-x^{2}-y^{2}&\text{si }x^{2}+y^{2}>1\end{cases}` | Continua (`z=1` en `r=1`) con arista en la circunferencia; cae a `-\infty` fuera |
| SF-25 | N3 | `\left(\sqrt{x^{2}+y^{2}}-3\right)^{2}+z^{2}=1` | Toro `R=3,\ r=1` (superficie implícita) |
| SF-26 | N3 | `x^{4}+y^{4}+z^{4}=1` | Superelipsoide, aspecto de cubo redondeado |
| SF-27 | N3 | `\left(x^{2}+\frac94y^{2}+z^{2}-1\right)^{3}-x^{2}z^{3}-\frac{9}{80}y^{2}z^{3}=0` | Corazón 3D (superficie implícita), ventana `[-1.5,1.5]^{3}` |
| SF-28 | N3 | `\sin x\cos y+\sin y\cos z+\sin z\cos x=0` | Giroide (superficie periódica), ventana `[-2\pi,2\pi]^{3}` |
| SF-29 | N3 | `\cos x+\cos y+\cos z=0` | Superficie P de Schwarz (periódica) |

---

## H2. Curvas de nivel, gradiente, extremos y planos tangentes

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| SN-01 | N1 | Curvas de nivel de `z=x^{2}+y^{2}` para `c=1,\ 4,\ 9` | Circunferencias de radio `1,\ 2,\ 3` |
| SN-02 | N2 | Curvas de nivel de `z=x^{2}-y^{2}` | Hipérbolas `x^{2}-y^{2}=c`; para `c=0`, las rectas `y=\pm x` |
| SN-03 | N1 | Curvas de nivel de `z=xy` | Hipérbolas `xy=c` |
| SN-04 | N1 | Curvas de nivel de `z=x+2y` y su gradiente | Rectas paralelas; `\nabla z=(1,2)` constante, perpendicular a ellas |
| SN-05 | N2 | Curvas de nivel de `z=e^{-(x^{2}+y^{2})}` | Circunferencias; `c=e^{-1}` corresponde a `r=1` |
| SN-06 | N3 | Curvas de nivel de `z=\sin x\sin y` | Celdas alternadas; puntos críticos en `\left(\frac\pi2+k\pi,\frac\pi2+m\pi\right)` |
| SN-07 | N2 | Campo gradiente de `f=x^{2}+y^{2}` | `\nabla f=(2x,2y)`, radial; en `(1,2)` vale `(2,4)` con módulo `2\sqrt{5}` |
| SN-08 | N2 | Derivada direccional de `f=x^{2}+y^{2}` en `(1,1)` hacia `\frac{(1,1)}{\sqrt2}` | `2\sqrt{2}\approx2.8284` |
| SN-09 | N2 | Campo gradiente de `f=xy` | `\nabla f=(y,x)` |
| SN-10 | N2 | Puntos críticos de `f=x^{2}-y^{2}` | `(0,0)` silla (discriminante `-4`) |
| SN-11 | N2 | Puntos críticos de `f=x^{2}+y^{2}-2x-4y+5` | `(1,2)` mínimo, `f=0` |
| SN-12 | N3 | Puntos críticos de `f=x^{3}-3x+y^{2}` | `(1,0)` mínimo local `f=-2`; `(-1,0)` silla `f=2` |
| SN-13 | N3 | Puntos críticos de `f=x^{3}+y^{3}-3xy` | `(0,0)` silla; `(1,1)` mínimo local `f=-1` |
| SN-14 | N3 | `f=\left(x^{2}+y^{2}\right)e^{-(x^{2}+y^{2})}` | Mínimo `0` en el origen; **anillo de máximos** en `r=1` con valor `e^{-1}\approx0.3679` |
| SN-15 | N3 | Lagrange: extremos de `f=xy` con `x^{2}+y^{2}=2` | Máx `1` en `(1,1)` y `(-1,-1)`; mín `-1` en `(1,-1)` y `(-1,1)`; las curvas `xy=c` son tangentes a la circunferencia |
| SN-16 | N3 | Lagrange: mínimo de `x^{2}+y^{2}` con `x+y=2` | `(1,1)`, valor `2`; circunferencia `r=\sqrt2` tangente a la recta |
| SN-17 | N2 | Plano tangente a `z=x^{2}+y^{2}` en `(1,2,5)` | `z=5+2(x-1)+4(y-2)`, es decir `2x+4y-z=5`; normal `(2,4,-1)` |
| SN-18 | N3 | Plano tangente a `z=\sqrt{9-x^{2}-y^{2}}` en `(1,2,2)` | `x+2y+2z=9` |
| SN-19 | N2 | Plano tangente a `x^{2}+y^{2}+z^{2}=14` en `(1,2,3)` | `x+2y+3z=14`; recta normal `(1,2,3)+t(1,2,3)` |
| SN-20 | N3 | Linealización de `f=\sqrt{x^{2}+y^{2}}` en `(3,4)` | `L(x,y)=5+\frac35(x-3)+\frac45(y-4)`; `L(3.1,3.9)=4.98` frente a `\approx4.98197` |
| SN-21 | N2 | Superficies de nivel de `f=x^{2}+y^{2}+z^{2}` con `k=1,\ 4,\ 9` | Esferas de radio `1,\ 2,\ 3` (`k=0`: un punto; `k<0`: vacía) |
| SN-22 | N2 | Superficies de nivel de `f=x^{2}+y^{2}-z^{2}` | `k>0` una hoja; `k=0` cono; `k<0` dos hojas |
| SN-23 | N2 | Superficies de nivel de `f=x+2y+3z` | Planos paralelos |
| SN-24 | N2 | Superficies de nivel de `f=x^{2}+y^{2}-z` | Paraboloides desplazados `z=x^{2}+y^{2}-k` |
| SN-25 | N2 | Cortes del elipsoide `\frac{x^{2}}{4}+\frac{y^{2}}{9}+\frac{z^{2}}{16}=1` con `z=0`, `x=0`, `z=2` | Elipse `\frac{x^{2}}{4}+\frac{y^{2}}{9}=1`; elipse `\frac{y^{2}}{9}+\frac{z^{2}}{16}=1`; elipse `\frac{x^{2}}{4}+\frac{y^{2}}{9}=\frac34` |

---

## H3. Curvas en el espacio

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| CU-01 | N1 | `\mathbf{r}(t)=(\cos t,\ \sin t,\ t),\ t\in[0,4\pi]` | Hélice de radio `1` y paso `2\pi`; longitud `4\pi\sqrt{2}\approx17.7715` |
| CU-02 | N2 | `\mathbf{r}(t)=(t,\ t^{2},\ t^{3}),\ t\in[-1,1]` | Cúbica alabeada; pasa por el origen; proyección sobre `xy` es una parábola |
| CU-03 | N1 | `\mathbf{r}(t)=(2\cos t,\ 2\sin t,\ 3)` | Circunferencia de radio `2` a la altura `z=3`; longitud `4\pi` |
| CU-04 | N2 | `\mathbf{r}(t)=(t\cos t,\ t\sin t,\ t),\ t\in[0,6\pi]` | Hélice cónica sobre el cono `z=\sqrt{x^{2}+y^{2}}` |
| CU-05 | N3 | `\mathbf{r}(t)=(1+\cos t,\ \sin t,\ 2\sin\frac t2),\ t\in[0,4\pi]` | Curva de Viviani: intersección de la esfera `x^{2}+y^{2}+z^{2}=4` y el cilindro `(x-1)^{2}+y^{2}=1` |
| CU-06 | N3 | `\mathbf{r}(t)=\left((2+\cos3t)\cos2t,\ (2+\cos3t)\sin2t,\ \sin3t\right),\ t\in[0,2\pi]` | Nudo de trébol sobre el toro `R=2,\ r=1` |
| CU-07 | N2 | Intersección de `z=x^{2}+y^{2}` con el plano `z=2x` | `\mathbf{r}(t)=(1+\cos t,\ \sin t,\ 2+2\cos t)`; elipse plana |
| CU-08 | N2 | Intersección del cilindro `x^{2}+y^{2}=1` con el plano `z=x+y` | `\mathbf{r}(t)=(\cos t,\sin t,\cos t+\sin t)`; elipse con `z\in[-\sqrt2,\sqrt2]` |
| CU-09 | N3 | Triedro de Frenet de la hélice `(\cos t,\sin t,t)` en `t=0` | `\mathbf{T}=\frac{(0,1,1)}{\sqrt2}`, `\mathbf{N}=(-1,0,0)`, `\mathbf{B}=\frac{(0,-1,1)}{\sqrt2}`; `\kappa=\tau=\frac12` |
| CU-10 | N2 | Recta tangente a la hélice en `t=\frac\pi2` | Punto `\left(0,1,\frac\pi2\right)`, velocidad `(-1,0,1)`; recta `(-s,\ 1,\ \frac\pi2+s)` |
| CU-11 | N3 | Atractor de Lorenz: `x'=10(y-x),\ y'=x(28-z)-y,\ z'=xy-\frac83z` | Dos "alas" de mariposa; equilibrios `(0,0,0)` y `(\pm\sqrt{72},\pm\sqrt{72},27)\approx(\pm8.485,\pm8.485,27)` |
| CU-12 | N2 | Intersección de los planos `x+y+z=6`, `x-y=0`, `z=2` | Punto `(2,2,2)` |

---

## H4. Superficies paramétricas

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| SP-01 | N2 | Esfera: `(R\sin\varphi\cos\theta,\ R\sin\varphi\sin\theta,\ R\cos\varphi),\ \varphi\in[0,\pi],\ \theta\in[0,2\pi]` | Sin agujeros en los polos; área `4\pi R^{2}` |
| SP-02 | N2 | Toro: `((R+r\cos v)\cos u,\ (R+r\cos v)\sin u,\ r\sin v)`, `R=3,\ r=1` | Área `12\pi^{2}\approx118.435`; volumen `6\pi^{2}\approx59.218` |
| SP-03 | N1 | Cilindro: `(\cos u,\ \sin u,\ v),\ v\in[0,3]` | Área lateral `6\pi` |
| SP-04 | N1 | Cono: `(v\cos u,\ v\sin u,\ v),\ v\in[0,1]` | Área lateral `\pi\sqrt{2}\approx4.4429` |
| SP-05 | N2 | Helicoide: `(u\cos v,\ u\sin v,\ v),\ u\in[-1,1],\ v\in[0,4\pi]` | Rampa helicoidal doble |
| SP-06 | N2 | Catenoide: `(\cosh v\cos u,\ \cosh v\sin u,\ v),\ v\in[-1,1]` | Área `2\pi\left(1+\frac{\sinh2}{2}\right)\approx17.677` |
| SP-07 | N3 | Banda de Möbius: `\left(\left(1+\frac v2\cos\frac u2\right)\cos u,\ \left(1+\frac v2\cos\frac u2\right)\sin u,\ \frac v2\sin\frac u2\right),\ u\in[0,2\pi],\ v\in[-1,1]` | Una sola cara y un solo borde; normal que se invierte al recorrer una vuelta |
| SP-08 | N3 | Botella de Klein (inmersión "figura 8"): `x=\left(2+\cos\frac u2\sin v-\sin\frac u2\sin2v\right)\cos u`, `y=\left(2+\cos\frac u2\sin v-\sin\frac u2\sin2v\right)\sin u`, `z=\sin\frac u2\sin v+\cos\frac u2\sin2v` | Superficie cerrada con autointersección, `u,v\in[0,2\pi]` |
| SP-09 | N3 | Superficie de Enneper: `\left(u-\frac{u^{3}}{3}+uv^{2},\ v-\frac{v^{3}}{3}+vu^{2},\ u^{2}-v^{2}\right),\ u,v\in[-1.5,1.5]` | Autointersección visible en las orillas |
| SP-10 | N2 | Paraboloide: `(u\cos v,\ u\sin v,\ u^{2})` | Coincide con `z=x^{2}+y^{2}` |
| SP-11 | N2 | Elipsoide: `(2\sin\varphi\cos\theta,\ 3\sin\varphi\sin\theta,\ 4\cos\varphi)` | Volumen encerrado `32\pi` |
| SP-12 | N3 | Superficie de Dini: `(\cos u\sin v,\ \sin u\sin v,\ \cos v+\ln\tan\frac v2+0.2u)` | Pseudoesfera retorcida; singularidad controlada en `v\to0` |
| SP-13 | N3 | Conoide de Plücker: `(u\cos v,\ u\sin v,\ \sin2v)` | Superficie reglada con dos "pliegues" |
| SP-14 | N2 | Normal a la esfera unitaria en `\theta=\frac\pi4,\ \varphi=\frac\pi2` | Punto `\left(\frac{\sqrt2}{2},\frac{\sqrt2}{2},0\right)`; la normal tiene la misma dirección que el vector de posición |

---

## H5. Sólidos de revolución y superficies de revolución

En cada ejercicio debe verse la región plana, el eje de giro y el sólido generado (ideal: rebanadas o discos/anillos/cascarones visibles).

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| SR-01 | N1 | `y=\sqrt{x},\ 0\le x\le4`, giro alrededor del eje `x` | Paraboloide; `V=8\pi\approx25.1327` |
| SR-02 | N1 | `y=x^{2},\ 0\le x\le2`, giro alrededor del eje `x` | `V=\frac{32\pi}{5}\approx20.1062` |
| SR-03 | N2 | Región entre `y=x` y `y=x^{2}` en `[0,1]`, giro alrededor del eje `x` (anillos) | `V=\frac{2\pi}{15}\approx0.41888` |
| SR-04 | N2 | `y=x^{2},\ 0\le x\le2`, giro alrededor del eje `y` (cascarones) | `V=8\pi\approx25.1327` |
| SR-05 | N2 | Región entre `y=x^{2}` y `y=\sqrt{x}`, giro alrededor del eje `y` | `V=\frac{3\pi}{10}\approx0.94248` |
| SR-06 | N2 | `y=\sin x,\ 0\le x\le\pi`, giro alrededor del eje `x` | `V=\frac{\pi^{2}}{2}\approx4.9348` |
| SR-07 | N2 | `y=\cos x,\ 0\le x\le\frac\pi2`, giro alrededor del eje `x` | `V=\frac{\pi^{2}}{4}\approx2.4674` |
| SR-08 | N3 | `y=e^{-x},\ x\ge0`, giro alrededor del eje `x` | `V=\frac\pi2\approx1.5708` (sólido infinito de volumen finito) |
| SR-09 | N3 | `y=\frac1x,\ x\ge1`, giro alrededor del eje `x` (cuerno de Gabriel) | `V=\pi`; área superficial **infinita** |
| SR-10 | N2 | `y=\sqrt{4-x^{2}}`, giro alrededor del eje `x` | Esfera de radio `2`: `V=\frac{32\pi}{3}\approx33.5103`; `S=16\pi\approx50.2655` |
| SR-11 | N2 | `y=\frac34x,\ 0\le x\le4`, giro alrededor del eje `x` | Cono `r=3,\ h=4`: `V=12\pi\approx37.6991`; área lateral `15\pi\approx47.1239` |
| SR-12 | N2 | Circunferencia `(x-2)^{2}+y^{2}=1`, giro alrededor del eje `y` | Toro: `V=4\pi^{2}\approx39.4784`; `S=8\pi^{2}\approx78.9568` (Pappus) |
| SR-13 | N3 | `y=x^{2},\ 0\le x\le1`, giro alrededor de la recta `y=-1` | `V=\frac{13\pi}{15}\approx2.7227` |
| SR-14 | N3 | Región entre `y=x` y `y=x^{2}`, giro alrededor de la recta `y=2` | `V=\frac{8\pi}{15}\approx1.6755` |
| SR-15 | N3 | Región bajo `y=x^{2}` en `[0,1]`, giro alrededor de la recta `x=2` | `V=\frac{5\pi}{6}\approx2.6180` |
| SR-16 | N3 | Región entre `y=x` y `y=x^{2}`, giro alrededor de la recta `x=-1` | `V=\frac\pi2\approx1.5708` |
| SR-17 | N2 | `y=x^{3},\ 0\le x\le1`, giro alrededor del eje `y` | `V=\frac{2\pi}{5}\approx1.2566` |
| SR-18 | N2 | Región entre `y=4-x^{2}` y el eje `x`, giro alrededor del eje `x` | `V=\frac{512\pi}{15}\approx107.233` |
| SR-19 | N2 | Misma región, giro alrededor del eje `y` | `V=8\pi\approx25.1327` |
| SR-20 | N3 | Área de superficie: `y=x^{3},\ 0\le x\le1`, giro alrededor del eje `x` | `S=\frac{\pi}{27}\left(10\sqrt{10}-1\right)\approx3.5631` |
| SR-21 | N3 | Área de superficie: `y=\sqrt{x},\ 0\le x\le4`, giro alrededor del eje `x` | `S=\frac\pi6\left(17\sqrt{17}-1\right)\approx36.177` |
| SR-22 | N3 | Área de superficie: `y=\sin x,\ 0\le x\le\pi`, giro alrededor del eje `x` | `S=2\pi\left[\sqrt2+\operatorname{arsinh}1\right]\approx14.4236` |
| SR-23 | N3 | Superficie de revolución parametrizada de `y=2+\sin x`, `x\in[0,2\pi]`, alrededor del eje `x` | `\left(u,\ (2+\sin u)\cos v,\ (2+\sin u)\sin v\right)`, florero ondulado |
| SR-24 | N2 | Florero: `r(z)=1+0.5\sin(2z),\ z\in[0,\pi]`, giro alrededor del eje `z` | Superficie de revolución con cuello ondulado |

---

## H6. Sólidos por secciones, integrales múltiples y sólidos de Riemann

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| SV-01 | N2 | Base `x^{2}+y^{2}\le1`; secciones perpendiculares al eje `x` que son **cuadrados** | `V=\frac{16}{3}\approx5.3333` |
| SV-02 | N2 | Misma base; secciones **semicírculos** | `V=\frac{2\pi}{3}\approx2.0944` |
| SV-03 | N2 | Misma base; secciones **triángulos equiláteros** | `V=\frac{4\sqrt3}{3}\approx2.3094` |
| SV-04 | N2 | Base entre `y=x` y `y=x^{2}`; secciones cuadradas perpendiculares a `x` | `V=\frac1{30}\approx0.0333` |
| SV-05 | N3 | Dos cilindros `x^{2}+y^{2}\le1` y `x^{2}+z^{2}\le1` (intersección) | `V=\frac{16}{3}\approx5.3333` (sólido de Steinmetz) |
| SV-06 | N3 | Tres cilindros `x^{2}+y^{2}\le1`, `x^{2}+z^{2}\le1`, `y^{2}+z^{2}\le1` | `V=8(2-\sqrt2)\approx4.6863` |
| SV-07 | N2 | `0\le z\le4-x^{2}-y^{2}` | Casquete de paraboloide; `V=8\pi\approx25.1327` |
| SV-08 | N2 | `\sqrt{x^{2}+y^{2}}\le z\le1` | Cono con tapa; `V=\frac\pi3\approx1.0472` |
| SV-09 | N3 | `\sqrt{x^{2}+y^{2}}\le z\le\sqrt{2-x^{2}-y^{2}}` | "Cono de helado"; `V=\frac{4\pi}{3}\left(\sqrt2-1\right)\approx1.7350` |
| SV-10 | N3 | `\sqrt{x^{2}+y^{2}}\le z\le6-x^{2}-y^{2}` | Intersección en `r=2,\ z=2`; `V=\frac{32\pi}{3}\approx33.5103` |
| SV-11 | N2 | Región `x,y,z\ge0,\ x+y+z\le1` | Tetraedro; `V=\frac16\approx0.1667` |
| SV-12 | N2 | Región `\lvert x\rvert+\lvert y\rvert+\lvert z\rvert\le1` | Octaedro; `V=\frac43` |
| SV-13 | N2 | Esfera `x^{2}+y^{2}+z^{2}\le4` con `z\ge1` | Casquete de altura `1`; `V=\frac{5\pi}{3}\approx5.2360` |
| SV-14 | N2 | Volumen bajo `z=x+y` sobre `[0,1]\times[0,1]` | `V=1` |
| SV-15 | N3 | Volumen bajo `z=\sin x\sin y` sobre `[0,\pi]\times[0,\pi]` | `V=4` |
| SV-16 | N3 | Volumen entre `z=x^{2}+y^{2}` y `z=2x` | Disco `(x-1)^{2}+y^{2}\le1`; `V=\frac\pi2\approx1.5708` |
| SV-17 | N3 | Volumen bajo `z=e^{-(x^{2}+y^{2})}` sobre todo `\mathbb{R}^{2}` | `V=\pi\approx3.1416` |
| SV-18 | N2 | Riemann 3D: `f(x,y)=x^{2}+y^{2}` sobre `[0,2]\times[0,2]`, `m=n=2`, **esquina inferior izquierda** | 4 prismas de base `1\times1`; suma `4` |
| SV-19 | N2 | Ídem, **esquina superior derecha** | Suma `20` |
| SV-20 | N2 | Ídem, **punto medio** | Suma `10` |
| SV-21 | N2 | Riemann 3D de la misma función con `m=n=4` (celdas de `0.5\times0.5`): esquina inferior izquierda, punto medio, esquina superior derecha | `7`, `10.5`, `15`; valor exacto `\frac{32}{3}\approx10.6667` |
| SV-22 | N2 | Riemann 3D: `f(x,y)=xy` sobre `[0,1]\times[0,1]`, `m=n=2`, punto medio | Suma `0.25`, igual al valor exacto `\frac14` |
| SV-23 | N3 | Convergencia: `x^{2}+y^{2}` sobre `[0,2]^{2}` con `m=n=2,\ 4,\ 8,\ 16` (animación o deslizador) | Las sumas tienden a `\frac{32}{3}`; el error de la esquina inferior izquierda y la superior derecha decrece como `\frac{1}{n}` |
| SV-24 | N2 | Área de la gráfica de `z=x^{2}+y^{2}` con `r\le1` | `\frac\pi6\left(5\sqrt5-1\right)\approx5.3304` |
| SV-25 | N2 | Área del hemisferio `z=\sqrt{1-x^{2}-y^{2}}` | `2\pi\approx6.2832` |
| SV-26 | N2 | Área del cono `z=\sqrt{x^{2}+y^{2}}` con `r\le1` | `\pi\sqrt2\approx4.4429` |
| SV-27 | N2 | Área del plano `z=x+y` sobre `[0,1]\times[0,1]` | `\sqrt3\approx1.7321` |

---

## H7. Coordenadas cilíndricas y esféricas, planos, campos vectoriales

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| SC-01 | N1 | Cilíndricas: `r=2`, `z=r`, `z=r^{2}` | Cilindro, cono, paraboloide |
| SC-02 | N2 | Cilíndricas: `r=2\cos\theta` | Cilindro desplazado con eje en `(1,0)` y radio `1` |
| SC-03 | N1 | Esféricas: `\rho=2`, `\varphi=\frac\pi4`, `\theta=\frac\pi3` | Esfera de radio `2`; cono de semiángulo `45^{\circ}`; semiplano |
| SC-04 | N3 | Esféricas: `\rho=2\cos\varphi` | Esfera de centro `(0,0,1)` y radio `1`: `x^{2}+y^{2}+z^{2}=2z` |
| SC-05 | N3 | Esféricas: `\rho=1+\cos\varphi` | Superficie de revolución en forma de manzana, hundimiento en el polo sur |
| SC-06 | N2 | Cilíndricas: cilindro cardioide `r=1+\cos\theta,\ z\in[0,2]` | Cardioide extruida |
| SC-07 | N2 | Conversión de `(\rho,\theta,\varphi)=\left(2,\frac\pi4,\frac\pi3\right)` | `(x,y,z)=\left(\frac{\sqrt6}{2},\frac{\sqrt6}{2},1\right)\approx(1.2247,1.2247,1)` |
| SC-08 | N2 | Campo `\mathbf{F}=(x,y,z)` | Flechas radiales; `\nabla\cdot\mathbf{F}=3` |
| SC-09 | N2 | Campo `\mathbf{F}=(-y,x,0)` | Rotación alrededor del eje `z`; `\nabla\times\mathbf{F}=(0,0,2)` |
| SC-10 | N3 | Líneas de corriente de `\mathbf{F}=(-y,x,1)` | Hélices ascendentes |
| SC-11 | N2 | Sistema `\begin{cases}x+y+z=6\\ x-y+z=2\\ 2x+y-z=1\end{cases}` | Tres planos que se cortan en el punto `(1,2,3)` |
| SC-12 | N2 | Sistema `\begin{cases}x+y+z=1\\ x+y+z=2\end{cases}` | Planos paralelos: sin solución |
| SC-13 | N3 | Sistema `\begin{cases}x+y+z=3\\ x-y=1\\ 2x+z=4\end{cases}` | La tercera ecuación es suma de las otras dos: los planos comparten una recta `(t,\ t-1,\ 4-2t)` |
| SC-14 | N2 | Recta `(t,2t,3t)` y plano `x+y+z=12` | Intersección en `t=2`: `(2,4,6)` |
| SC-15 | N2 | Cubo `[0,1]^{3}` en alambre | 8 vértices, 12 aristas, diagonal `\sqrt3` |

---

## H8. Robustez y estrés de la graficación 3D

| ID | Nivel | Ejercicio | Verificación |
|---|---|---|---|
| RZ-01 | N3 | `z=\tan x+\tan y` | Asíntotas verticales recortadas, sin picos ni láminas falsas |
| RZ-02 | N3 | `z=\frac{1}{x^{2}+y^{2}}` con recorte `z\le10` | Embudo cortado limpio en `z=10`; ningún valor infinito dibujado |
| RZ-03 | N3 | `z=\sin10x\cos10y` en `[-\pi,\pi]^{2}` | `10` ciclos por eje; malla suficiente para no deformar los máximos |
| RZ-04 | N3 | `z=\sqrt{x^{2}-y^{2}}` | Dom `\lvert x\rvert\ge\lvert y\rvert` (dos cuñas); el resto sin superficie |
| RZ-05 | N3 | `z=\ln(xy)` | Dom `xy>0` (primer y tercer cuadrantes) |
| RZ-06 | N2 | `z=\sqrt{x}+\sqrt{y}` | Dom `x\ge0,\ y\ge0`; Rg `[0,\infty)` |
| RZ-07 | N3 | `z=\sin\left(x^{2}+y^{2}\right)` en `[-5,5]^{2}` | Anillos concéntricos cada vez más finos hacia el exterior (necesita malla fina) |
| RZ-08 | N3 | `z=e^{x+y}` en `[0,10]^{2}` | Alcanza `e^{20}\approx4.85\times10^{8}`; autoescala o escala logarítmica en `z` |
| RZ-09 | N2 | `z=5` y `x=2` | Plano horizontal y plano vertical (este último como superficie implícita) |
| RZ-10 | N3 | `z=x^{2}+y^{2}` y `z=4` en la misma escena | Intersección: circunferencia `r=2` a altura `4`; sin z-fighting |
| RZ-11 | N2 | Esfera `x^{2}+y^{2}+z^{2}=1` en ventana `16:9` | Debe verse esférica (relación `1:1:1`), no elipsoidal |
| RZ-12 | N2 | Verificación de ejes | `x` hacia la derecha, `y` hacia adentro, `z` hacia arriba (mano derecha) con etiquetas |
| RZ-13 | N3 | Polos de la esfera paramétrica y vértice del cono | Sin agujeros; normal indefinida en el vértice sin artefactos de sombreado |
| RZ-14 | N3 | Atractor de Lorenz con `10^{5}` puntos | Se dibuja sin bloqueo y mantiene la fluidez al rotar |
| RZ-15 | N3 | Cuadrícula `200\times200` de `z=\sin x\cos y` | Tiempo de render razonable y rotación fluida |

---

## Plantilla de registro de resultados (copiar y completar)

| ID | Lite | Plus | Código de fallo | Observaciones |
|---|:-:|:-:|---|---|
| GA-01 | ☐ | ☐ |  |  |
| GP-01 | ☐ | ☐ |  |  |
| SR-01 | ☐ | ☐ |  |  |

Marcar con ✓ si cumple, ✗ si falla y – si no aplica o no está soportado.
