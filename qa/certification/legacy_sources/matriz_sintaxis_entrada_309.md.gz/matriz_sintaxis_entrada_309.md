# Matriz de estrés — Entrada y sintaxis

Verifica **cómo interpreta la calculadora lo que se escribe**: multiplicación implícita, potencias de funciones, exponentes de varios dígitos, alias en español, Unicode, delimitadores, formatos de matrices y sistemas, ida y vuelta de la salida, y entradas hostiles. Es el origen más frecuente de errores silenciosos.

**Total: 309 ejercicios** (N1: 104 · N2: 183 · N3: 22).

## Cómo usar esta matriz

1. Escribir la columna **Entrada** en Lite y en Plus.
2. Comparar con **Resultado esperado** según el tipo de comparación (tabla siguiente).
3. Registrar `✓`, `✗` o `–` (no soportado) por motor y clasificar toda diferencia entre Lite y Plus como **PARIDAD**, **DIFERENCIA INTENCIONAL** o **GAP**.
4. Cada fallo se convierte en un caso de regresión permanente.

**Formato ejecutable:** los mismos ejercicios están en `matrices_ejecutables.jsonl` (una línea JSON por ejercicio), listos para un ejecutor automático (Playwright en Lite, API en Plus).

## Tipos de comparación

| Valor de `comparacion` | Qué se verifica |
|---|---|
| `numerica_o_exacta` | Valor numérico (tolerancia relativa `10^{-9}`) o exacto cuando es racional o entero. |
| `equivalencia_simbolica` | Equivalencia: la diferencia con el esperado se simplifica a `0`, o coincide en puntos de prueba aleatorios. |
| `forma_factorizada` | Equivalencia **y** que la expresión esté efectivamente factorizada (producto de factores irreducibles). |
| `conjunto_solucion` | Mismo conjunto de soluciones (valores, intervalos o tuplas), sin importar el orden ni el nombre del parámetro. |
| `conjunto_salvo_escalares` | Mismos valores propios con multiplicidad; vectores propios iguales salvo múltiplos escalares. |
| `estructura` | La interpretación sintáctica es la indicada (por ejemplo, `3\cdot\sin(x)` y no `\sin(3x)`). |
| `convencion_declarada` | Cualquiera de las lecturas válidas se acepta **si la interfaz declara cuál usó**. Elegir una en silencio es fallo. |
| `aviso_de_error` | Mensaje claro y sin valor numérico falso. No debe bloquearse ni ejecutar código. |

## Campos del archivo JSONL

| Campo | Contenido |
|---|---|
| `id` | Identificador único (por ejemplo `SY-P-03`). |
| `matriz` | Código de la matriz: `SY`, `MV` o `AS`. |
| `seccion` | Código de la sección. |
| `nivel` | `N1` básico, `N2` intermedio, `N3` desafío. |
| `operacion` | Qué se pide (`valor`, `det`, `inversa`, `factorizar`, `resolver`, ...). |
| `comparacion` | Cómo comparar el resultado (ver tabla). |
| `entrada` | LaTeX que se escribe en la calculadora. |
| `esperado` | Resultado esperado en LaTeX. Si empieza por `T:` es una descripción en texto (error claro, caso con condiciones, etc.). |
| `nota` | Aclaración opcional. |

## Convenciones

- **Nivel:** `N1` básico · `N2` intermedio · `N3` desafío (rama delicada, precisión, rendimiento o función especial).
- "Error claro" significa un mensaje comprensible; devolver un número incorrecto en silencio es el peor resultado posible.
- Cuando una expresión admite dos lecturas matemáticas razonables, el ejercicio es de tipo `convencion`: la interfaz debe **mostrar** la que usa.
- Los valores aproximados se dan con 9 cifras significativas.

---

## SY-P. Multiplicación implícita y precedencia

Cómo se agrupa y en qué orden se evalúa. Donde la matemática admite dos lecturas razonables, el ejercicio es de tipo `convencion`: el motor debe **declarar** la que usa de forma visible (no basta con elegir una en silencio).

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-P-01 | N1 | `valor` | `2(3+4)` | `14` |  |
| SY-P-02 | N1 | `valor` | `2\pi` | `6.283185307` |  |
| SY-P-03 | N1 | `interpretacion` | `3\sin x` | `3\cdot\sin(x)` |  |
| SY-P-04 | N2 | `interpretacion` | `2x^{2}` | `2\cdot\left(x^{2}\right)` | Con x=3 vale 18, no 36. |
| SY-P-05 | N2 | `interpretacion` | `-x^{2}` | `-\left(x^{2}\right)` | Con x=3 vale -9. |
| SY-P-06 | N1 | `valor` | `(-3)^{2}` | `9` |  |
| SY-P-07 | N2 | `valor` | `-3^{2}` | `-9` |  |
| SY-P-08 | N2 | `valor` | `2^{3^{2}}` | `512` | La potencia se agrupa por la derecha: 2^(3^2). |
| SY-P-09 | N1 | `valor` | `\left(2^{3}\right)^{2}` | `64` |  |
| SY-P-10 | N1 | `valor` | `2^{-1}` | `\frac{1}{2}` |  |
| SY-P-11 | N1 | `valor` | `5-3-1` | `1` | Asociatividad por la izquierda. |
| SY-P-12 | N1 | `valor` | `100\div10\div5` | `2` |  |
| SY-P-13 | N1 | `valor` | `2+3\cdot4` | `14` |  |
| SY-P-14 | N1 | `valor` | `(2+3)\cdot4` | `20` |  |
| SY-P-15 | N2 | `valor` | `-2^{2}+3` | `-1` |  |
| SY-P-16 | N1 | `valor` | `+5` | `5` |  |
| SY-P-17 | N1 | `valor` | `1-(-1)` | `2` |  |
| SY-P-18 | N2 | `convencion` | `8\div2(2+2)` | `16 \ \text{(izq. a der.)}\ \text{o}\ 1` | Declarar si la multiplicación implícita tiene mayor precedencia que la división. |
| SY-P-19 | N2 | `convencion` | `6\div2(1+2)` | `9 \ \text{o}\ 1` | Misma ambigüedad que el caso anterior. |
| SY-P-20 | N2 | `interpretacion` | `\frac{1}{2}x` | `\frac{x}{2}` | La fracción es una unidad; sin ambigüedad. |
| SY-P-21 | N2 | `convencion` | `1/2x` | `\frac{x}{2}\ \text{o}\ \frac{1}{2x}` | Con `/` en línea hay dos lecturas; declarar cuál. |
| SY-P-22 | N1 | `interpretacion` | `1/(2x)` | `\frac{1}{2x}` |  |
| SY-P-23 | N2 | `convencion` | `a/bc` | `\frac{ac}{b}\ \text{o}\ \frac{a}{bc}` | Declarar la convención. |
| SY-P-24 | N1 | `interpretacion` | `xy` | `x\cdot y` | Dos variables, no un símbolo llamado `xy`. |
| SY-P-25 | N1 | `interpretacion` | `xyz` | `x\cdot y\cdot z` |  |
| SY-P-26 | N1 | `interpretacion` | `x^{2}y` | `x^{2}\cdot y` |  |
| SY-P-27 | N1 | `interpretacion` | `2e^{x}` | `2\cdot e^{x}` |  |
| SY-P-28 | N2 | `interpretacion` | `e^{2}x` | `e^{2}\cdot x` |  |
| SY-P-29 | N1 | `equivalente` | `(x+1)(x-1)` | `x^{2}-1` |  |
| SY-P-30 | N2 | `equivalente` | `x(x+1)` | `x^{2}+x` | Sin `f` definida, `x(...)` es producto, no llamada a función. |
| SY-P-31 | N2 | `equivalente` | `2(x)(3)` | `6x` |  |
| SY-P-32 | N2 | `convencion` | `f(x+1)` | Si `f` no está definida: producto `f\cdot(x+1)` o aviso "f no definida" | No debe descartar `f` ni inventar una función. |
| SY-P-33 | N1 | `valor` | `2\cdot3^{2}` | `18` |  |

---

## SY-F. Funciones, argumentos y potencias de funciones

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-F-01 | N1 | `interpretacion` | `\sin x+1` | `\sin(x)+1` | No `\sin(x+1)`. |
| SY-F-02 | N1 | `interpretacion` | `\sin x\cos x` | `\sin(x)\cdot\cos(x)` |  |
| SY-F-03 | N2 | `interpretacion` | `\sin x^{2}` | `\sin\left(x^{2}\right)` | No `(\sin x)^2`. |
| SY-F-04 | N2 | `valor` | `\sin^{2}\frac{\pi}{6}` | `\frac{1}{4}` | Potencia de la función: `(\sin x)^2`. |
| SY-F-05 | N2 | `valor` | `\sin^{-1}\frac{1}{2}` | `\frac{\pi}{6}` | `\sin^{-1}` es la función inversa (arcsen), no 1/sen. |
| SY-F-06 | N2 | `valor` | `\left(\sin\frac{\pi}{6}\right)^{-1}` | `2` | Con paréntesis es el recíproco. |
| SY-F-07 | N2 | `valor` | `\tan^{-1}1` | `\frac{\pi}{4}` |  |
| SY-F-08 | N2 | `convencion` | `\sin2x` | `\sin(2x)` | Argumento sin paréntesis: declarar (lo habitual es `\sin(2x)`). |
| SY-F-09 | N1 | `valor` | `\sin\frac{\pi}{6}` | `\frac{1}{2}` |  |
| SY-F-10 | N1 | `valor` | `\sin\left(30^{\circ}\right)` | `\frac{1}{2}` |  |
| SY-F-11 | N2 | `valor` | `\sin30^{\circ}` | `\frac{1}{2}` |  |
| SY-F-12 | N2 | `equivalente` | `\cos^{2}x+\sin^{2}x` | `1` |  |
| SY-F-13 | N2 | `interpretacion` | `\ln x^{2}` | `\ln\left(x^{2}\right)` | No `(\ln x)^2`. |
| SY-F-14 | N2 | `convencion` | `\ln^{2}x` | `\left(\ln x\right)^{2}` | Potencia de función en `\ln`: declarar. |
| SY-F-15 | N1 | `valor` | `\log100` | `2` | Decisión del proyecto: `\log` sin base es base 10. |
| SY-F-16 | N1 | `valor` | `\log_{2}8` | `3` |  |
| SY-F-17 | N1 | `valor` | `\log_{10}1000` | `3` |  |
| SY-F-18 | N2 | `interpretacion` | `\log_{2}x+1` | `\left(\log_{2}x\right)+1` |  |
| SY-F-19 | N2 | `equivalente` | `\log_{a}b` | `\frac{\ln b}{\ln a}` |  |
| SY-F-20 | N1 | `valor` | `\ln e` | `1` |  |
| SY-F-21 | N2 | `valor` | `\operatorname{arsinh}1` | `0.881373587` |  |
| SY-F-22 | N2 | `valor` | `\sinh^{-1}1` | `0.881373587` |  |
| SY-F-23 | N2 | `equivalente` | `\cosh^{2}x-\sinh^{2}x` | `1` |  |
| SY-F-24 | N2 | `valor` | `\operatorname{sech}0` | `1` |  |
| SY-F-25 | N1 | `valor` | `\exp(2)` | `e^{2}\approx7.389056099` |  |
| SY-F-26 | N1 | `valor` | `e^{\ln3}` | `3` |  |
| SY-F-27 | N2 | `equivalente` | `\sin x\sin x` | `\sin^{2}x` |  |
| SY-F-28 | N1 | `valor` | `\sin(\cos(\tan0))` | `\sin 1\approx0.841470985` |  |
| SY-F-29 | N2 | `error` | `\arcsin2` | error claro: fuera del dominio real (o valor complejo declarado) |  |
| SY-F-30 | N2 | `interpretacion` | `\sqrt{x}y` | `\sqrt{x}\cdot y` | La raíz cubre solo `x`. |
| SY-F-31 | N1 | `valor` | `\sqrt3` | `\sqrt{3}\approx1.732050808` |  |
| SY-F-32 | N1 | `valor` | `\sqrt[3]{8}` | `2` |  |
| SY-F-33 | N2 | `valor` | `\sqrt[3]{-8}` | `-2` | Raíz real de índice impar (convención del proyecto). |
| SY-F-34 | N1 | `valor` | `\sqrt[4]{16}` | `2` |  |
| SY-F-35 | N2 | `valor` | `\sqrt{\sqrt{16}}` | `2` |  |
| SY-F-36 | N2 | `equivalente` | `\sqrt[n]{x^{n}}` | `\lvert x\rvert` si n par; `x` si n impar (o aviso de supuestos) |  |
| SY-F-37 | N2 | `valor` | `\lvert-3\rvert` | `3` |  |
| SY-F-38 | N2 | `valor` | `\left\vert -3\right\vert ` | `3` | Barras tecleadas con `/`. |
| SY-F-39 | N2 | `valor` | `\operatorname{abs}(-3)` | `3` |  |
| SY-F-40 | N3 | `convencion` | `\vert \vert x\vert -2\vert ` | `\left\lvert\lvert x\rvert-2\right\rvert` | Barras anidadas escritas con `/`: ambiguas; debe resolver o pedir `\lvert\rvert`. |
| SY-F-41 | N1 | `valor` | `\lfloor3.7\rfloor` | `3` |  |
| SY-F-42 | N1 | `valor` | `\lceil3.2\rceil` | `4` |  |
| SY-F-43 | N1 | `valor` | `\operatorname{sgn}(-5)` | `-1` |  |
| SY-F-44 | N2 | `valor` | `10\bmod3` | `1` |  |
| SY-F-45 | N2 | `valor` | `\gcd(12,18)` | `6` |  |
| SY-F-46 | N2 | `valor` | `\operatorname{lcm}(4,6)` | `12` |  |
| SY-F-47 | N1 | `valor` | `\max(1,5,3)` | `5` |  |
| SY-F-48 | N1 | `valor` | `\min(1,5,3)` | `1` |  |

---

## SY-E. Exponentes, fracciones y radicales

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-E-01 | N1 | `valor` | `2^{10}` | `1024` | Exponente de dos dígitos. |
| SY-E-02 | N2 | `valor` | `2^10` | `1024` | Tecleado en ASCII: no debe leerse como `2^{1}\cdot0`. Caso histórico del proyecto. |
| SY-E-03 | N1 | `valor` | `x^{12}\ \text{con}\ x=2` | `4096` |  |
| SY-E-04 | N1 | `valor` | `10^{-3}` | `0.001` |  |
| SY-E-05 | N2 | `valor` | `2^{2^{2}}` | `16` |  |
| SY-E-06 | N2 | `equivalente` | `x^{\frac{1}{2}}` | `\sqrt{x}` |  |
| SY-E-07 | N2 | `equivalente` | `x^{0.5}` | `\sqrt{x}` |  |
| SY-E-08 | N1 | `equivalente` | `x^{-1}` | `\frac{1}{x}` |  |
| SY-E-09 | N1 | `equivalente` | `\left(x^{2}\right)^{3}` | `x^{6}` |  |
| SY-E-10 | N2 | `equivalente` | `x^{2^{3}}` | `x^{8}` |  |
| SY-E-11 | N2 | `error` | `x^{2}^{3}` | error claro: doble superíndice sin agrupar |  |
| SY-E-12 | N2 | `error` | `x^{}` | error claro: exponente vacío |  |
| SY-E-13 | N2 | `error` | `^{2}` | error claro: falta la base |  |
| SY-E-14 | N2 | `valor` | `2^{3.5}` | `11.31370850` |  |
| SY-E-15 | N2 | `valor` | `2^{-0.5}` | `0.7071067812` |  |
| SY-E-16 | N1 | `valor` | `(-2)^{3}` | `-8` |  |
| SY-E-17 | N2 | `convencion` | `(-2)^{0.5}` | En ℝ: error claro; en ℂ: `\sqrt{2}\,i` |  |
| SY-E-18 | N2 | `convencion` | `(-8)^{\frac{1}{3}}` | `-2\ \text{o}\ 1+\sqrt{3}\,i` | Raíz real o rama principal: declarar. |
| SY-E-19 | N2 | `convencion` | `0^{0}` | indeterminada (o `1` por convención declarada) |  |
| SY-E-20 | N2 | `error` | `0^{-1}` | error claro: división entre cero |  |
| SY-E-21 | N1 | `valor` | `\frac12` | `\frac{1}{2}` | Abreviatura de un solo dígito. |
| SY-E-22 | N2 | `equivalente` | `\frac{1}{1+\frac{1}{x}}` | `\frac{x}{x+1}` |  |
| SY-E-23 | N2 | `valor` | `\frac{\frac{1}{2}}{\frac{3}{4}}` | `\frac{2}{3}` |  |
| SY-E-24 | N1 | `valor` | `\dfrac{3}{4}` | `\frac{3}{4}` |  |
| SY-E-25 | N1 | `valor` | `\tfrac{3}{4}` | `\frac{3}{4}` |  |
| SY-E-26 | N1 | `valor` | `\frac{1}{3}+\frac{1}{6}` | `\frac{1}{2}` |  |
| SY-E-27 | N1 | `valor` | `\frac{22}{7}` | `\frac{22}{7}\approx3.142857143` |  |
| SY-E-28 | N1 | `error` | `\frac{1}{0}` | error claro: división entre cero |  |
| SY-E-29 | N2 | `error` | `\frac{0}{0}` | error claro: indeterminado |  |
| SY-E-30 | N2 | `error` | `\frac{x}{}` | error claro: denominador vacío |  |
| SY-E-31 | N3 | `convencion` | `2\frac{1}{3}` | `\frac{7}{3}\ \text{(número mixto)}\ \text{o}\ \frac{2}{3}\ \text{(producto)}` | Número mixto o producto: declarar. |

---

## SY-N. Números, constantes, precisión y formato

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-N-01 | N1 | `valor` | `.5` | `0.5` |  |
| SY-N-02 | N1 | `valor` | `5.` | `5` |  |
| SY-N-03 | N1 | `valor` | `00012` | `12` |  |
| SY-N-04 | N1 | `valor` | `1.2\times10^{3}` | `1200` |  |
| SY-N-05 | N2 | `convencion` | `1\mathrm{e}3` | `1000\ \text{o error claro}` | Notación `e` de calculadora: aceptarla o rechazarla con aviso. |
| SY-N-06 | N2 | `valor` | `0.1+0.2` | `0.3` | No `0.30000000000000004`. |
| SY-N-07 | N2 | `valor` | `0.1\times3` | `0.3` |  |
| SY-N-08 | N2 | `valor` | `1-0.9` | `0.1` |  |
| SY-N-09 | N2 | `valor` | `4.35\times100` | `435` | En coma flotante sale 434.99999999999994. |
| SY-N-10 | N2 | `valor` | `1.005\times1000` | `1005` |  |
| SY-N-11 | N2 | `valor` | `\frac{1}{3}\times3` | `1` |  |
| SY-N-12 | N1 | `valor` | `1.5+\frac12` | `2` |  |
| SY-N-13 | N2 | `valor` | `\sqrt{2}^{2}` | `2` | Exacto, no `2.0000000000000004`. |
| SY-N-14 | N2 | `valor` | `\left(\sqrt{2}\right)^{2}-2` | `0` |  |
| SY-N-15 | N2 | `valor` | `10^{20}+1` | `100000000000000000001` | Entero exacto, sin pasar a `1e20`. |
| SY-N-16 | N2 | `valor` | `2^{100}` | `1267650600228229401496703205376` |  |
| SY-N-17 | N3 | `valor` | `9007199254740993` | `9007199254740993` | Es 2^53+1: en coma flotante se redondea a ...992. |
| SY-N-18 | N1 | `valor` | `12\%` | `0.12` |  |
| SY-N-19 | N2 | `valor` | `50\%\times200` | `100` |  |
| SY-N-20 | N1 | `valor` | `5!` | `120` |  |
| SY-N-21 | N1 | `valor` | `0!` | `1` |  |
| SY-N-22 | N2 | `error` | `(-1)!` | error claro: factorial no definido |  |
| SY-N-23 | N3 | `convencion` | `2.5!` | `\Gamma(3.5)\approx3.323350970\ \text{o error claro}` | Factorial de no entero: función Gamma o aviso. |
| SY-N-24 | N3 | `valor` | `100!` | `9.332621544\times10^{157}` | Entero exacto de 158 dígitos si se pide exacto. |
| SY-N-25 | N3 | `valor` | `170!` | `7.257415615\times10^{306}` |  |
| SY-N-26 | N3 | `valor` | `171!` | valor exacto de 311 dígitos o aviso de desbordamiento; nunca `Infinity` silencioso |  |
| SY-N-27 | N1 | `valor` | `\pi` | `3.141592654` |  |
| SY-N-28 | N1 | `valor` | `e` | `2.718281828` |  |
| SY-N-29 | N2 | `convencion` | `1,5+2` | `3.5\ \text{(coma decimal)}\ \text{o aviso}` | Separador decimal: declarar la configuración regional. |
| SY-N-30 | N2 | `convencion` | `1{,}000+1` | `1001\ \text{o aviso}` | Separador de miles. |
| SY-N-31 | N2 | `valor` | `\frac{1}{3000000}` | `3.333333333\times10^{-7}` | Notación científica en la salida. |

---

## SY-D. Delimitadores y paréntesis

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-D-01 | N1 | `error` | `(2+3` | error claro: paréntesis sin cerrar |  |
| SY-D-02 | N1 | `error` | `2+3)` | error claro: paréntesis de cierre sobrante |  |
| SY-D-03 | N1 | `error` | `()` | error claro: paréntesis vacíos |  |
| SY-D-04 | N2 | `error` | `(1+2]` | error claro: delimitadores que no coinciden |  |
| SY-D-05 | N2 | `error` | `\left(1+2\right]` | error claro: delimitadores que no coinciden |  |
| SY-D-06 | N1 | `valor` | `[1+2]\cdot3` | `9` |  |
| SY-D-07 | N2 | `convencion` | `\{1+2\}\cdot3` | `9\ \text{o aviso (llaves como conjunto)}` |  |
| SY-D-08 | N1 | `valor` | `\left(1+2\right)^{2}` | `9` |  |
| SY-D-09 | N1 | `valor` | `\left(\frac{1}{2}\right)^{2}` | `\frac{1}{4}` |  |
| SY-D-10 | N1 | `valor` | `(1+2)(3+4)` | `21` |  |
| SY-D-11 | N1 | `valor` | `(1+2)3` | `9` |  |
| SY-D-12 | N1 | `valor` | `3(1+2)` | `9` |  |
| SY-D-13 | N2 | `valor` | `((((((((((1))))))))))` | `1` |  |
| SY-D-14 | N1 | `valor` | `((2))` | `2` |  |

---

## SY-U. Operadores, espacios y caracteres Unicode

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-U-01 | N1 | `valor` | `3\times4` | `12` |  |
| SY-U-02 | N1 | `valor` | `12\div4` | `3` |  |
| SY-U-03 | N1 | `valor` | `3\cdot4` | `12` |  |
| SY-U-04 | N1 | `valor` | `3*4` | `12` |  |
| SY-U-05 | N1 | `valor` | `12/4` | `3` |  |
| SY-U-06 | N2 | `valor` | `3×4` | `12` | Carácter Unicode × (U+00D7). |
| SY-U-07 | N2 | `valor` | `12÷4` | `3` | Carácter Unicode ÷ (U+00F7). |
| SY-U-08 | N2 | `valor` | `3·4` | `12` | Punto medio (U+00B7). |
| SY-U-09 | N2 | `valor` | `2−1` | `1` | Signo menos Unicode (U+2212), típico al copiar de PDF. |
| SY-U-10 | N2 | `convencion` | `2–1` | `1\ \text{o aviso}` | Raya corta (U+2013). |
| SY-U-11 | N2 | `convencion` | `x²` | `x^{2}\ \text{o aviso}` | Superíndice Unicode. |
| SY-U-12 | N2 | `convencion` | `√4` | `2\ \text{o aviso}` | Raíz Unicode. |
| SY-U-13 | N1 | `valor` | `π` | `3.141592654` |  |
| SY-U-14 | N2 | `valor` | `3\,+\,4` | `7` | Espacios finos `\,`. |
| SY-U-15 | N2 | `valor` | `3\;+\;4` | `7` |  |
| SY-U-16 | N2 | `valor` | `3 + 4` | `7` | Espacio duro (U+00A0) entre los símbolos. |
| SY-U-17 | N2 | `valor` | `２＋３` | `5` | Dígitos de ancho completo. |
| SY-U-18 | N2 | `valor` | `2+-3` | `-1` |  |
| SY-U-19 | N2 | `valor` | `2--3` | `5` |  |
| SY-U-20 | N2 | `valor` | `2*-3` | `-6` |  |
| SY-U-21 | N2 | `valor` | `--3` | `3` |  |
| SY-U-22 | N1 | `error` | `2+` | error claro: expresión incompleta |  |
| SY-U-23 | N1 | `error` | `*2` | error claro: operador sin operando |  |
| SY-U-24 | N2 | `convencion` | `2\ 3` | `6\ \text{o}\ 23\ \text{o aviso}` | Dos números separados por espacio: declarar. |
| SY-U-25 | N2 | `convencion` | `2++3` | `5\ \text{o aviso}` |  |

---

## SY-V. Variables, símbolos y notación de cálculo

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-V-01 | N1 | `interpretacion` | `X+x` | `X+x` | Distingue mayúsculas de minúsculas: dos variables. |
| SY-V-02 | N2 | `interpretacion` | `x_{1}+x_{2}` | `x_{1}+x_{2}` | Dos variables distintas. |
| SY-V-03 | N2 | `interpretacion` | `\pi r^{2}` | `\pi\cdot r^{2}` | `\pi` es la constante; `r` es variable. |
| SY-V-04 | N2 | `valor` | `f(x)=x^{2};\ f(3)` | `9` |  |
| SY-V-05 | N2 | `equivalente` | `f(x)=x^{2};\ f(x+1)` | `(x+1)^{2}` |  |
| SY-V-06 | N2 | `valor` | `g(x,y)=x+y;\ g(2,3)` | `5` |  |
| SY-V-07 | N1 | `equivalente` | `\frac{d}{dx}x^{2}` | `2x` |  |
| SY-V-08 | N2 | `equivalente` | `\frac{d^{2}}{dx^{2}}x^{3}` | `6x` |  |
| SY-V-09 | N1 | `equivalente` | `\int x\,dx` | `\frac{x^{2}}{2}+C` |  |
| SY-V-10 | N2 | `equivalente` | `\int xdx` | `\frac{x^{2}}{2}+C` | Sin espacio antes de `dx`: debe reconocer el diferencial. |
| SY-V-11 | N1 | `valor` | `\int_{0}^{1}x\,dx` | `\frac{1}{2}` |  |
| SY-V-12 | N2 | `equivalente` | `\int x\,dy` | `xy+C` | `dy` es el diferencial; `x` es constante respecto a `y`. |
| SY-V-13 | N1 | `valor` | `\lim_{x\to0}\frac{\sin x}{x}` | `1` |  |
| SY-V-14 | N2 | `valor` | `\lim_{x\to0^{+}}\frac{1}{x}` | `+\infty` |  |
| SY-V-15 | N2 | `valor` | `\lim_{x\to\infty}\frac{1}{x}` | `0` |  |
| SY-V-16 | N1 | `valor` | `\sum_{k=1}^{10}k` | `55` |  |
| SY-V-17 | N2 | `equivalente` | `\sum_{k=1}^{n}k` | `\frac{n(n+1)}{2}` |  |
| SY-V-18 | N1 | `valor` | `\prod_{k=1}^{5}k` | `120` |  |
| SY-V-19 | N1 | `valor` | `\binom{5}{2}` | `10` |  |
| SY-V-20 | N2 | `equivalente` | `\binom{n}{2}` | `\frac{n(n-1)}{2}` |  |
| SY-V-21 | N2 | `valor` | `P(5,2)` | `20` | Permutaciones (sin ambigüedad con una función `P` definida por el usuario). |
| SY-V-22 | N2 | `convencion` | `i^{2}` | `-1\ \text{(complejos)}\ \text{o}\ i^{2}\ \text{(variable)}` | `i` como unidad imaginaria o como variable según el modo: declarar. |
| SY-V-23 | N2 | `valor` | `\overline{3+4i}` | `3-4i` |  |
| SY-V-24 | N2 | `valor` | `\lvert3+4i\rvert` | `5` |  |
| SY-V-25 | N2 | `valor` | `\mathrm{e}^{x}\ \text{con}\ x=0` | `1` |  |
| SY-V-26 | N3 | `convencion` | `sinx` | `\sin x\ \text{o}\ s\cdot i\cdot n\cdot x` | Letras seguidas sin barra: declarar si se reconocen nombres de función. |
| SY-V-27 | N3 | `convencion` | `pi` | `\pi\ \text{o}\ p\cdot i` | Nombre `pi` tecleado con letras: declarar. |
| SY-V-28 | N2 | `valor` | `\alpha+\alpha` | `2\alpha` | Letras griegas como variables. |

---

## SY-Q. Ecuaciones, sistemas y desigualdades como entrada

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-Q-01 | N1 | `resolver` | `x^{2}=4` | `x=-2,\ x=2` |  |
| SY-Q-02 | N1 | `resolver` | `x^{2}-4=0` | `x=-2,\ x=2` |  |
| SY-Q-03 | N1 | `resolver` | `4=x^{2}` | `x=-2,\ x=2` | Incógnita en el miembro derecho. |
| SY-Q-04 | N2 | `resolver` | `x=x` | identidad: todo `x` es solución |  |
| SY-Q-05 | N2 | `resolver` | `x=x+1` | sin solución |  |
| SY-Q-06 | N1 | `resolver` | `x^{2}\le4` | `x\in[-2,2]` |  |
| SY-Q-07 | N1 | `resolver` | `x^{2}<4` | `x\in(-2,2)` |  |
| SY-Q-08 | N2 | `resolver` | `1<x\le3` | `x\in(1,3]` | Desigualdad encadenada. |
| SY-Q-09 | N2 | `resolver` | `x\neq2` | `x\in\mathbb{R}\setminus\{2\}` |  |
| SY-Q-10 | N2 | `resolver` | `\lvert x\rvert<3` | `x\in(-3,3)` |  |
| SY-Q-11 | N1 | `resolver` | `\begin{cases}x+y=3\\ x-y=1\end{cases}` | `(x,y)=(2,1)` |  |
| SY-Q-12 | N2 | `resolver` | `x+y=3,\ x-y=1` | `(x,y)=(2,1)` | Sistema separado por comas. |
| SY-Q-13 | N2 | `resolver` | `x+y=3;\ x-y=1` | `(x,y)=(2,1)` | Sistema separado por punto y coma. |
| SY-Q-14 | N2 | `resolver` | `\left\{\begin{array}{l}x+y=3\\ x-y=1\end{array}\right.` | `(x,y)=(2,1)` |  |
| SY-Q-15 | N2 | `resolver` | `\begin{aligned}x+y&=3\\ x-y&=1\end{aligned}` | `(x,y)=(2,1)` |  |
| SY-Q-16 | N2 | `resolver` | `\begin{cases}x^{2}+y^{2}=25\\ x+y=7\end{cases}` | `(x,y)=(3,4),\ (4,3)` |  |
| SY-Q-17 | N2 | `resolver` | `\begin{cases}x>1\\ x<3\end{cases}` | `x\in(1,3)` |  |
| SY-Q-18 | N2 | `resolver` | `x+y=3` | una ecuación, dos incógnitas: `x=3-y` con `y` libre |  |
| SY-Q-19 | N2 | `error` | `x=y=3` | error claro o interpretación declarada (igualdad encadenada) |  |
| SY-Q-20 | N2 | `convencion` | `x^{2}-4` | Sin `=`, en modo ecuación: tratar como `x^{2}-4=0` o avisar | Declarar el comportamiento. |
| SY-Q-21 | N1 | `resolver` | `x\leq2` | `x\in(-\infty,2]` |  |
| SY-Q-22 | N2 | `resolver` | `x<=2` | `x\in(-\infty,2]` | Operador ASCII `<=`. |
| SY-Q-23 | N2 | `resolver` | `x≥1` | `x\in[1,\infty)` | Símbolo Unicode ≥. |

---

## SY-M. Matrices y vectores como entrada

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-M-01 | N1 | `det` | `\det\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `-2` |  |
| SY-M-02 | N1 | `det` | `\det\begin{bmatrix}1&2\\3&4\end{bmatrix}` | `-2` |  |
| SY-M-03 | N2 | `det` | `\begin{vmatrix}1&2\\3&4\end{vmatrix}` | `-2` | `vmatrix` equivale a determinante. |
| SY-M-04 | N2 | `det` | `\det\begin{array}{cc}1&2\\3&4\end{array}` | `-2` |  |
| SY-M-05 | N2 | `det` | `\det\left[\begin{matrix}1&2\\3&4\end{matrix}\right]` | `-2` |  |
| SY-M-06 | N2 | `det` | `\det[[1,2],[3,4]]` | `-2` | Sintaxis ASCII de listas anidadas. |
| SY-M-07 | N2 | `error` | `\begin{pmatrix}1&2\\3\end{pmatrix}` | error claro: filas de distinta longitud |  |
| SY-M-08 | N2 | `error` | `\begin{pmatrix}\end{pmatrix}` | error claro: matriz vacía |  |
| SY-M-09 | N2 | `det` | `\det\begin{pmatrix}\frac12&\sqrt2\\\pi&e\end{pmatrix}` | `\frac{e}{2}-\sqrt{2}\pi\approx-3.0837` | Entradas con fracciones, radicales y constantes. |
| SY-M-10 | N2 | `vectores` | `\begin{pmatrix}1\\2\\3\end{pmatrix}\cdot\begin{pmatrix}4\\5\\6\end{pmatrix}` | `32` |  |
| SY-M-11 | N2 | `vectores` | `\langle1,2,3\rangle\cdot\langle4,5,6\rangle` | `32` | Notación de ángulo para vectores. |
| SY-M-12 | N2 | `convencion` | `(1,2,3)\cdot(4,5,6)` | `32\ \text{o aviso}` | Tupla: vector, punto o intervalo según el contexto; declarar. |
| SY-M-13 | N2 | `vectores` | `\mathbf{i}+2\mathbf{j}-\mathbf{k}` | `(1,2,-1)` | Notación de base canónica. |
| SY-M-14 | N2 | `vectores` | `\vec{u}\cdot\vec{v}\ \text{con}\ \vec{u}=(1,2,3),\ \vec{v}=(4,5,6)` | `32` |  |
| SY-M-15 | N2 | `convencion` | `\vec{u}\times\vec{v}` | producto cruz (vectores 3D); no producto escalar | `\times` entre vectores es producto cruz. |
| SY-M-16 | N2 | `convencion` | `\left\lvert A\right\rvert` | determinante de `A` si `A` es matriz; valor absoluto si es escalar | Debe decidir por el tipo. |
| SY-M-17 | N2 | `inversa` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{-1}` | `\begin{pmatrix}-2&1\\\frac{3}{2}&-\frac{1}{2}\end{pmatrix}` |  |
| SY-M-18 | N2 | `matriz` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{T}` | `\begin{pmatrix}1&3\\2&4\end{pmatrix}` |  |
| SY-M-19 | N2 | `matriz` | `\begin{pmatrix}1&2\\3&4\end{pmatrix}^{\top}` | `\begin{pmatrix}1&3\\2&4\end{pmatrix}` |  |
| SY-M-20 | N2 | `matriz` | `2\begin{pmatrix}1&2\\3&4\end{pmatrix}` | `\begin{pmatrix}2&4\\6&8\end{pmatrix}` |  |

---

## SY-S. Alias y notación en español

Notación habitual en libros y aulas en español. El motor debe **aceptar el alias** o responder con un aviso claro que sugiera la forma correcta; no debe interpretarlo como producto de letras.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-S-01 | N1 | `valor` | `\operatorname{sen}\frac{\pi}{6}` | `\frac{1}{2}` |  |
| SY-S-02 | N1 | `valor` | `\operatorname{tg}\frac{\pi}{4}` | `1` |  |
| SY-S-03 | N1 | `valor` | `\operatorname{ctg}\frac{\pi}{4}` | `1` |  |
| SY-S-04 | N1 | `valor` | `\operatorname{cosec}\frac{\pi}{6}` | `2` |  |
| SY-S-05 | N2 | `valor` | `\operatorname{arcsen}\frac{1}{2}` | `\frac{\pi}{6}` |  |
| SY-S-06 | N2 | `valor` | `\operatorname{arctg}1` | `\frac{\pi}{4}` |  |
| SY-S-07 | N2 | `valor` | `\operatorname{arcctg}1` | `\frac{\pi}{4}` |  |
| SY-S-08 | N2 | `valor` | `\operatorname{senh}1` | `1.175201194` |  |
| SY-S-09 | N2 | `valor` | `\operatorname{tgh}1` | `0.7615941560` |  |
| SY-S-10 | N2 | `valor` | `\operatorname{argsenh}1` | `0.881373587` |  |
| SY-S-11 | N2 | `valor` | `sen(x)\ \text{con}\ x=\frac{\pi}{6}` | `\frac{1}{2}` | Texto plano con paréntesis. |
| SY-S-12 | N2 | `valor` | `raiz(16)` | `4` | Nombre `raiz` sin tilde en texto plano. |
| SY-S-13 | N2 | `valor` | `sin(0)` | `0` | Nombre inglés en texto plano. |
| SY-S-14 | N2 | `valor` | `exp(0)` | `1` |  |
| SY-S-15 | N2 | `valor` | `ln(e)` | `1` |  |
| SY-S-16 | N2 | `valor` | `log(100)` | `2` | Base 10, decisión del proyecto. |
| SY-S-17 | N2 | `valor` | `abs(-3)` | `3` |  |
| SY-S-18 | N2 | `valor` | `sqrt(16)` | `4` |  |
| SY-S-19 | N2 | `valor` | `sin(30°)` | `\frac{1}{2}` | Grados con el símbolo °. |
| SY-S-20 | N2 | `valor` | `sen(30°)` | `\frac{1}{2}` |  |

---

## SY-R. Ida y vuelta: la salida debe poder reingresarse

Se toma la salida mostrada por la calculadora y se vuelve a ingresar como entrada. El valor resultante debe ser el mismo. Es la mejor prueba de que la salida LaTeX es sintácticamente válida para el propio motor.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-R-01 | N1 | `valor` | `\frac{\sqrt{2}}{2}` | `0.7071067812` |  |
| SY-R-02 | N1 | `valor` | `2\sqrt{3}` | `3.464101615` |  |
| SY-R-03 | N1 | `valor` | `\frac{\pi}{6}` | `0.5235987756` |  |
| SY-R-04 | N2 | `valor` | `e^{-x^{2}}\ \text{con}\ x=1` | `0.3678794412` |  |
| SY-R-05 | N2 | `valor` | `\operatorname{arsinh}\left(1\right)` | `0.881373587` |  |
| SY-R-06 | N2 | `valor` | `\ln\left(2\right)` | `0.6931471806` |  |
| SY-R-07 | N2 | `valor` | `1.5\times10^{-7}` | `0.00000015` |  |
| SY-R-08 | N2 | `valor` | `1+2i` | `1+2i` | Complejo en forma binómica. |
| SY-R-09 | N2 | `equivalente` | `\frac{x^{3}}{3}+C` | al derivar da `x^{2}` | Salida de una integral reingresada y derivada. |
| SY-R-10 | N2 | `equivalente` | `\left(\frac{x+1}{x-1}\right)^{2}` | `\frac{(x+1)^{2}}{(x-1)^{2}}` |  |
| SY-R-11 | N2 | `matriz` | `\begin{pmatrix}-2&1\\\frac{3}{2}&-\frac{1}{2}\end{pmatrix}` | al multiplicar por `\begin{pmatrix}1&2\\3&4\end{pmatrix}` da la identidad |  |
| SY-R-12 | N2 | `error` | `\text{no existe}` | texto no ingresable: error claro (no debe aceptarlo como expresión) |  |
| SY-R-13 | N2 | `valor` | `\sqrt[3]{x}\ \text{con}\ x=27` | `3` |  |
| SY-R-14 | N3 | `valor` | `\left\lvert x\right\rvert\ \text{con}\ x=-4` | `4` |  |

---

## SY-X. Entradas hostiles y de estrés

El objetivo es la **robustez**: ninguna entrada debe bloquear la aplicación, ejecutar código ni devolver un resultado falso. Es aceptable un error claro o un límite de tiempo anunciado.

| ID | Nivel | Operación | Entrada | Resultado esperado | Nota |
|---|---|---|---|---|---|
| SY-X-01 | N1 | `error` | *(vacía)* | sin cambios o aviso "entrada vacía"; sin error interno |  |
| SY-X-02 | N1 | `error` | `\ \ \ \ ` | igual que la entrada vacía |  |
| SY-X-03 | N2 | `error` | `\\` | error claro de sintaxis |  |
| SY-X-04 | N2 | `equivalente` | `x+x+x+\cdots+x\ \text{(500 términos)}` | `500x` | Entrada larga con la misma suma repetida. |
| SY-X-05 | N3 | `valor` | `\underbrace{(\cdots((1))\cdots)}_{30\text{ niveles}}` | `1` | Paréntesis anidados a 30 niveles. |
| SY-X-06 | N3 | `error` | `\text{(entrada de 10 000 caracteres)}` | procesada sin bloquear, o rechazada con aviso de longitud |  |
| SY-X-07 | N2 | `error` | `\infty-\infty` | indeterminado: error claro |  |
| SY-X-08 | N2 | `error` | `\sqrt{-1}` | en ℝ: error claro; en ℂ: `i` |  |
| SY-X-09 | N3 | `error` | `99999999999^{99999999999}` | límite de tiempo o memoria anunciado; nunca bloqueo ni valor falso |  |
| SY-X-10 | N3 | `error` | `10^{10^{10}}` | resultado simbólico o aviso de tamaño; sin intentar imprimir 10^10 dígitos |  |
| SY-X-11 | N3 | `error` | `9^{9^{9}}` | ídem (el número tiene unos 369 millones de dígitos) |  |
| SY-X-12 | N3 | `error` | `\int\sin\left(x^{x}\right)dx` | sin forma elemental: aviso claro; no una antiderivada inventada |  |
| SY-X-13 | N3 | `equivalente` | `\frac{d}{dx}x^{x^{x}}` | `x^{x^{x}}\left(x^{x}(\ln x+1)\ln x+x^{x-1}\right)` |  |
| SY-X-14 | N3 | `valor` | `\underbrace{\frac{1}{\frac{1}{\cdots\frac{1}{x}}}}_{50\text{ niveles}}` | `x` o `\frac{1}{x}` según la paridad de los niveles (50 → `x`) |  |
| SY-X-15 | N2 | `error` | `\text{<script>alert(1)</script>}` | tratado como texto o error; **nunca** se ejecuta ni se inserta como HTML |  |
| SY-X-16 | N2 | `error` | `\input{/etc/passwd}` | ignorado o rechazado; sin lectura de archivos |  |
| SY-X-17 | N2 | `error` | `\write18{ls}` | ignorado o rechazado; sin ejecución |  |
| SY-X-18 | N3 | `error` | `__import__('os').system('ls')` | error de sintaxis sin ejecutar nada (relevante para el backend de Plus) |  |
| SY-X-19 | N3 | `error` | `open('/etc/passwd').read()` | error de sintaxis sin ejecutar nada |  |
| SY-X-20 | N2 | `error` | `😀+1` | error claro de carácter no válido |  |
| SY-X-21 | N3 | `error` | `1​+​2` | `3\ \text{o error claro}` | Con espacios de ancho cero (U+200B) entre los símbolos. |
| SY-X-22 | N3 | `valor` | `\text{(número de 10 000 dígitos)}+1` | suma exacta o aviso de tamaño; sin pasar a coma flotante |  |

---

## Resumen de cobertura

| Sección | Ejercicios |
|---|:-:|
| SY-P · Multiplicación implícita y precedencia | 33 |
| SY-F · Funciones, argumentos y potencias de funciones | 48 |
| SY-E · Exponentes, fracciones y radicales | 31 |
| SY-N · Números, constantes, precisión y formato | 31 |
| SY-D · Delimitadores y paréntesis | 14 |
| SY-U · Operadores, espacios y caracteres Unicode | 25 |
| SY-V · Variables, símbolos y notación de cálculo | 28 |
| SY-Q · Ecuaciones, sistemas y desigualdades como entrada | 23 |
| SY-M · Matrices y vectores como entrada | 20 |
| SY-S · Alias y notación en español | 20 |
| SY-R · Ida y vuelta: la salida debe poder reingresarse | 14 |
| SY-X · Entradas hostiles y de estrés | 22 |
| **Total** | **309** |
