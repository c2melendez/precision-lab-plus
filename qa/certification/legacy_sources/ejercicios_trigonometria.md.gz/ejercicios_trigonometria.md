# Batería de ejercicios — Funciones trigonométricas

Suite de evaluación para la calculadora (Precision Lab Lite / Plus), enfocada en las cuatro familias:

- **Directas:** $\sin,\ \cos,\ \tan,\ \csc,\ \sec,\ \cot$
- **Inversas:** $\arcsin,\ \arccos,\ \arctan,\ \operatorname{arccsc},\ \operatorname{arcsec},\ \operatorname{arccot}$
- **Hiperbólicas:** $\sinh,\ \cosh,\ \tanh,\ \operatorname{csch},\ \operatorname{sech},\ \coth$
- **Hiperbólicas inversas:** $\operatorname{arsinh},\ \operatorname{arcosh},\ \operatorname{artanh},\ \operatorname{arcsch},\ \operatorname{arsech},\ \operatorname{arcoth}$

## Convenciones

- Ángulos en **radianes**, salvo en la sección 9.
- $\operatorname{arccot}$ con rango $(0,\pi)$: $\operatorname{arccot}(x)=\arctan(1/x)$ si $x>0$, $\arctan(1/x)+\pi$ si $x<0$, y $\operatorname{arccot}(0)=\pi/2$.
- $\operatorname{arcsch}(x)=\operatorname{arsinh}(1/x)$, $\operatorname{arsech}(x)=\operatorname{arcosh}(1/x)$, $\operatorname{arcoth}(x)=\operatorname{artanh}(1/x)$.
- Aproximaciones numéricas a 9 decimales. Las antiderivadas se aceptan **salvo constante** (y en formas equivalentes).
- Cada ejercicio y cada resultado esperado está en código LaTeX, listo para copiar y pegar.
- Cuando el resultado esperado es un error o "no existe", la calculadora debe decirlo con claridad, nunca devolver un valor incorrecto en silencio.

---

## 1. Evaluación de una función en un punto

### 1.A Directas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EV-D-01 | `\sin\left(\frac{\pi}{6}\right)` | `\frac{1}{2}` |
| EV-D-02 | `\cos\left(\frac{\pi}{3}\right)` | `\frac{1}{2}` |
| EV-D-03 | `\tan\left(\frac{\pi}{4}\right)` | `1` |
| EV-D-04 | `\csc\left(\frac{\pi}{6}\right)` | `2` |
| EV-D-05 | `\sec\left(\frac{\pi}{3}\right)` | `2` |
| EV-D-06 | `\cot\left(\frac{\pi}{4}\right)` | `1` |
| EV-D-07 | `\sin\left(\frac{5\pi}{4}\right)` | `-\frac{\sqrt{2}}{2}` |
| EV-D-08 | `\sin(1)` | `\approx 0.841470985` |
| EV-D-09 | `\cos(2)` | `\approx -0.416146837` |
| EV-D-10 | `\cot\left(\frac{\pi}{2}\right)` | `0` |
| EV-D-11 | `\sin^{2}\left(\frac{\pi}{8}\right)+\cos^{2}\left(\frac{\pi}{8}\right)` | `1` |
| EV-D-12 | `\tan\left(\frac{\pi}{2}\right)` | indefinida (error claro) |

### 1.B Inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EV-I-01 | `\arcsin\left(\frac{1}{2}\right)` | `\frac{\pi}{6}` |
| EV-I-02 | `\arccos\left(-\frac{1}{2}\right)` | `\frac{2\pi}{3}` |
| EV-I-03 | `\arctan(1)` | `\frac{\pi}{4}` |
| EV-I-04 | `\arctan\left(\sqrt{3}\right)` | `\frac{\pi}{3}` |
| EV-I-05 | `\operatorname{arccsc}(2)` | `\frac{\pi}{6}` |
| EV-I-06 | `\operatorname{arcsec}(2)` | `\frac{\pi}{3}` |
| EV-I-07 | `\operatorname{arccot}(-1)` | `\frac{3\pi}{4}` |
| EV-I-08 | `\operatorname{arccot}(0)` | `\frac{\pi}{2}` |
| EV-I-09 | `\arcsin(\sin 2)` | `\pi-2 \approx 1.141592654` |
| EV-I-10 | `\sin\left(\arccos\frac{3}{5}\right)` | `\frac{4}{5}` |
| EV-I-11 | `\cos(\arctan 2)` | `\frac{\sqrt{5}}{5}` |
| EV-I-12 | `\arcsin(2)` | fuera del dominio real (error claro) |

### 1.C Hiperbólicas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EV-H-01 | `\sinh(0)` | `0` |
| EV-H-02 | `\cosh(0)` | `1` |
| EV-H-03 | `\tanh(0)` | `0` |
| EV-H-04 | `\sinh(\ln 2)` | `\frac{3}{4}` |
| EV-H-05 | `\cosh(\ln 2)` | `\frac{5}{4}` |
| EV-H-06 | `\tanh(\ln 2)` | `\frac{3}{5}` |
| EV-H-07 | `\operatorname{csch}(\ln 2)` | `\frac{4}{3}` |
| EV-H-08 | `\operatorname{sech}(\ln 2)` | `\frac{4}{5}` |
| EV-H-09 | `\coth(\ln 2)` | `\frac{5}{3}` |
| EV-H-10 | `\sinh(1)` | `\approx 1.175201194` |
| EV-H-11 | `\cosh(1)` | `\approx 1.543080635` |
| EV-H-12 | `\cosh^{2}(1)-\sinh^{2}(1)` | `1` |

### 1.D Hiperbólicas inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EV-HI-01 | `\operatorname{arsinh}(0)` | `0` |
| EV-HI-02 | `\operatorname{arcosh}(1)` | `0` |
| EV-HI-03 | `\operatorname{artanh}(0)` | `0` |
| EV-HI-04 | `\operatorname{arsinh}(1)` | `\ln\left(1+\sqrt{2}\right)\approx 0.881373587` |
| EV-HI-05 | `\operatorname{arcosh}(2)` | `\ln\left(2+\sqrt{3}\right)\approx 1.316957897` |
| EV-HI-06 | `\operatorname{artanh}\left(\frac{1}{2}\right)` | `\frac{1}{2}\ln 3\approx 0.549306144` |
| EV-HI-07 | `\operatorname{arcsch}(1)` | `\ln\left(1+\sqrt{2}\right)` |
| EV-HI-08 | `\operatorname{arsech}\left(\frac{1}{2}\right)` | `\ln\left(2+\sqrt{3}\right)` |
| EV-HI-09 | `\operatorname{arcoth}(2)` | `\frac{1}{2}\ln 3` |
| EV-HI-10 | `\sinh\left(\operatorname{arsinh}(3)\right)` | `3` |
| EV-HI-11 | `\operatorname{artanh}(1)` | no definida / $+\infty$ (error claro) |
| EV-HI-12 | `\operatorname{arcosh}\left(\frac{1}{2}\right)` | fuera del dominio real (error claro) |

---

## 2. Ecuaciones

### 2.A Directas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EC-D-01 | `\sin x=\frac{1}{2},\quad x\in[0,2\pi)` | `x=\frac{\pi}{6},\ \frac{5\pi}{6}` |
| EC-D-02 | `2\cos x-1=0,\quad x\in[0,2\pi)` | `x=\frac{\pi}{3},\ \frac{5\pi}{3}` |
| EC-D-03 | `\tan x=\sqrt{3}` | `x=\frac{\pi}{3}+k\pi,\ k\in\mathbb{Z}` |
| EC-D-04 | `2\sin^{2}x-\sin x-1=0,\quad x\in[0,2\pi)` | `x=\frac{\pi}{2},\ \frac{7\pi}{6},\ \frac{11\pi}{6}` |
| EC-D-05 | `\sin x+\cos x=1,\quad x\in[0,2\pi)` | `x=0,\ \frac{\pi}{2}` |
| EC-D-06 | `\sin 2x=\cos x,\quad x\in[0,2\pi)` | `x=\frac{\pi}{6},\ \frac{\pi}{2},\ \frac{5\pi}{6},\ \frac{3\pi}{2}` |
| EC-D-07 | `\csc x=2,\quad x\in[0,2\pi)` | `x=\frac{\pi}{6},\ \frac{5\pi}{6}` |
| EC-D-08 | `\sec x=-2,\quad x\in[0,2\pi)` | `x=\frac{2\pi}{3},\ \frac{4\pi}{3}` |
| EC-D-09 | `\cot x=1,\quad x\in[0,2\pi)` | `x=\frac{\pi}{4},\ \frac{5\pi}{4}` |
| EC-D-10 | `\sin x=2` | sin solución real |

### 2.B Inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EC-I-01 | `\arcsin x=\frac{\pi}{6}` | `x=\frac{1}{2}` |
| EC-I-02 | `\arccos x=\frac{\pi}{3}` | `x=\frac{1}{2}` |
| EC-I-03 | `\arctan x=\frac{\pi}{4}` | `x=1` |
| EC-I-04 | `\arcsin x=\arccos x` | `x=\frac{\sqrt{2}}{2}` |
| EC-I-05 | `\arctan x+\arctan(2x)=\frac{\pi}{4}` | `x=\frac{\sqrt{17}-3}{4}` (descartar `\frac{-3-\sqrt{17}}{4}`) |
| EC-I-06 | `\operatorname{arccot} x=\frac{2\pi}{3}` | `x=-\frac{\sqrt{3}}{3}` |
| EC-I-07 | `\operatorname{arcsec} x=\frac{\pi}{3}` | `x=2` |
| EC-I-08 | `\operatorname{arccsc} x=\frac{\pi}{6}` | `x=2` |
| EC-I-09 | `\arcsin x=2` | sin solución real |

### 2.C Hiperbólicas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EC-H-01 | `\sinh x=0` | `x=0` |
| EC-H-02 | `\cosh x=1` | `x=0` |
| EC-H-03 | `\sinh x=1` | `x=\ln\left(1+\sqrt{2}\right)` |
| EC-H-04 | `\cosh x=2` | `x=\pm\ln\left(2+\sqrt{3}\right)` |
| EC-H-05 | `\tanh x=\frac{1}{2}` | `x=\frac{1}{2}\ln 3` |
| EC-H-06 | `\cosh x+\sinh x=2` | `x=\ln 2` |
| EC-H-07 | `\sinh(2x)=\sinh x` | `x=0` |
| EC-H-08 | `\operatorname{sech} x=\frac{1}{2}` | `x=\pm\ln\left(2+\sqrt{3}\right)` |
| EC-H-09 | `\cosh x=\frac{1}{2}` | sin solución real |
| EC-H-10 | `\tanh x=2` | sin solución real |

### 2.D Hiperbólicas inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| EC-HI-01 | `\operatorname{arsinh} x=1` | `x=\sinh 1\approx 1.175201194` |
| EC-HI-02 | `\operatorname{arcosh} x=0` | `x=1` |
| EC-HI-03 | `\operatorname{artanh} x=\ln 2` | `x=\frac{3}{5}` |
| EC-HI-04 | `\operatorname{arcosh} x=\ln 2` | `x=\frac{5}{4}` |
| EC-HI-05 | `\operatorname{arcoth} x=\ln 2` | `x=\frac{5}{3}` |
| EC-HI-06 | `\operatorname{artanh} x=\operatorname{arsinh} x` | `x=0` |
| EC-HI-07 | `\operatorname{arcosh} x=\operatorname{arsinh} x` | sin solución real |
| EC-HI-08 | `\operatorname{artanh} x=2` | `x=\tanh 2\approx 0.964027580` |

---

## 3. Inecuaciones

### 3.A Directas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IN-D-01 | `\sin x>\frac{1}{2},\quad x\in[0,2\pi)` | `\left(\frac{\pi}{6},\frac{5\pi}{6}\right)` |
| IN-D-02 | `\cos x\le 0,\quad x\in[0,2\pi)` | `\left[\frac{\pi}{2},\frac{3\pi}{2}\right]` |
| IN-D-03 | `\tan x<1,\quad x\in\left(-\frac{\pi}{2},\frac{\pi}{2}\right)` | `\left(-\frac{\pi}{2},\frac{\pi}{4}\right)` |
| IN-D-04 | `2\sin^{2}x-\sin x-1<0,\quad x\in[0,2\pi)` | `\left[0,\frac{\pi}{2}\right)\cup\left(\frac{\pi}{2},\frac{7\pi}{6}\right)\cup\left(\frac{11\pi}{6},2\pi\right)` |
| IN-D-05 | `\lvert\sin x\rvert\ge\frac{\sqrt{2}}{2},\quad x\in[0,2\pi)` | `\left[\frac{\pi}{4},\frac{3\pi}{4}\right]\cup\left[\frac{5\pi}{4},\frac{7\pi}{4}\right]` |
| IN-D-06 | `\sin x\cos x>0,\quad x\in[0,2\pi)` | `\left(0,\frac{\pi}{2}\right)\cup\left(\pi,\frac{3\pi}{2}\right)` |
| IN-D-07 | `\sec x>2,\quad x\in\left(-\frac{\pi}{2},\frac{\pi}{2}\right)` | `\left(-\frac{\pi}{2},-\frac{\pi}{3}\right)\cup\left(\frac{\pi}{3},\frac{\pi}{2}\right)` |
| IN-D-08 | `\cot x\ge 1,\quad x\in(0,\pi)` | `\left(0,\frac{\pi}{4}\right]` |
| IN-D-09 | `\csc x<-2,\quad x\in[0,2\pi)` | `\left(\pi,\frac{7\pi}{6}\right)\cup\left(\frac{11\pi}{6},2\pi\right)` |

### 3.B Inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IN-I-01 | `\arcsin x>\frac{\pi}{6}` | `\left(\frac{1}{2},1\right]` |
| IN-I-02 | `\arccos x\le\frac{\pi}{3}` | `\left[\frac{1}{2},1\right]` |
| IN-I-03 | `\arctan x<1` | `\left(-\infty,\tan 1\right)` con `\tan 1\approx 1.557407725` |
| IN-I-04 | `\arctan(2x)\ge\frac{\pi}{4}` | `\left[\frac{1}{2},\infty\right)` |
| IN-I-05 | `\arcsin x<\arccos x` | `\left[-1,\frac{\sqrt{2}}{2}\right)` |
| IN-I-06 | `\operatorname{arccot} x<\frac{\pi}{4}` | `(1,\infty)` |
| IN-I-07 | `\arcsin(2x-1)\ge 0` | `\left[\frac{1}{2},1\right]` |

### 3.C Hiperbólicas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IN-H-01 | `\sinh x>0` | `(0,\infty)` |
| IN-H-02 | `\cosh x<2` | `\left(-\ln\left(2+\sqrt{3}\right),\ \ln\left(2+\sqrt{3}\right)\right)` |
| IN-H-03 | `\tanh x\le\frac{1}{2}` | `\left(-\infty,\frac{1}{2}\ln 3\right]` |
| IN-H-04 | `\sinh x<-1` | `\left(-\infty,-\ln\left(1+\sqrt{2}\right)\right)` |
| IN-H-05 | `\sinh x\cosh x>0` | `(0,\infty)` |
| IN-H-06 | `\cosh(2x)\le 3` | `\left[-\ln\left(1+\sqrt{2}\right),\ \ln\left(1+\sqrt{2}\right)\right]` |
| IN-H-07 | `\operatorname{sech} x>\frac{1}{2}` | `\left(-\ln\left(2+\sqrt{3}\right),\ \ln\left(2+\sqrt{3}\right)\right)` |
| IN-H-08 | `\cosh x\ge 1` | `\mathbb{R}` |
| IN-H-09 | `\cosh x<1` | `\varnothing` |

### 3.D Hiperbólicas inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IN-HI-01 | `\operatorname{arsinh} x>1` | `\left(\sinh 1,\infty\right)` |
| IN-HI-02 | `\operatorname{arsinh} x\le 0` | `(-\infty,0]` |
| IN-HI-03 | `\operatorname{arcosh} x<1` | `\left[1,\cosh 1\right)` |
| IN-HI-04 | `\operatorname{arcosh} x\ge 0` | `[1,\infty)` (dominio) |
| IN-HI-05 | `\operatorname{artanh} x\ge\frac{1}{2}\ln 3` | `\left[\frac{1}{2},1\right)` |
| IN-HI-06 | `\operatorname{artanh} x<0` | `(-1,0)` |
| IN-HI-07 | `\operatorname{arcoth} x>\ln 2` | `\left(1,\frac{5}{3}\right)` |

---

## 4. Límites

### 4.A Directas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| LM-D-01 | `\lim_{x\to 0}\frac{\sin x}{x}` | `1` |
| LM-D-02 | `\lim_{x\to 0}\frac{1-\cos x}{x^{2}}` | `\frac{1}{2}` |
| LM-D-03 | `\lim_{x\to 0}\frac{\tan x}{x}` | `1` |
| LM-D-04 | `\lim_{x\to 0}\frac{\sin 3x}{\sin 5x}` | `\frac{3}{5}` |
| LM-D-05 | `\lim_{x\to 0}\frac{\tan x-\sin x}{x^{3}}` | `\frac{1}{2}` |
| LM-D-06 | `\lim_{x\to 0}\frac{\sec x-1}{x^{2}}` | `\frac{1}{2}` |
| LM-D-07 | `\lim_{x\to 0}\frac{\csc x-\cot x}{x}` | `\frac{1}{2}` |
| LM-D-08 | `\lim_{x\to 0}x\cot x` | `1` |
| LM-D-09 | `\lim_{x\to\frac{\pi}{2}^{-}}\tan x` | `+\infty` |
| LM-D-10 | `\lim_{x\to\frac{\pi}{2}^{+}}\tan x` | `-\infty` |
| LM-D-11 | `\lim_{x\to\infty}\frac{\sin x}{x}` | `0` |
| LM-D-12 | `\lim_{x\to 0}x\sin\frac{1}{x}` | `0` |
| LM-D-13 | `\lim_{x\to\frac{\pi}{2}}\tan x` | no existe (laterales distintos) |

### 4.B Inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| LM-I-01 | `\lim_{x\to 0}\frac{\arcsin x}{x}` | `1` |
| LM-I-02 | `\lim_{x\to 0}\frac{\arctan x}{x}` | `1` |
| LM-I-03 | `\lim_{x\to 0}\frac{\arcsin 3x}{\arctan 2x}` | `\frac{3}{2}` |
| LM-I-04 | `\lim_{x\to 0}\frac{x-\arctan x}{x^{3}}` | `\frac{1}{3}` |
| LM-I-05 | `\lim_{x\to 0}\frac{\arcsin x-x}{x^{3}}` | `\frac{1}{6}` |
| LM-I-06 | `\lim_{x\to\infty}\arctan x` | `\frac{\pi}{2}` |
| LM-I-07 | `\lim_{x\to-\infty}\arctan x` | `-\frac{\pi}{2}` |
| LM-I-08 | `\lim_{x\to 1^{-}}\arccos x` | `0` |
| LM-I-09 | `\lim_{x\to\infty}x\left(\frac{\pi}{2}-\arctan x\right)` | `1` |
| LM-I-10 | `\lim_{x\to\infty}\operatorname{arccot} x` | `0` |
| LM-I-11 | `\lim_{x\to-\infty}\operatorname{arccot} x` | `\pi` |

### 4.C Hiperbólicas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| LM-H-01 | `\lim_{x\to 0}\frac{\sinh x}{x}` | `1` |
| LM-H-02 | `\lim_{x\to 0}\frac{\cosh x-1}{x^{2}}` | `\frac{1}{2}` |
| LM-H-03 | `\lim_{x\to 0}\frac{\tanh x}{x}` | `1` |
| LM-H-04 | `\lim_{x\to 0}\frac{\sinh x-x}{x^{3}}` | `\frac{1}{6}` |
| LM-H-05 | `\lim_{x\to\infty}\tanh x` | `1` |
| LM-H-06 | `\lim_{x\to-\infty}\tanh x` | `-1` |
| LM-H-07 | `\lim_{x\to\infty}\frac{\sinh x}{e^{x}}` | `\frac{1}{2}` |
| LM-H-08 | `\lim_{x\to\infty}\frac{\cosh x}{\sinh x}` | `1` |
| LM-H-09 | `\lim_{x\to\infty}\left(\cosh x-\sinh x\right)` | `0` |
| LM-H-10 | `\lim_{x\to 0^{+}}\coth x` | `+\infty` |
| LM-H-11 | `\lim_{x\to\infty}\cosh x` | `+\infty` |

### 4.D Hiperbólicas inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| LM-HI-01 | `\lim_{x\to 0}\frac{\operatorname{arsinh} x}{x}` | `1` |
| LM-HI-02 | `\lim_{x\to 0}\frac{\operatorname{artanh} x}{x}` | `1` |
| LM-HI-03 | `\lim_{x\to 0}\frac{\operatorname{artanh} x-x}{x^{3}}` | `\frac{1}{3}` |
| LM-HI-04 | `\lim_{x\to 1^{-}}\operatorname{artanh} x` | `+\infty` |
| LM-HI-05 | `\lim_{x\to\infty}\left(\operatorname{arsinh} x-\ln x\right)` | `\ln 2` |
| LM-HI-06 | `\lim_{x\to\infty}\left(\operatorname{arcosh} x-\ln x\right)` | `\ln 2` |
| LM-HI-07 | `\lim_{x\to 1^{+}}\frac{\operatorname{arcosh} x}{\sqrt{x-1}}` | `\sqrt{2}` |
| LM-HI-08 | `\lim_{x\to\infty}\operatorname{arcoth} x` | `0` |

---

## 5. Derivadas

### 5.A Directas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| DV-D-01 | `\frac{d}{dx}\sin x` | `\cos x` |
| DV-D-02 | `\frac{d}{dx}\cos x` | `-\sin x` |
| DV-D-03 | `\frac{d}{dx}\tan x` | `\sec^{2}x` |
| DV-D-04 | `\frac{d}{dx}\csc x` | `-\csc x\cot x` |
| DV-D-05 | `\frac{d}{dx}\sec x` | `\sec x\tan x` |
| DV-D-06 | `\frac{d}{dx}\cot x` | `-\csc^{2}x` |
| DV-D-07 | `\frac{d}{dx}\sin\left(x^{2}\right)` | `2x\cos\left(x^{2}\right)` |
| DV-D-08 | `\frac{d}{dx}\tan(3x)` | `3\sec^{2}(3x)` |
| DV-D-09 | `\frac{d}{dx}\left(x\cos x\right)` | `\cos x-x\sin x` |
| DV-D-10 | `\frac{d}{dx}\sin^{3}(2x)` | `6\sin^{2}(2x)\cos(2x)` |
| DV-D-11 | `\frac{d}{dx}\frac{\sin x}{1+\cos x}` | `\frac{1}{1+\cos x}` |
| DV-D-12 | `\frac{d}{dx}\ln\left(\sec x+\tan x\right)` | `\sec x` |
| DV-D-13 | `\frac{d^{2}}{dx^{2}}\tan x` | `2\sec^{2}x\tan x` |
| DV-D-14 | `\left.\frac{d}{dx}\tan x\right\rvert_{x=\pi/4}` | `2` |

### 5.B Inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| DV-I-01 | `\frac{d}{dx}\arcsin x` | `\frac{1}{\sqrt{1-x^{2}}}` |
| DV-I-02 | `\frac{d}{dx}\arccos x` | `-\frac{1}{\sqrt{1-x^{2}}}` |
| DV-I-03 | `\frac{d}{dx}\arctan x` | `\frac{1}{1+x^{2}}` |
| DV-I-04 | `\frac{d}{dx}\operatorname{arccot} x` | `-\frac{1}{1+x^{2}}` |
| DV-I-05 | `\frac{d}{dx}\operatorname{arcsec} x` | `\frac{1}{\lvert x\rvert\sqrt{x^{2}-1}}` |
| DV-I-06 | `\frac{d}{dx}\operatorname{arccsc} x` | `-\frac{1}{\lvert x\rvert\sqrt{x^{2}-1}}` |
| DV-I-07 | `\frac{d}{dx}\arctan\left(x^{2}\right)` | `\frac{2x}{1+x^{4}}` |
| DV-I-08 | `\frac{d}{dx}\arcsin(2x)` | `\frac{2}{\sqrt{1-4x^{2}}}` |
| DV-I-09 | `\frac{d}{dx}\left(x\arctan x\right)` | `\arctan x+\frac{x}{1+x^{2}}` |
| DV-I-10 | `\frac{d}{dx}\arcsin\left(\sqrt{x}\right)` | `\frac{1}{2\sqrt{x(1-x)}}` |
| DV-I-11 | `\frac{d}{dx}\arctan\left(\frac{1}{x}\right)` | `-\frac{1}{1+x^{2}}` |
| DV-I-12 | `\frac{d}{dx}\left(\arcsin x+\arccos x\right)` | `0` |

### 5.C Hiperbólicas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| DV-H-01 | `\frac{d}{dx}\sinh x` | `\cosh x` |
| DV-H-02 | `\frac{d}{dx}\cosh x` | `\sinh x` |
| DV-H-03 | `\frac{d}{dx}\tanh x` | `\operatorname{sech}^{2}x` |
| DV-H-04 | `\frac{d}{dx}\operatorname{csch} x` | `-\operatorname{csch} x\coth x` |
| DV-H-05 | `\frac{d}{dx}\operatorname{sech} x` | `-\operatorname{sech} x\tanh x` |
| DV-H-06 | `\frac{d}{dx}\coth x` | `-\operatorname{csch}^{2}x` |
| DV-H-07 | `\frac{d}{dx}\sinh(3x)` | `3\cosh(3x)` |
| DV-H-08 | `\frac{d}{dx}\ln\left(\cosh x\right)` | `\tanh x` |
| DV-H-09 | `\frac{d}{dx}\left(x\sinh x\right)` | `\sinh x+x\cosh x` |
| DV-H-10 | `\frac{d}{dx}\tanh^{2}x` | `2\tanh x\operatorname{sech}^{2}x` |
| DV-H-11 | `\frac{d}{dx}\left(e^{x}\cosh x\right)` | `e^{2x}` |
| DV-H-12 | `\frac{d}{dx}\left(\cosh^{2}x-\sinh^{2}x\right)` | `0` |

### 5.D Hiperbólicas inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| DV-HI-01 | `\frac{d}{dx}\operatorname{arsinh} x` | `\frac{1}{\sqrt{x^{2}+1}}` |
| DV-HI-02 | `\frac{d}{dx}\operatorname{arcosh} x` | `\frac{1}{\sqrt{x^{2}-1}},\ x>1` |
| DV-HI-03 | `\frac{d}{dx}\operatorname{artanh} x` | `\frac{1}{1-x^{2}},\ \lvert x\rvert<1` |
| DV-HI-04 | `\frac{d}{dx}\operatorname{arcoth} x` | `\frac{1}{1-x^{2}},\ \lvert x\rvert>1` |
| DV-HI-05 | `\frac{d}{dx}\operatorname{arsech} x` | `-\frac{1}{x\sqrt{1-x^{2}}},\ 0<x<1` |
| DV-HI-06 | `\frac{d}{dx}\operatorname{arcsch} x` | `-\frac{1}{\lvert x\rvert\sqrt{1+x^{2}}}` |
| DV-HI-07 | `\frac{d}{dx}\operatorname{arsinh}(2x)` | `\frac{2}{\sqrt{4x^{2}+1}}` |
| DV-HI-08 | `\frac{d}{dx}\operatorname{arcosh}(3x)` | `\frac{3}{\sqrt{9x^{2}-1}}` |
| DV-HI-09 | `\frac{d}{dx}\operatorname{artanh}\left(x^{2}\right)` | `\frac{2x}{1-x^{4}}` |
| DV-HI-10 | `\frac{d}{dx}\left(x\operatorname{arsinh} x-\sqrt{x^{2}+1}\right)` | `\operatorname{arsinh} x` |

---

## 6. Integrales indefinidas

### 6.A Directas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IT-D-01 | `\int\sin x\,dx` | `-\cos x+C` |
| IT-D-02 | `\int\cos x\,dx` | `\sin x+C` |
| IT-D-03 | `\int\sec^{2}x\,dx` | `\tan x+C` |
| IT-D-04 | `\int\csc^{2}x\,dx` | `-\cot x+C` |
| IT-D-05 | `\int\sec x\tan x\,dx` | `\sec x+C` |
| IT-D-06 | `\int\csc x\cot x\,dx` | `-\csc x+C` |
| IT-D-07 | `\int\tan x\,dx` | `-\ln\lvert\cos x\rvert+C` |
| IT-D-08 | `\int\cot x\,dx` | `\ln\lvert\sin x\rvert+C` |
| IT-D-09 | `\int\sec x\,dx` | `\ln\lvert\sec x+\tan x\rvert+C` |
| IT-D-10 | `\int\csc x\,dx` | `-\ln\lvert\csc x+\cot x\rvert+C` |
| IT-D-11 | `\int\sin^{2}x\,dx` | `\frac{x}{2}-\frac{\sin 2x}{4}+C` |
| IT-D-12 | `\int\sin^{3}x\,dx` | `-\cos x+\frac{\cos^{3}x}{3}+C` |
| IT-D-13 | `\int\tan^{2}x\,dx` | `\tan x-x+C` |
| IT-D-14 | `\int\sec^{3}x\,dx` | `\frac{1}{2}\left(\sec x\tan x+\ln\lvert\sec x+\tan x\rvert\right)+C` |
| IT-D-15 | `\int x\cos x\,dx` | `x\sin x+\cos x+C` |
| IT-D-16 | `\int e^{x}\sin x\,dx` | `\frac{e^{x}\left(\sin x-\cos x\right)}{2}+C` |
| IT-D-17 | `\int\sin(3x)\,dx` | `-\frac{\cos 3x}{3}+C` |
| IT-D-18 | `\int\frac{\cos x}{1+\sin^{2}x}\,dx` | `\arctan(\sin x)+C` |

### 6.B Inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IT-I-01 | `\int\arcsin x\,dx` | `x\arcsin x+\sqrt{1-x^{2}}+C` |
| IT-I-02 | `\int\arccos x\,dx` | `x\arccos x-\sqrt{1-x^{2}}+C` |
| IT-I-03 | `\int\arctan x\,dx` | `x\arctan x-\frac{1}{2}\ln\left(1+x^{2}\right)+C` |
| IT-I-04 | `\int\operatorname{arccot} x\,dx` | `x\operatorname{arccot} x+\frac{1}{2}\ln\left(1+x^{2}\right)+C` |
| IT-I-05 | `\int\operatorname{arcsec} x\,dx,\ x>1` | `x\operatorname{arcsec} x-\ln\left(x+\sqrt{x^{2}-1}\right)+C` |
| IT-I-06 | `\int\operatorname{arccsc} x\,dx,\ x>1` | `x\operatorname{arccsc} x+\ln\left(x+\sqrt{x^{2}-1}\right)+C` |
| IT-I-07 | `\int x\arctan x\,dx` | `\frac{x^{2}+1}{2}\arctan x-\frac{x}{2}+C` |
| IT-I-08 | `\int\frac{\arcsin x}{\sqrt{1-x^{2}}}\,dx` | `\frac{1}{2}\arcsin^{2}x+C` |
| IT-I-09 | `\int\frac{dx}{1+x^{2}}` | `\arctan x+C` |
| IT-I-10 | `\int\frac{dx}{\sqrt{1-x^{2}}}` | `\arcsin x+C` |
| IT-I-11 | `\int\frac{dx}{x\sqrt{x^{2}-1}},\ x>1` | `\operatorname{arcsec} x+C` |

### 6.C Hiperbólicas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IT-H-01 | `\int\sinh x\,dx` | `\cosh x+C` |
| IT-H-02 | `\int\cosh x\,dx` | `\sinh x+C` |
| IT-H-03 | `\int\tanh x\,dx` | `\ln\left(\cosh x\right)+C` |
| IT-H-04 | `\int\coth x\,dx` | `\ln\lvert\sinh x\rvert+C` |
| IT-H-05 | `\int\operatorname{sech}^{2}x\,dx` | `\tanh x+C` |
| IT-H-06 | `\int\operatorname{csch}^{2}x\,dx` | `-\coth x+C` |
| IT-H-07 | `\int\operatorname{sech} x\,dx` | `\arctan(\sinh x)+C` |
| IT-H-08 | `\int\operatorname{csch} x\,dx` | `\ln\left\lvert\tanh\frac{x}{2}\right\rvert+C` |
| IT-H-09 | `\int\operatorname{sech} x\tanh x\,dx` | `-\operatorname{sech} x+C` |
| IT-H-10 | `\int\operatorname{csch} x\coth x\,dx` | `-\operatorname{csch} x+C` |
| IT-H-11 | `\int\sinh^{2}x\,dx` | `\frac{\sinh 2x}{4}-\frac{x}{2}+C` |
| IT-H-12 | `\int\cosh^{2}x\,dx` | `\frac{\sinh 2x}{4}+\frac{x}{2}+C` |
| IT-H-13 | `\int\tanh^{2}x\,dx` | `x-\tanh x+C` |
| IT-H-14 | `\int x\sinh x\,dx` | `x\cosh x-\sinh x+C` |
| IT-H-15 | `\int\sinh x\cosh x\,dx` | `\frac{\sinh^{2}x}{2}+C` |
| IT-H-16 | `\int e^{x}\cosh x\,dx` | `\frac{e^{2x}}{4}+\frac{x}{2}+C` |

### 6.D Hiperbólicas inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| IT-HI-01 | `\int\operatorname{arsinh} x\,dx` | `x\operatorname{arsinh} x-\sqrt{x^{2}+1}+C` |
| IT-HI-02 | `\int\operatorname{arcosh} x\,dx,\ x>1` | `x\operatorname{arcosh} x-\sqrt{x^{2}-1}+C` |
| IT-HI-03 | `\int\operatorname{artanh} x\,dx,\ \lvert x\rvert<1` | `x\operatorname{artanh} x+\frac{1}{2}\ln\left(1-x^{2}\right)+C` |
| IT-HI-04 | `\int\operatorname{arcoth} x\,dx,\ \lvert x\rvert>1` | `x\operatorname{arcoth} x+\frac{1}{2}\ln\left(x^{2}-1\right)+C` |
| IT-HI-05 | `\int\operatorname{arsech} x\,dx,\ 0<x<1` | `x\operatorname{arsech} x+\arcsin x+C` |
| IT-HI-06 | `\int\operatorname{arcsch} x\,dx,\ x>0` | `x\operatorname{arcsch} x+\operatorname{arsinh} x+C` |
| IT-HI-07 | `\int\frac{dx}{\sqrt{x^{2}+1}}` | `\operatorname{arsinh} x+C` |
| IT-HI-08 | `\int\frac{dx}{\sqrt{x^{2}-1}},\ x>1` | `\operatorname{arcosh} x+C` |
| IT-HI-09 | `\int\frac{dx}{1-x^{2}},\ \lvert x\rvert<1` | `\operatorname{artanh} x+C` |
| IT-HI-10 | `\int x\operatorname{arsinh} x\,dx` | `\frac{2x^{2}+1}{4}\operatorname{arsinh} x-\frac{x\sqrt{x^{2}+1}}{4}+C` |

---

## 7. Integrales definidas

### 7.A Directas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| ID-D-01 | `\int_{0}^{\pi}\sin x\,dx` | `2` |
| ID-D-02 | `\int_{0}^{\pi/2}\cos x\,dx` | `1` |
| ID-D-03 | `\int_{0}^{\pi/4}\sec^{2}x\,dx` | `1` |
| ID-D-04 | `\int_{0}^{\pi/4}\tan x\,dx` | `\frac{1}{2}\ln 2\approx 0.346573590` |
| ID-D-05 | `\int_{0}^{\pi}\sin^{2}x\,dx` | `\frac{\pi}{2}` |
| ID-D-06 | `\int_{0}^{\pi/2}\sin^{3}x\,dx` | `\frac{2}{3}` |
| ID-D-07 | `\int_{0}^{\pi/2}\sin x\cos x\,dx` | `\frac{1}{2}` |
| ID-D-08 | `\int_{-\pi}^{\pi}\sin x\,dx` | `0` |
| ID-D-09 | `\int_{0}^{\pi/3}\sec x\,dx` | `\ln\left(2+\sqrt{3}\right)\approx 1.316957897` |
| ID-D-10 | `\int_{\pi/6}^{\pi/2}\csc x\,dx` | `\ln\left(2+\sqrt{3}\right)` |
| ID-D-11 | `\int_{0}^{\pi}x\sin x\,dx` | `\pi` |
| ID-D-12 | `\int_{0}^{\pi/2}\ln(\sin x)\,dx` | `-\frac{\pi}{2}\ln 2\approx -1.088793045` (desafío) |

### 7.B Inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| ID-I-01 | `\int_{0}^{1}\arcsin x\,dx` | `\frac{\pi}{2}-1\approx 0.570796327` |
| ID-I-02 | `\int_{0}^{1}\arccos x\,dx` | `1` |
| ID-I-03 | `\int_{0}^{1}\arctan x\,dx` | `\frac{\pi}{4}-\frac{1}{2}\ln 2\approx 0.438825` |
| ID-I-04 | `\int_{0}^{1}\operatorname{arccot} x\,dx` | `\frac{\pi}{4}+\frac{1}{2}\ln 2\approx 1.131972` |
| ID-I-05 | `\int_{0}^{1}\frac{dx}{1+x^{2}}` | `\frac{\pi}{4}` |
| ID-I-06 | `\int_{0}^{1/2}\frac{dx}{\sqrt{1-x^{2}}}` | `\frac{\pi}{6}` |
| ID-I-07 | `\int_{1}^{2}\frac{dx}{x\sqrt{x^{2}-1}}` | `\frac{\pi}{3}` |
| ID-I-08 | `\int_{-1}^{1}\arcsin x\,dx` | `0` |
| ID-I-09 | `\int_{0}^{\infty}\frac{dx}{1+x^{2}}` | `\frac{\pi}{2}` (impropia) |

### 7.C Hiperbólicas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| ID-H-01 | `\int_{0}^{1}\sinh x\,dx` | `\cosh 1-1\approx 0.543080635` |
| ID-H-02 | `\int_{0}^{\ln 2}\cosh x\,dx` | `\frac{3}{4}` |
| ID-H-03 | `\int_{0}^{1}\operatorname{sech}^{2}x\,dx` | `\tanh 1\approx 0.761594156` |
| ID-H-04 | `\int_{0}^{\ln 2}\tanh x\,dx` | `\ln\frac{5}{4}\approx 0.223143551` |
| ID-H-05 | `\int_{0}^{1}x\sinh x\,dx` | `e^{-1}\approx 0.367879441` |
| ID-H-06 | `\int_{-1}^{1}\sinh x\,dx` | `0` |
| ID-H-07 | `\int_{-1}^{1}\cosh x\,dx` | `2\sinh 1\approx 2.350402387` |
| ID-H-08 | `\int_{0}^{1}\cosh^{2}x\,dx` | `\frac{\sinh 2}{4}+\frac{1}{2}\approx 1.406715102` |
| ID-H-09 | `\int_{0}^{1}\operatorname{sech} x\,dx` | `\arctan(\sinh 1)\approx 0.865769483` |
| ID-H-10 | `\int_{0}^{\infty}\operatorname{sech}^{2}x\,dx` | `1` (impropia) |

### 7.D Hiperbólicas inversas

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| ID-HI-01 | `\int_{0}^{1}\operatorname{arsinh} x\,dx` | `\ln\left(1+\sqrt{2}\right)-\sqrt{2}+1\approx 0.467160025` |
| ID-HI-02 | `\int_{1}^{2}\operatorname{arcosh} x\,dx` | `2\ln\left(2+\sqrt{3}\right)-\sqrt{3}\approx 0.901864986` |
| ID-HI-03 | `\int_{0}^{1/2}\operatorname{artanh} x\,dx` | `\frac{3}{4}\ln 3-\ln 2\approx 0.130812036` |
| ID-HI-04 | `\int_{2}^{3}\operatorname{arcoth} x\,dx` | `3\ln 2-\frac{3}{2}\ln 3\approx 0.431523109` |
| ID-HI-05 | `\int_{0}^{1}\frac{dx}{\sqrt{x^{2}+1}}` | `\ln\left(1+\sqrt{2}\right)` |
| ID-HI-06 | `\int_{1}^{2}\frac{dx}{\sqrt{x^{2}-1}}` | `\ln\left(2+\sqrt{3}\right)` |
| ID-HI-07 | `\int_{0}^{1/2}\frac{dx}{1-x^{2}}` | `\frac{1}{2}\ln 3` |
| ID-HI-08 | `\int_{0}^{1}x\operatorname{arsinh} x\,dx` | `\frac{3}{4}\ln\left(1+\sqrt{2}\right)-\frac{\sqrt{2}}{4}\approx 0.307426799` |
| ID-HI-09 | `\int_{-1}^{1}\operatorname{arsinh} x\,dx` | `0` |

---

## 8. Casos límite y manejo de errores

La calculadora **no debe** devolver un número incorrecto en ninguno de estos casos.

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| CL-01 | `\int_{0}^{\pi}\sec^{2}x\,dx` | diverge (aplicar Barrow ingenuamente daría `0`, que es falso) |
| CL-02 | `\int_{0}^{\pi/2}\tan x\,dx` | diverge a `+\infty` |
| CL-03 | `\int_{-\pi/2}^{\pi/2}\tan x\,dx` | diverge (no debe devolver `0`) |
| CL-04 | `\lim_{x\to 0}\sin\frac{1}{x}` | no existe |
| CL-05 | `\lim_{x\to\infty}\sin x` | no existe |
| CL-06 | `\cos x=\frac{3}{2}` | sin solución real |
| CL-07 | `\sec x=\frac{1}{2}` | sin solución real |
| CL-08 | `\operatorname{arsech}(2)` | fuera del dominio real (error claro) |
| CL-09 | `\operatorname{arcoth}\left(\frac{1}{2}\right)` | fuera del dominio real (error claro) |
| CL-10 | `\frac{d}{dx}\operatorname{arcsec} x` evaluada en `x=\frac{1}{2}` | fuera del dominio (error claro) |
| CL-11 | `\tan x>1,\quad x\in[0,2\pi)` | `\left(\frac{\pi}{4},\frac{\pi}{2}\right)\cup\left(\frac{5\pi}{4},\frac{3\pi}{2}\right)` (las asíntotas quedan excluidas) |
| CL-12 | `\cot x=0,\quad x\in[0,2\pi]` | `x=\frac{\pi}{2},\ \frac{3\pi}{2}` |

---

## 9. Modo grados (verificar el cambio RAD ↔ DEG)

| ID | Ejercicio | Resultado esperado |
|---|---|---|
| GR-01 | `\sin\left(30^{\circ}\right)` | `\frac{1}{2}` |
| GR-02 | `\cos\left(60^{\circ}\right)` | `\frac{1}{2}` |
| GR-03 | `\tan\left(45^{\circ}\right)` | `1` |
| GR-04 | `\sec\left(60^{\circ}\right)` | `2` |
| GR-05 | `\arcsin\left(\frac{1}{2}\right)` (salida en DEG) | `30^{\circ}` |
| GR-06 | `\arctan(1)` (salida en DEG) | `45^{\circ}` |
| GR-07 | `\operatorname{arccot}(-1)` (salida en DEG) | `135^{\circ}` |
| GR-08 | `\sin x=\frac{1}{2},\quad x\in[0^{\circ},360^{\circ})` | `x=30^{\circ},\ 150^{\circ}` |
| GR-09 | `\sinh(1)` en modo DEG | `\approx 1.175201194` (las hiperbólicas **no** dependen del modo angular) |

---

## Resumen de cobertura

| Categoría | Directas | Inversas | Hiperbólicas | Hip. inversas |
|---|:-:|:-:|:-:|:-:|
| Evaluación en un punto | 12 | 12 | 12 | 12 |
| Ecuaciones | 10 | 9 | 10 | 8 |
| Inecuaciones | 9 | 7 | 9 | 7 |
| Límites | 13 | 11 | 11 | 8 |
| Derivadas | 14 | 12 | 12 | 10 |
| Integrales indefinidas | 18 | 11 | 16 | 10 |
| Integrales definidas | 12 | 9 | 10 | 9 |

Más 12 casos límite (sección 8) y 9 casos de modo grados (sección 9).
